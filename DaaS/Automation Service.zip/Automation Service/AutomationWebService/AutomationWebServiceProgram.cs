﻿using EriCommon;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration.Install;
using System.IO;
using System.Linq;
using System.ServiceModel.Web;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AutomationWebService
{
    static class AutomationWebServiceProgram
    {
#if true
        /// <summary>
        /// The service name.
        /// </summary>
        public const String ServiceName = "EricomAuthenticationServer";

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        public static void Main(string[] args)
        {
            System.IO.Directory.SetCurrentDirectory(AppDomain.CurrentDomain.BaseDirectory);

            ServiceStopped = new NamedManualResetEvent("Stop Ericom Automation Web Server");

            ServiceInstance = new WindowsService(ServiceName,
                                                 on_start,
                                                 on_stop,
                                                 on_pause,
                                                 on_continue,
                                                 on_shutdown,
                                                 on_power_event,
                                                 on_custom_command);

            ServiceInstance.Main(args);
            ServiceInstance.Join();
        }

        static void copy_App_4_Debugging()
        {
            string source_fn = @"..\..\App_4_Debugging.config";

            if(File.Exists(source_fn))
            {
                File.Copy(source_fn, "AutomationWebService.exe.config", true);
                File.Copy(source_fn, "AutomationWebService.vshost.exe.config", true);
            }
        }

        static void on_start(WindowsService ws, string[] args)
        {
            //Copy App_4_Debugging.config
            copy_App_4_Debugging();

            AppConfig.Init();

            BootstrapSettings.UpdateXmlFile();

//             Thread.Sleep(5000);
//             AppCfg.Modify("EmailSettings", "SMTPPassword", "blabla");
//             AppCfg.Modify("PortalSettings", "Port", 1957);

            //TODO
            string url = string.Format("{0}://{1}:{2}/{3}", "http", "localhost", 8066, "EricomAutomation");
            AutomationWebServiceImpl impl = new AutomationWebServiceImpl();

            using (WebServiceHost host = new WebServiceHost(impl, new Uri(url)))
            {
                host.Open();
                ServiceStopped.WaitOne();
            }
        }

        static void on_stop(WindowsService ws)
        {
            ServiceStopped.Set();
        }

        static void on_pause(WindowsService ws)
        {
            PauseService(ws);
        }

        static void on_continue(WindowsService ws)
        {
            ContinueService(ws);
        }

        static void on_shutdown(WindowsService ws)
        {
            on_stop(ws);
        }

        static bool on_power_event(WindowsService.PowerEventCtx ctx)
        {
            return false;
        }

        static void on_custom_command(WindowsService.CustomCommandCtx ctx)
        {

        }

        static public WindowsService ServiceInstance
        {
            get;
            private set;
        }

        static public NamedManualResetEvent ServiceStopped
        {
            get;
            private set;
        }

        static public bool ServicePaused
        {
            get { return paused_state != PausedState.NotPaused; }
        }

        public enum PausedState
        {
            OK,
            NotPaused,
            PausedByWindowsService,
            PausedRemotely,
        }

        static public PausedState PauseService(WindowsService ws)
        {
            lock (servicepaused_lock)
            {
                if (ServicePaused)
                    return paused_state;

                paused_state = (ws == null) ? PausedState.PausedRemotely : PausedState.PausedByWindowsService;

                return PausedState.OK;
            }
        }

        static public PausedState ContinueService(WindowsService ws)
        {
            lock (servicepaused_lock)
            {
                if (ServicePaused == false)
                    return PausedState.NotPaused;

                if (paused_state != ((ws == null) ? PausedState.PausedRemotely : PausedState.PausedByWindowsService))
                    return paused_state;

                paused_state = PausedState.NotPaused;

                return PausedState.OK;
            }
        }

        static private Object servicepaused_lock = new Object();
        static private PausedState paused_state = PausedState.NotPaused;
#else
        static public AutomationWebService sm_ServiceInstance = new AutomationWebService();

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main(string[] args)
        {
            if (args != null && args.Length > 0)
            {
                if (args[0].Equals("/run", StringComparison.OrdinalIgnoreCase))
                {
                    RunAsConsole(args.Skip(1).ToArray());
                    return;
                }
                else if (args[0].Equals("/install", StringComparison.OrdinalIgnoreCase))
                {
                    InstallService();
                    return;
                }
                else if (args[0].Equals("/uninstall", StringComparison.OrdinalIgnoreCase))
                {
                    UninstallService();
                    return;
                }
                else if (args[0].Equals("/start", StringComparison.OrdinalIgnoreCase))
                {
                    StartService();
                    return;
                }
                else if (args[0].Equals("/stop", StringComparison.OrdinalIgnoreCase))
                {
                    StopService();
                    return;
                }
                else if (args[0].Equals("/restart", StringComparison.OrdinalIgnoreCase))
                {
                    RestartService();
                    return;
                }
            }

            RunAsService();
        }

        /// <summary>
        /// Entry point for running as a console application
        /// </summary>
        static void RunAsConsole(string[] args)
        {
            sm_ServiceInstance.OnStartAsConsole(args);
        }

        /// <summary>
        /// Entry point for running the as a service
        /// </summary>
        static void RunAsService()
        {
            ServiceBase.Run(sm_ServiceInstance);
        }

        static public IDisposable RunAsTest()
        {
            // TODO
            sm_ServiceInstance = new AutomationWebService();
            sm_ServiceInstance.OnStartAsTest();
            return sm_ServiceInstance;
        }

        static void StartService()
        {
            using (ServiceController service = new ServiceController(sm_ServiceInstance.ServiceName))
            {
                try
                {
                    service.Start();
                    service.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromMilliseconds(5000));
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }

        static void StopService()
        {
            using (ServiceController service = new ServiceController(sm_ServiceInstance.ServiceName))
            {
                if (service.Status != ServiceControllerStatus.Running)
                {
                    return;
                }

                try
                {
                    service.Stop();
                    service.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromMilliseconds(5000));
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }

        static void RestartService()
        {
            StopService();
            StartService();
        }

        static void InstallService()
        {
            using (AssemblyInstaller myAssemblyInstaller = new AssemblyInstaller(typeof(AutomationWebServiceProgram).Assembly, null))
            {
                IDictionary mySavedState = new Hashtable();

                try
                {
                    myAssemblyInstaller.UseNewContext = true;
                    myAssemblyInstaller.Install(mySavedState);
                    myAssemblyInstaller.Commit(mySavedState);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);

                    try
                    {
                        myAssemblyInstaller.Rollback(mySavedState);
                    }
                    catch { }
                }
            }
        }

        static void UninstallService()
        {
            using (AssemblyInstaller myAssemblyInstaller = new AssemblyInstaller(typeof(AutomationWebServiceProgram).Assembly, null))
            {
                IDictionary mySavedState = new Hashtable();

                try
                {
                    myAssemblyInstaller.UseNewContext = true;
                    myAssemblyInstaller.Uninstall(mySavedState);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);

                    try
                    {
                        myAssemblyInstaller.Rollback(mySavedState);
                    }
                    catch { }
                }
            }
        }
#endif
    }
}
