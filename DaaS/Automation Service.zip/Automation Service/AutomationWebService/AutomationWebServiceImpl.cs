﻿using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Threading.Tasks;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Collections.ObjectModel;
using System.Diagnostics;
using EriCommon;
using TracerX;
// using System.Collections.Objectmodel;


namespace AutomationWebService
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single,
#if DEBUG
                     IncludeExceptionDetailInFaults = true,
#endif
                     ConcurrencyMode = ConcurrencyMode.Multiple)]
    public class AutomationWebServiceImpl : IAutomationWebService
    {
        #region INITIALIZATION & STARTING
        #endregion INITIALIZATION & STARTING

        #region WEBSERVER

        static private readonly Hashtable m_MimeTypes;
        private string m_WebPageDirectory = Path.Combine(Path.GetDirectoryName(Assembly.GetCallingAssembly().Location), @"WebServer");

        /// <summary>
        /// GetFromDisk implementation
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
       public Stream GetFromDisk(string path)
       {
            try
            {
                if (String.IsNullOrEmpty(path))
                {
                    WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.Redirect;
                    WebOperationContext.Current.OutgoingResponse.StatusDescription = "Redirect";
                    
                    // TODO:
                    string defaultFolder = "";
                    string defaultPage = "";
                    string defaultUrl = string.Format("/{0}/{1}",defaultFolder, defaultPage);

                    return null;
                }

                string ext = Path.GetExtension(path);

                if (String.IsNullOrEmpty(ext))
                {
                    // path is a folder
                    WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.Forbidden;
                    WebOperationContext.Current.OutgoingResponse.StatusDescription = "The server does not allow listing the content of directories.";
                    return null;
                }

                String full_path = Path.Combine(m_WebPageDirectory, path);

                FileInfo fi = new FileInfo(full_path);

                if (fi.Exists == false)
                {
                    WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.NotFound;
                    WebOperationContext.Current.OutgoingResponse.StatusDescription = "Page not found";
                    WebOperationContext.Current.OutgoingResponse.ContentType = "text/html";
                    MemoryStream response_stream = new MemoryStream();
                    //TODO translate
                    string sm_404_not_alllowed = "404 - File or directory not found. \nThe resource you are looking for might have been removed, had its name changed, or is temporarily unavailable.";
                    byte[] sm_404_not_alllowedByts = GetBytes(sm_404_not_alllowed);
                    response_stream.Write(sm_404_not_alllowedByts, 0, sm_404_not_alllowedByts.Length);
                    response_stream.Position = 0;

                    return response_stream;
                }

                String ifModifiedSince = WebOperationContext.Current.IncomingRequest.Headers[HttpRequestHeader.IfModifiedSince];
                DateTime modified_since;

                if (String.IsNullOrEmpty(ifModifiedSince) == false && DateTime.TryParse(ifModifiedSince, null, DateTimeStyles.AdjustToUniversal, out modified_since))
                {
                    // "If-Modified-Since" will actually contain our "Last-Modified" value, which was formatted using the "R" format, which means it will never include milliseconds.
                    // Therefore, we must drop the milliseconds from fi.LastWriteTimeUtc before comparing them.
                    DateTime temp = fi.LastWriteTimeUtc;
                    DateTime modification_time = new DateTime(temp.Year, temp.Month, temp.Day, temp.Hour, temp.Minute, temp.Second, 0);

                    if (modification_time <= modified_since)
                    {
                        WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.NotModified;
                        WebOperationContext.Current.OutgoingResponse.StatusDescription = "Not Modified";
                        return null;
                    }
                }

                WebOperationContext.Current.OutgoingResponse.Headers.Add(HttpResponseHeader.LastModified, fi.LastWriteTimeUtc.ToString("R"));    // (R) = RFC1123
                WebOperationContext.Current.OutgoingResponse.Headers.Add("X-Frame-Options", "SAMEORIGIN");
                WebOperationContext.Current.OutgoingResponse.ContentType = get_mime_type(ext);
                return File.OpenRead(full_path);
            }
            catch (Exception ex)
            {
                WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.InternalServerError;
                WebOperationContext.Current.OutgoingResponse.StatusDescription = ex.Message;
                return null;
            }
        }

        private static byte[] GetBytes(string str)
        {
            byte[] bytes = new byte[str.Length * sizeof(char)];
            System.Buffer.BlockCopy(str.ToCharArray(), 0, bytes, 0, bytes.Length);
            return bytes;
        }

        static AutomationWebServiceImpl()
        {
            m_MimeTypes = new Hashtable();

            m_MimeTypes[".html"]  = "text/html";
            m_MimeTypes[".htm"]   = "text/html";
            m_MimeTypes[".css"]   = "text/css";
            m_MimeTypes[".js"]    = "text/javascript";
            m_MimeTypes[".txt"]   = "text/plain";
            m_MimeTypes[".png"]   = "image/png";
            m_MimeTypes[".gif"]   = "image/gif";
            m_MimeTypes[".jpg"]   = "image/jpeg";
            m_MimeTypes[".jpeg"]  = "image/jpeg";
            m_MimeTypes[".ico"]   = "image/x-icon";
            m_MimeTypes[".logx"]  = "application/octet-stream";
            m_MimeTypes[".exe"]   = "application/octet-stream";
            m_MimeTypes[".pdf"]   = "application/pdf";
            m_MimeTypes[".aspx"]  = "application/xml";
            m_MimeTypes[".config"]= "application/xml";
            m_MimeTypes[".gz"]    = "application/x-gzip";
            m_MimeTypes[".swf"]   = "application/x-shockwave-flash";
            m_MimeTypes[".zip"]   = "application/x-zip-compressed";
            m_MimeTypes[".woff"]  = "application/font-woff";
            m_MimeTypes[".woff2"] = "application/octet-stream";
            m_MimeTypes[".ttf"]   = "application/octet-stream";
        }

        private String get_mime_type(String ext)
        {
            String mime = (string)m_MimeTypes[ext];

            if (mime == null)
            {
                try
                {
                    using (RegistryKey rk = Registry.ClassesRoot.OpenSubKey(ext, false))
                    {
                        if (rk != null)
                            mime = (String)rk.GetValue("Content Type");

                        if (mime == null)
                            throw new KeyNotFoundException();   // arbitrary exception...
                    }
                }
                catch
                {
                    mime = "application/octet-stream";
                }
            }

            return mime;
        }

        #endregion WEBSERVER

        #region API

        static uint st_Generic_counter = 0;
        static TimeSpan st_Generic_total_delta;
        static object st_Generic_lock = new object();

        public Stream Generic(String requestVersion, Stream content)
        {
            uint counter;

            lock (st_Generic_lock)
            {
                counter = ++st_Generic_counter;
            }

            DateTime started = DateTime.Now;

            GenericRequest req = JsonUtils.StreamToObject<GenericRequest>(content);

            sm_logger.Info(String.Format("Generic request #{0}:\n", counter), req.GetText());

            string status, message;
            System.Collections.Hashtable hashtable;
            
            List<object> Params = new List<object>();
            Params.Add(req.args);

            bool success = RunPowershellScript(requestVersion, req.command, Params, out status, out message, out hashtable);

            GenericResponse res = new GenericResponse
            {
                success = success.ToString(),
                status = status,
                message = message,
                hashtable = hashtable ?? null
            };

            TimeSpan delta = DateTime.Now - started,
                     total_delta;

            lock (st_Generic_lock)
            {
                st_Generic_total_delta += delta;
                total_delta = st_Generic_total_delta;
            }

            sm_logger.Info(String.Format("Generic response #{0}:\n{1}Elapsed time: {2}ms\nAverage time: {3}ms", 
                                         counter, 
                                         res.GetText(), 
                                         delta.TotalMilliseconds,
                                         total_delta.TotalMilliseconds / counter));

            OutgoingWebResponseContext outgoingWebRequestContext = WebOperationContext.Current.OutgoingResponse;
            outgoingWebRequestContext.Headers.Add("Cache-Control", "no-cache");
            outgoingWebRequestContext.Headers.Add("Pragma", "no-cache");

            Stream ret = res.Serialize();
            return ret;
        }

        #endregion API

        #region POWER_SHELL
        private static object GetAndRemove(System.Collections.Hashtable hashtable, string key)
        {
            object retval = hashtable[key];
            hashtable.Remove(key);
            return retval;
        }

        private static bool RunPowershellScript(String requestVersion, string command, List<object> parameters, out string status, out string message, out System.Collections.Hashtable hashtable)
        {
            Exception ex;
            Collection<PSObject> psObjects = RunPowershellScript(requestVersion, command, parameters, out ex);

            if (ex == null)
            {
                Debug.Assert(psObjects.Count == 1);
                PSObject result = psObjects[0];

                if (result == null)
                {
                    hashtable = null;
                    status = "REJECTED";
                    message = "PowerShell script has rejected the command";
                    return false;
                }
                else
                {
                    hashtable = (System.Collections.Hashtable)result.ImmediateBaseObject;
                    status = (string)GetAndRemove(hashtable, "status");
                    message = (string)GetAndRemove(hashtable, "message");
                    return (bool)GetAndRemove(hashtable, "success");
                }
            }

            hashtable = null;
            status = "EXCEPTION";
            message = ex.Message;

            return false;
        }

#if DEBUG
        const bool showMessageBox = false;
#else
        const bool showMessageBox = false;
#endif

        private static Collection<PSObject> RunPowershellScript(String requestVersion, string command, List<object> parameters, out Exception ex)
        {
            try
            {
                // Validate parameters
                if (string.IsNullOrEmpty(command)) { throw new ArgumentNullException("scriptFile"); }
                if (parameters == null) { throw new ArgumentNullException("parameters"); }

                string scriptFile = String.Format("{0}{1}.ps1", BootstrapSettings.Portal.ScriptsFolderFullPath, command);
                RunspaceConfiguration runspaceConfiguration = RunspaceConfiguration.Create();

                using (Runspace runspace = RunspaceFactory.CreateRunspace(runspaceConfiguration))
                {
                    runspace.Open();
                    RunspaceInvoke scriptInvoker = new RunspaceInvoke(runspace);
                    scriptInvoker.Invoke("Set-ExecutionPolicy Unrestricted");

                    Command scriptCommand = new Command(scriptFile);
                    scriptCommand.Parameters.Add(new CommandParameter("ShowMessageBox", showMessageBox));
                    scriptCommand.Parameters.Add(new CommandParameter("RequestVersion", requestVersion));

                    foreach (object scriptParameter in parameters)
                    {
                        CommandParameter commandParm = new CommandParameter("Data", scriptParameter);
                        scriptCommand.Parameters.Add(commandParm);
                    }

                    Pipeline pipeline = runspace.CreatePipeline();
                    pipeline.Commands.Add(scriptCommand);

                    Collection<PSObject> psObjects;
                    psObjects = pipeline.Invoke();

                    ex = null;
                    return psObjects;
                }
            }
            catch (Exception e)
            {
                ex = e;
                sm_logger.Error(String.Format("Failed to run PowerShell command '{0}'.\n{1}\n{2}\n{3}", command, ex.AllMessages(0), ex.GetType(), ex.StackTrace));
                return null;
            }
        }

        #endregion POWER_SHELL

        static private readonly Logger sm_logger = Logger.GetLogger("Service", true);	// this class is used as a singleton. we can therefore use a single logger.

#if false
        public Stream GetAppList(String requestVersion, Stream content)
        {
            // TODO

            GetAppListRequest req = JsonUtils.StreamToObject<GetAppListRequest>(content);

            GetAppListResponse res = new GetAppListResponse
            {
                appName = "calc"
            };
            
            OutgoingWebResponseContext outgoingWebRequestContext = WebOperationContext.Current.OutgoingResponse;
            outgoingWebRequestContext.Headers.Add("Cache-Control", "no-cache");
            outgoingWebRequestContext.Headers.Add("Pragma", "no-cache");

            Stream ret = res.Serialize();
            return ret;
        }

        public Stream AssignUser(String requestVersion, Stream content)
        {
            // TODO

            AssignUserRequest req = JsonUtils.StreamToObject<AssignUserRequest>(content);

            AssignUserResponse res = new AssignUserResponse
            {
                status = "OK",
                success = "true",
                message = "User has been successfuly added to the selected group",
                url = "http://erez.berez"
            };

            OutgoingWebResponseContext outgoingWebRequestContext = WebOperationContext.Current.OutgoingResponse;
            outgoingWebRequestContext.Headers.Add("Cache-Control", "no-cache");
            outgoingWebRequestContext.Headers.Add("Pragma", "no-cache");

            Stream ret = res.Serialize();
            return ret;
        }

        public Stream CreateUser(String requestVersion, Stream content)
        {
            // TODO
            CreateUserRequest req = JsonUtils.StreamToObject<CreateUserRequest>(content);

            List<object> Params = new List<object>();
           
            Params.Add(req.username);
            Params.Add(req.password);
            Params.Add(req.email);
            string status, message;
            System.Collections.Hashtable hashtable;
            bool success = RunPowershellScript(requestVersion, req.command, Params, out status, out message, out hashtable);

            CreateUserResponse res = new CreateUserResponse
            {
                success = success.ToString(),
                status = status,
                message = message
            };

            OutgoingWebResponseContext outgoingWebRequestContext = WebOperationContext.Current.OutgoingResponse;
            outgoingWebRequestContext.Headers.Add("Cache-Control", "no-cache");
            outgoingWebRequestContext.Headers.Add("Pragma", "no-cache");

            Stream ret = res.Serialize();
            return ret;
        }

        public Stream CustomDesk(String requestVersion, Stream content)
        {
            // TODO

            CustomDeskRequest req = JsonUtils.StreamToObject<CustomDeskRequest>(content);

            CustomDeskResponse res = new CustomDeskResponse
            {
                status = "OK",
                success = "true",
                message = "User has been successfuly added to the selected group",
                url = "http://ee.ee/ee"
            };

            OutgoingWebResponseContext outgoingWebRequestContext = WebOperationContext.Current.OutgoingResponse;
            outgoingWebRequestContext.Headers.Add("Cache-Control", "no-cache");
            outgoingWebRequestContext.Headers.Add("Pragma", "no-cache");

            Stream ret = res.Serialize();
            return ret;
        }
        public Stream AuthUser(String requestVersion, Stream content)
        {
            // TODO
            string text;
            AuthUserRequest req = JsonUtils.StreamToObject<AuthUserRequest>(content, out text);

            AuthUserResponse res = new AuthUserResponse
            {
                status = "OK",
                success = "true",
                email = "ee@ee.il",
                message = "message"
            };

            OutgoingWebResponseContext outgoingWebRequestContext = WebOperationContext.Current.OutgoingResponse;
            outgoingWebRequestContext.Headers.Add("Cache-Control", "no-cache");
            outgoingWebRequestContext.Headers.Add("Pragma", "no-cache");

            Stream ret = res.Serialize();
            return ret;
        }
#endif
    }
}
