﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using EriCommon;
using System.Collections;

namespace AutomationWebService
{
    static class LogFormater
    {
        const uint FieldNameLength = 25;
        static readonly string sm_format = String.Format("  {{0,-{0}}}: {{1}}\n", FieldNameLength);

        public static String GetFieldText(String field_name, Object val)
        {
            bool is_password = field_name[0] == '-';
            if (is_password)
                field_name = field_name.Substring(1);

            Debug.Assert(field_name.Length <= FieldNameLength);
            Debug.Assert(!String.IsNullOrWhiteSpace(field_name));

            String valstr = (is_password) ? "*****" : 
                            (val == null) ? "<null>" : val.ToString();

            return String.Format(sm_format, field_name, valstr.ShiftLinesRight(FieldNameLength + 2, false));
        }

        public static String GetHashtableText(System.Collections.Hashtable hashtable)
        {
            String retval = "";

            if (hashtable != null)
                foreach (DictionaryEntry pair in hashtable)
                {
                    retval += LogFormater.GetFieldText((String)(pair.Key), pair.Value);
                }

            return retval;
        }
    }

    /// <summary>
    /// Base class for all request messages
    /// </summary>
    //[DataContract]
    abstract public partial class Request
    {
        public String command { get; set; }
        /// <summary>
        /// Converts the object into a JSON string
        /// </summary>
        /// <returns></returns>
        public String ToJson()
        {
            String json = JsonConvert.SerializeObject(this);
            return json;
        }

        public virtual String GetText()
        {
            return LogFormater.GetFieldText("command", command);
        }
    }

    /// <summary>
    /// Base class for all response messages
    /// </summary>
    //[DataContract]
    abstract public partial class Response
    {
        public String success { get; set; }
        public String status { get; set; }
        public String message { get; set; }


        public virtual String GetText()
        {
            return LogFormater.GetFieldText("success", success) +
                   LogFormater.GetFieldText("status",  status) +
                   LogFormater.GetFieldText("message", message);
        }
        
        static readonly JsonSerializerSettings sm_SerializerSettings;

        static Response()
        {
            sm_SerializerSettings = new JsonSerializerSettings();
            sm_SerializerSettings.Converters.Add(new StringEnumConverter());
            sm_SerializerSettings.Converters.Add(new IsoDateTimeConverter
            {
                DateTimeStyles = DateTimeStyles.AdjustToUniversal
            });
            sm_SerializerSettings.Formatting = Formatting.Indented;
            sm_SerializerSettings.NullValueHandling = NullValueHandling.Include;
            sm_SerializerSettings.TypeNameHandling = TypeNameHandling.None;
            sm_SerializerSettings.MissingMemberHandling = MissingMemberHandling.Error;
            sm_SerializerSettings.DateTimeZoneHandling = DateTimeZoneHandling.Utc;
            sm_SerializerSettings.DateFormatHandling = DateFormatHandling.IsoDateFormat;
            //sm_SerializerSettings.TypeNameHandling = TypeNameHandling.All;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        public Response()
        {

        }

        /// <summary>
        /// Convert to json with our conversion settings
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static string ToJson(object obj)
        {
            String json = JsonConvert.SerializeObject(obj, sm_SerializerSettings);
            return json;
        }

        /// <summary>
        /// Converts the object into a JSON string
        /// </summary>
        /// <returns></returns>
        public String ToJson()
        {
            String json = JsonConvert.SerializeObject(this, sm_SerializerSettings);
            return json;
        }

        /// <summary>
        /// Serializes the object into a stream in JSON format
        /// </summary>
        /// <returns></returns>
        public Stream Serialize()
        {
            String json = ToJson();

            byte[] data = Encoding.UTF8.GetBytes(json);

            MemoryStream response_stream = null;
            try
            {
                response_stream = new MemoryStream();

                response_stream.Write(data, 0, data.Length);
                response_stream.Position = 0;

                return response_stream;
            }
            catch
            {
                if (response_stream != null)
                {
                    response_stream.Dispose();
                }
                throw;
            }
        }
    }
#if false
    public class GetAppListRequest : Request
    {
        public String groups { get; set; }
    }

    public class GetAppListResponse : Response
    {
        public String appName { get; set; }
        //{KnowledgeWorkers: [{title: "Calculator",…}, {title: "Notepad",…}, {title: "WordPad",…}],…}
//KnowledgeWorkers: [{title: "Calculator",…}, {title: "Notepad",…}, {title: "WordPad",…}]
//MobileWorkers: [{title: "Calculator",…}, {title: "Notepad",…}, {title: "WordPad",…}, {title: "Paint",…},…]
//TaskWorkers: [{title: "Calculator",…}, {title: "Notepad",…}]
    }

    public class AssignUserRequest : Request
    {
        public String username { get; set; }
        public String password { get; set; }
        public String email { get; set; }
        public String config { get; set; }
    }

    public class AssignUserResponse : Response
    {
        public String url { get; set; }

    }

    public class CreateUserRequest : Request
    {
        public String username { get; set; }
        public String password { get; set; }
        public String email { get; set; }
    }

    public class CreateUserResponse : Response
    {
    }

    public class CustomDeskRequest : Request
    {
        public String username { get; set; }
        public String password { get; set; }
        public String email { get; set; }
        public String hardware { get; set; }
        public String os { get; set; }
        public String applications { get; set; }
        public String services { get; set; }


    }

    public class CustomDeskResponse : Response
    {
        public String url { get; set; }

    }

    public class AuthUserRequest : Request
    {
        public String username { get; set; }
        public String password { get; set; }
    }

    public class AuthUserResponse : Response
    {
        public String email { get; set; }
    }
#endif

    public class GenericRequest : Request
    {
        public System.Collections.Hashtable args;

        public override String GetText()
        {
            return base.GetText() +
                   LogFormater.GetHashtableText(args);
        }
    }

    public class GenericResponse : Response
    {
        public System.Collections.Hashtable hashtable;

        public override String GetText()
        {
            return base.GetText() +
                   LogFormater.GetHashtableText(hashtable);
        }
    }
}
