﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Threading.Tasks;

namespace AutomationWebService
{
    [ServiceContract]
    public interface IAutomationWebService
    {
        [OperationContract]
        [WebGet(UriTemplate = "/{*path}")]
        Stream GetFromDisk(string path);

#if false
        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "command/getAppList?requestVersion={requestVersion}",
                   RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        Stream GetAppList(String requestVersion, Stream content);

        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "command/AssignUser?requestVersion={requestVersion}",
                 RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        Stream AssignUser(String requestVersion, Stream content);

        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "command/CreateUser?requestVersion={requestVersion}",
                 RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        Stream CreateUser(String requestVersion, Stream content);

        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "command/CustomDesk?requestVersion={requestVersion}",
                 RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        Stream CustomDesk(String requestVersion, Stream content);

        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "command/AuthUser?requestVersion={requestVersion}",
                 RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        Stream AuthUser(String requestVersion, Stream content);
#endif //
        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "command/Generic?requestVersion={requestVersion}",
                 RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        Stream Generic(String requestVersion, Stream content);
    }
}
