﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EriCommon;
using System.Xml;
using System.IO;

namespace AutomationWebService
{
    public class AppConfig : EriCommon.AppCfg
    {
        private static readonly AppConfig instance;

        private AppConfig() { Settings.Load(); }

        static AppConfig() { instance = new AppConfig(); }

        public static AppConfig Instance
        {
            get { return instance; }
        }

        public static void Init() { }

        protected override void onChanged(FileSystemEventArgs e)
        {
            base.onChanged(e);
            BootstrapSettings.UpdateXmlFile();
        }

    }

    static class BootstrapSettings
    {
        public static void UpdateXmlFile()
        {
            lock (AppCfg.LoadLocker)
            lock (locker) 
            {
                if (!changed)
                    return;

                changed = false;

                string fn = Portal.ScriptsFolderFullPath + "BootStrapSettings.xml";

                XmlDocument doc = new XmlDocument();
                XmlDocument prev = new XmlDocument();

                try { prev.Load(fn); } catch { }

                XmlDeclaration xmldecl = doc.CreateXmlDeclaration("1.0", null, null);

                XmlElement root = doc.DocumentElement;
                doc.InsertBefore(xmldecl, root);

                XmlNode settings = doc.CreateNode("Settings");

                Portal.UpdateXmlFile(settings);
                Email.UpdateXmlFile(settings);
                AD.UpdateXmlFile(settings);
                Connect.UpdateXmlFile(settings);

                if (doc.AsString() == prev.AsString())
                    return;

                doc.Save(fn);

                AppCfg.Logger.Info(String.Format("The file {0} was updated.", fn));
            }
        }

        static object locker = new object();

        static bool changed = true;

        static String EncodePassword(String v, AppCfg.Item item, AppCfg.StringItem key_item)
        {
            lock (locker)
            {
                if (!String.IsNullOrEmpty(v) && !v.IsEnpass())
                {
                    v = v.Enpass(key_item.Value, true);
                    item.Set(v);
                    changed = true;
                }

                return v;
            }
        }

        static void Update(UInt16 v, AppCfg.Item item) 
        {
            lock (locker) { changed = true; }
        }

        static void Update(bool v, AppCfg.Item item)
        {
            lock (locker) { changed = true; }
        }

        static void Update(String v, AppCfg.Item item)
        {
            lock (locker) { changed = true; }
        }

        public static class Portal
        {
            public static void UpdateXmlFile(XmlNode parent)
            {
                settings.Write(parent);
            }

            private static AppCfg.Settings settings = new AppCfg.Settings("PortalSettings");
            public static AppCfg.UInt16Item Port = new AppCfg.UInt16Item(settings, "Port", 2244);
            public static AppCfg.BoolItem Secure = new AppCfg.BoolItem(settings, "Secure", false);
            public static AppCfg.StringItem WebsitePath = new AppCfg.StringItem(settings, "WebsitePath", @"Website\DaaS\");
            public static AppCfg.StringItem FQDN = new AppCfg.StringItem(settings, "FQDN", @"$env:COMPUTERNAME");
            public static AppCfg.StringItem PathToPSFiles = new AppCfg.StringItem(settings, "PathToPSFiles", @"Scripts\");
            public static AppCfg.StringItem AllowedPSFiles = new AppCfg.StringItem(settings, "AllowedPSFiles", @"Assign-User.ps1, Auth-User.ps1, Bootstrap.ps1, Create-User.ps1, Custom-Desk.ps1, Generic.ps1, Get-AppList.ps1");

            static Portal()
            {
                Port.Subscribe(Update);
                Secure.Subscribe(Update);
                WebsitePath.Subscribe(Update);
                FQDN.Subscribe(Update);
                PathToPSFiles.Subscribe(Update);
                AllowedPSFiles.Subscribe(Update);
            }

            public static String ScriptsFolderFullPath
            {
                get
                {
                    string folder = System.IO.Path.GetDirectoryName(new System.Uri(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).LocalPath) + @"\";
                    return folder + PathToPSFiles;
                }
            }
        }

        public static class Email
        {
            public static void UpdateXmlFile(XmlNode parent)
            {
                settings.Write(parent);
            }

            private static AppCfg.Settings settings = new AppCfg.Settings("EmailSettings");
            public static AppCfg.StringItem EmailTemplatePath = new AppCfg.StringItem(settings, "EmailTemplatePath", @"Website\DaaS\emails\ready.html");
            public static AppCfg.StringItem SMTPServer = new AppCfg.StringItem(settings, "SMTPServer", @"");
            public static AppCfg.UInt16Item SMTPPort = new AppCfg.UInt16Item(settings, "SMTPPort", 25);
            public static AppCfg.StringItem SMTPFrom = new AppCfg.StringItem(settings, "SMTPFrom", @"");
            public static AppCfg.StringItem SMTPUsername = new AppCfg.StringItem(settings, "SMTPUsername", @"");
            public static AppCfg.StringItem SMTPPassword = new AppCfg.StringItem(settings, "SMTPPassword", @"");
            public static AppCfg.StringItem ListOfCc = new AppCfg.StringItem(settings, "ListOfCc", @"");
            public static AppCfg.StringItem ListOfBcc = new AppCfg.StringItem(settings, "ListOfBcc", @"");

            static Email()
            {
                EmailTemplatePath.Subscribe(Update);
                SMTPServer.Subscribe(Update);
                SMTPPort.Subscribe(Update);
                SMTPFrom.Subscribe(Update);
                SMTPUsername.Subscribe(ReEncodePassword);
                SMTPPassword.Subscribe(UpdatePassword);
                ListOfCc.Subscribe(Update);
                ListOfBcc.Subscribe(Update);
            }

            static void ReEncodePassword(String v, AppCfg.Item item)
            {
                EncodePassword(v, SMTPPassword, SMTPUsername);
            }

            static void UpdatePassword(String v, AppCfg.Item item)
            {
                EncodePassword(v, item, SMTPUsername);
            }
        }

        public static class AD
        {
            public static void UpdateXmlFile(XmlNode parent)
            {
                settings.Write(parent);
            }

            private static AppCfg.Settings settings = new AppCfg.Settings("ADSettings");
            public static AppCfg.StringItem Domain = new AppCfg.StringItem(settings, "Domain", @"");
            public static AppCfg.StringItem Administrator = new AppCfg.StringItem(settings, "Administrator", @"");
            public static AppCfg.StringItem Password = new AppCfg.StringItem(settings, "Password", @"");
            public static AppCfg.StringItem BaseADGroup = new AppCfg.StringItem(settings, "BaseADGroup", @"");

            static AD()
            {
                Domain.Subscribe(Update);
                Administrator.Subscribe(ReEncodePassword);
                Password.Subscribe(UpdatePassword);
                BaseADGroup.Subscribe(Update);
            }

            static void ReEncodePassword(String v, AppCfg.Item item)
            {
                EncodePassword(v, Password, Administrator);
            }

            static void UpdatePassword(String v, AppCfg.Item item)
            {
                EncodePassword(v, item, Administrator);
            }
        }

        public static class Connect
        {
            public static void UpdateXmlFile(XmlNode parent)
            {
                settings.Write(parent);
            }

            private static AppCfg.Settings settings = new AppCfg.Settings("ConnectSettings");
            public static AppCfg.StringItem EC_AdminUser = new AppCfg.StringItem(settings, "EC_AdminUser", @"");
            public static AppCfg.StringItem EC_AdminPass = new AppCfg.StringItem(settings, "EC_AdminPass", @"");

            static Connect()
            {
                EC_AdminUser.Subscribe(ReEncodePassword);
                EC_AdminPass.Subscribe(UpdatePassword);
            }

            static void ReEncodePassword(String v, AppCfg.Item item)
            {
                EncodePassword(v, EC_AdminPass, EC_AdminUser);
            }

            static void UpdatePassword(String v, AppCfg.Item item)
            {
                EncodePassword(v, item, EC_AdminUser);
            }
        }
    }
}
