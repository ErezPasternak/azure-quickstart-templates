param(
    [bool]$ShowMessageBox = $true,
    [String]$RequestVersion = "",
    [System.Collections.Hashtable]$Data
)


$settingsFile = "BootStrapSettings.xml"
[System.Collections.Hashtable]$BootStrapSettings = New-Object System.Collections.Hashtable
[xml]$XMLBootStrapSettings = (Get-Content $settingsFile)
foreach ($rootNode in $XMLBootStrapSettings.ChildNodes) {
    if($rootNode.NodeType.ToString().Trim() -ne "XmlDeclaration") {
        if ($rootNode.LocalName -eq "Settings") {
            foreach($node in $rootNode.ChildNodes) {
                [System.Collections.Hashtable]$localSettings = New-Object System.Collections.Hashtable
                $node.ChildNodes | ForEach-Object { $localSettings.Add($_.Name, $_.InnerText) }
                $BootStrapSettings.Add($node.LocalName, $localSettings);
            }
        }
    }
}


Function FindAndCreateUserInGroup {
	param(
        [bool]$ShowMessageBox,
		[String]$Username,
		[String]$Password,
		[String]$Email,
        [String]$BaseADGroupRDP
	)

    $nl = [Environment]::NewLine

    if ($ShowMessageBox -eq $true) {
        $res = [System.Windows.Forms.MessageBox]::Show("User : " + $Username + $nl + "Email: " + $Email, "Params" , 4)
        if ($res -ne "Yes") {
            return $null }  }

    $response = $null

    $securePassword = ConvertTo-SecureString -String $Password -AsPlainText -Force	
    $domainName = $BootStrapSettings['ADSettings'].Domain
    $hasError = $false;
    try {
	    New-ADUser -Server $domainName -PasswordNeverExpires $true -SamAccountName $Username -Name $Username -Enabled $true -Verbose -EmailAddress $Email -AccountPassword $securePassword -UserPrincipalName ("$Username" + "@" + "$domainName") -ErrorAction Continue
        Add-ADGroupMember -Server $domainName -Identity (Get-ADGroup -Server $domainName $BaseADGroupRDP) -Members $Username
    } catch  {
        $hasError = $true;
        $HResult = $_.Exception.HResult
        $ErrorMessage = $_.Exception.Message
        $FailedItem = $_.Exception.ItemName
    }
    if ($hasError -eq $false) {
        # OK
        $response = @{
            success = $true
            status = "OK"
            message = "Your account has been created."
            data = @{
                test1 = $true
                test2 = "false"
            }
        }
    } else {
        if ($ErrorMessage -ne "The specified account already exists") {
            # delete account only for any error except when account already exists
            try {
                Remove-ADUser $Username -Server $domainName -Confirm:$false -ErrorAction SilentlyContinue 
            } catch { }
        }
        # problems
        $response = @{
            success = $false
            status = "ERROR"
            message = "$ErrorMessage"
            data = @{
                test3 = $true
                test4 = "false"
            }
        }
    }

    return $response
}


return (FindAndCreateUserInGroup -ShowMessageBox $ShowMessageBox -Username $Data["username"] -Password $Data["-password"] -Email $Data["email"] -BaseADGroupRDP $BootStrapSettings['ADSettings'].BaseADGroup)