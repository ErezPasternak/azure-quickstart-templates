param(
    [bool]$ShowMessageBox = $true,
    [String]$RequestVersion = "",
    [System.Collections.Hashtable]$Data
)


$settingsFile = "BootStrapSettings.xml"
[System.Collections.Hashtable]$BootStrapSettings = New-Object System.Collections.Hashtable
[xml]$XMLBootStrapSettings = (Get-Content $settingsFile)
foreach ($rootNode in $XMLBootStrapSettings.ChildNodes) {
    if($rootNode.NodeType.ToString().Trim() -ne "XmlDeclaration") {
        if ($rootNode.LocalName -eq "Settings") {
            foreach($node in $rootNode.ChildNodes) {
                [System.Collections.Hashtable]$localSettings = New-Object System.Collections.Hashtable
                $node.ChildNodes | ForEach-Object { $localSettings.Add($_.Name, $_.InnerText) }
                $BootStrapSettings.Add($node.LocalName, $localSettings);
            }
        }
    }
}

$adminUser = $BootStrapSettings['ADSettings'].Administrator;
$adminPassword = $BootStrapSettings['ADSettings'].Password;
$groupList = $Data['groups']


Function Start-EricomConnection { 
    $Assem = Import-EricomLib

    $regularUser = New-Object Ericom.CloudConnect.Utilities.SpaceCredentials("regularUser")
    $adminApi = [Ericom.MegaConnect.Runtime.XapApi.AdministrationProcessingUnitClassFactory]::GetInstance($regularUser)
    return $adminApi
}

Function Import-EricomLib {
    $XAPPath = "C:\Program Files\Ericom Software\Ericom Connect Configuration Tool\"

    function Get-ScriptDirectory
    {
        $Invocation = (Get-Variable MyInvocation -Scope 1).Value
        Split-Path $Invocation.MyCommand.Path
    }

    $MegaConnectRuntimeApiDll = Join-Path ($XAPPath)  "MegaConnectRuntimeXapApi.dll"
    $CloudConnectUtilitiesDll = Join-Path ($XAPPath)  "CloudConnectUtilities.dll"


    add-type -Path (
        $MegaConnectRuntimeApiDll,
        $CloudConnectUtilitiesDll
    )
                                                                                                                `
    $Assem = ( 
        $MegaConnectRuntimeApiDll,
        $CloudConnectUtilitiesDll
        )
  
    return $Assem 

}

$adminApi = Start-EricomConnection
$adminSessionId = $adminApi.CreateAdminsession($adminUser, $adminPassword,"rooturl","en-us")
if($groupList.Length -gt 0) { $groups = $groupList.Split(",") } else { $groups = New-Object System.Collections.ArrayList }
[System.Collections.ArrayList]$jsonList = New-Object System.Collections.ArrayList

if ($groups.Count -eq 0) {
    $AppList = $adminApi.ResourceDefinitionSearch($adminSessionId.AdminSessionId,$null,$null)
    foreach ($app in $AppList)
    {
            $RHData = New-Object Ericom.MegaConnect.Runtime.XapApi.ResourceDefinition
            $RHData = $app;

            $Displayname = $RHData.DisplayName;
            $icon = $RHData.DisplayProperties.GetLocalPropertyValue("IconString")
            $resourceId = $RHData.ResourceDefinitionId
            $path = $RHData.Path;
            $remoteAgentId = $RHData.RemoteAgentId

            $resource = @{
            title = $DisplayName
            icon = ("data:image/png;base64," + $icon)
            resourceId = $resourceId
            }
            $jsonList.Add($resource) | Out-Default
    }
    $response = @{
        status = "OK"
        success = $true
        message = "Applications list fetched successfuly"
        data = $jsonList
    }
    return $response  
} else {
    # grab the apps per resource group specified.
    $resources = $adminApi.ResourceGroupSearch($adminSessionId.AdminSessionId, $null, $null, $null)
    $groupDictionary = New-Object "System.Collections.Generic.Dictionary[[System.String],[System.Object]]"
    foreach ($resource in $resources){
        foreach($item in $groups) {
            if($resource.DisplayName -eq $item) {
                [System.Collections.ArrayList]$apps = New-Object System.Collections.ArrayList
                if ($resource.ResourceDefinitionIds.Count -gt 0) {
                    foreach($rdid in $resource.ResourceDefinitionIds) {
                        $item = $adminApi.GetResourceDefinition($adminSessionId.AdminSessionId, $rdid.ToString().Trim());
                        $appDictionary = New-Object "System.Collections.Generic.Dictionary[[System.String],[System.Object]]"
                        try {
                            $appDictionary.Add("title", $item.DisplayName.ToString());
                            $appDictionary.Add("icon", ("data:image/png;base64," + $item.DisplayProperties.GetLocalPropertyValue("IconString").LocalValue.ToString()));
                            $appDictionary.Add("resourceId", $rdid.ToString());
                            $appDictionary.Add("groupName", $resource.DisplayName.ToString());
                            $apps.Add($appDictionary) | Out-Default
                        } catch {
                            
                        }
                    }
                }                    
                $groupDictionary.Add($resource.DisplayName, $apps) | Out-Default
            }
        }
    }
    $response = @{
        status = "OK"
        success = $true
        message = "Applications list fetched successfuly"
        data = $groupDictionary
    }
    return $response  
}
