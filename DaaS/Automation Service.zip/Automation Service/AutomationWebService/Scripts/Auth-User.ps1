param(
    [bool]$ShowMessageBox = $true,
    [String]$RequestVersion = "",
    [System.Collections.Hashtable]$Data
)

$settingsFile = "BootStrapSettings.xml"
[System.Collections.Hashtable]$BootStrapSettings = New-Object System.Collections.Hashtable
[xml]$XMLBootStrapSettings = (Get-Content $settingsFile)
foreach ($rootNode in $XMLBootStrapSettings.ChildNodes) {
    if($rootNode.NodeType.ToString().Trim() -ne "XmlDeclaration") {
        if ($rootNode.LocalName -eq "Settings") {
            foreach($node in $rootNode.ChildNodes) {
                [System.Collections.Hashtable]$localSettings = New-Object System.Collections.Hashtable
                $node.ChildNodes | ForEach-Object { $localSettings.Add($_.Name, $_.InnerText) }
                $BootStrapSettings.Add($node.LocalName, $localSettings);
            }
        }
    }
}


Function Test-ADCredentials {
    param(
		[String]$Username,
		[String]$Password
    )

    $Domain = (Get-ADDomainController).Domain

    if ($ShowMessageBox -eq $true) {
        $res = [System.Windows.Forms.MessageBox]::Show("User : " + $Username, "Data" , 4)
        if ($res -ne "Yes") {
            return $null }  }

    Add-Type -AssemblyName System.DirectoryServices.AccountManagement
    $ct = [System.DirectoryServices.AccountManagement.ContextType]::Domain
    $pc = New-Object System.DirectoryServices.AccountManagement.PrincipalContext $ct, $Domain
    $isValid = ($pc.ValidateCredentials($Username, $Password) | Out-String).ToString().Trim() -eq "True"
    $response = $null
    if ($isValid -eq $true) {
        $email = ((Get-AdUser $Username -Properties EmailAddress | Select EmailAddress).EmailAddress | Out-String).Trim()
        
        $homepage = ""
        try {
            $homepage = ((Get-ADUser $Username  -Properties HomePage | Select HomePage).HomePage | Out-String).Trim()
        } catch { $homepage = "" }

        $response = @{
            status = "OK"
            success = $true
            message = "Authentication OK"
            email = "$email"
        }
        if ($homepage.Length -gt 0) {
            $response.Add("homepage", $homepage)
        }
    } else {
        $response = @{
            status = "ERROR"
            success = $false
            message = "Authentication failed!"
        }
    }
    return $response
}

return (Test-ADCredentials -Username $Data["username"] -Password $Data["-password"])