param(
    [String]$Command = "command"
)

$response = @{
            status = "OK"
            success = $true
            message = "Generic API call"
}

return $response