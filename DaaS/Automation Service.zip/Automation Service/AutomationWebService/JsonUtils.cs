﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomationWebService
{
    public static class JsonUtils
    {
        /// <summary>Desrializes a stream to an object.</summary>
        /// <typeparam name="T">the type of the object to be returned</typeparam>
        /// <param name="content">The content of type T.</param>
        /// <returns>T</returns>
        public static T StringToObject<T>(string content)
        {
            JsonSerializerSettings settings = new JsonSerializerSettings();
            settings.MissingMemberHandling = MissingMemberHandling.Error;
            settings.TypeNameHandling = TypeNameHandling.Auto;

            try
            {
                T obj = Newtonsoft.Json.JsonConvert.DeserializeObject<T>(content, settings);
                return obj;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(string.Format("text was '{0}'", content), ex);
            }
        }
    
        /// <summary>Desrializes a stream to an object.</summary>
        /// <typeparam name="T">the type of the object to be returned</typeparam>
        /// <param name="content">The content of type T.</param>
        /// <param name="text">The content of type T, as text.</param>
        /// <returns>T</returns>
        public static T StreamToObject<T>(Stream content, out string text)
        {
            using (StreamReader streamReader = new StreamReader(content, Encoding.UTF8))
            {
                text = streamReader.ReadToEnd();
            }

            return StringToObject<T>(text);
        }

        /// <summary>Desrializes a stream to an object.</summary>
        /// <typeparam name="T">the type of the object to be returned</typeparam>
        /// <param name="content">The content of type T.</param>
        /// <returns>T</returns>
        public static T StreamToObject<T>(Stream content)
        {
            string text;
            return StreamToObject<T>(content, out text);
        }
    }
}
