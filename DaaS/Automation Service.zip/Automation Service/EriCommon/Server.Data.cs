﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;

using TracerX;

namespace EriCommon
{
    public partial class Server
    {
        /// <summary>
        /// The basic CLIENT service contract
        /// </summary>
        [ServiceContract]
        public interface IService
        {
            /// <summary>
            /// Returns the  features (services) list
            /// </summary>
            [OperationContract]
            [WebGet(UriTemplate = "XML/Features")]
            Features XML_GetFeatures();

            /// <summary>
            /// Returns the  features (services) list
            /// </summary>
            [OperationContract]
            [WebGet(UriTemplate = "JSON/Features", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
            Features GetFeatures();

            /// <summary>
            /// Returns the  build time of the assembly
            /// </summary>
            [OperationContract]
            [WebGet(UriTemplate = "XML/BuiltAt")]
            DateTime XML_GetBuiltAt();

            /// <summary>
            /// Returns the  features (services) list
            /// </summary>
            [OperationContract]
            [WebGet(UriTemplate = "JSON/BuiltAt", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
            DateTime GetBuiltAt();
        }

        /// <summary>
        /// The basic ADMIN service contract
        /// </summary>
        [ServiceContract]
        public interface IAdminService
        {
            // ADMINISTRATIVE OPERATIONS
            /// <summary>
            /// Stops the server
            /// </summary>
            [OperationContract]
            [WebGet(UriTemplate = "XML/Stop?user={user}&pass={pass}&tenant={tenant}&lang={lang}")]
            String XML_StopServer(String user, String pass, String tenant, String lang);

            /// <summary>
            /// Stops the server
            /// </summary>
            [OperationContract]
            [WebGet(UriTemplate = "JSON/Stop?user={user}&pass={pass}&tenant={tenant}&lang={lang}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
            String StopServer(String user, String pass, String tenant, String lang);

            /// <summary>
            /// Pauses the server
            /// </summary>
            [OperationContract]
            [WebGet(UriTemplate = "XML/Pause?user={user}&pass={pass}&tenant={tenant}&lang={lang}")]
            String XML_PauseServer(String user, String pass, String tenant, String lang);

            /// <summary>
            /// Pauses the server
            /// </summary>
            [OperationContract]
            [WebGet(UriTemplate = "JSON/Pause?user={user}&pass={pass}&tenant={tenant}&lang={lang}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
            String PauseServer(String user, String pass, String tenant, String lang);

            /// <summary>
            /// Continues the paused server
            /// </summary>
            [OperationContract]
            [WebGet(UriTemplate = "XML/Continue?user={user}&pass={pass}&tenant={tenant}&lang={lang}")]
            String XML_ContinueServer(String user, String pass, String tenant, String lang);

            /// <summary>
            /// Continues the paused server
            /// </summary>
            [OperationContract]
            [WebGet(UriTemplate = "JSON/Continue?user={user}&pass={pass}&tenant={tenant}&lang={lang}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
            String ContinueServer(String user, String pass, String tenant, String lang);

            /// <summary>
            /// Returns true if the server was paused
            /// </summary>
            [OperationContract]
            [WebGet(UriTemplate = "XML/Paused")]
            bool XML_ServerPaused();

            /// <summary>
            /// Returns true if the server was paused
            /// </summary>
            [OperationContract]
            [WebGet(UriTemplate = "JSON/Paused", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
            bool ServerPaused();
        }

        /// <summary>
        /// The basic ADMIN service contract
        /// </summary>
        [DataContract(Namespace = "", Name = "_Data")]
        public abstract class _Data
        {
            /// <summary>
            /// The LanguageId (as supplied by the client)
            /// </summary>
            [DataMember(Name = "LanguageId")]
            public String LanguageId
            {
                get;
                private set;
            }

            /// <summary>
            /// Sets the LanguageId and Dict
            /// </summary>
            public void SetLanguageId(String language_id)
            {
                Debug.Assert(LanguageId == null);
                Debug.Assert(String.IsNullOrWhiteSpace(language_id) == false);
                LanguageId = language_id.ToUpper();
                RefreshDict();
            }

            /// <summary>
            /// Gets the LanguageId
            /// </summary>
            public String GetLanguageId()
            {
                return (Dict == null) ? LanguageId : Dict.LanguageId;
            }

            /// <summary>
            /// Sets the Dict
            /// </summary>
            public void RefreshDict()
            {
                Dict = Translator.GetDict(LanguageId);

                if (Dict == null)
                    return;

                Debug.Assert(Dict != null);
                LanguageId = Dict.LanguageId;
            }

            /// <summary>
            /// Sets the Dict and LanguageId
            /// </summary>
            public void SetDict(Translator.IDict dict)
            {
                Debug.Assert(LanguageId == null);
                Debug.Assert(dict != null);
                LanguageId = dict.LanguageId;
                Dict = dict;
            }

            /// <summary>
            /// The current dictionary
            /// </summary>
            public Translator.IDict Dict
            {
                get;
                private set;
            }

            /// <summary>
            /// Returns as text
            /// </summary>
            public virtual String GetText(Service service)
            {
                return (!String.IsNullOrWhiteSpace(LanguageId)) ? service.Owner.GetFieldText("Language Id", LanguageId) : "";
            }

            /// <summary>
            /// Returns the object as text for CSV
            /// </summary>
            public abstract String GetCsvDetails(Server.Service service);

            /// <summary>
            /// Returns true if it is a multi-step service
            /// </summary>
            public virtual bool MultiStep
            {
                get { return false; }
            }

            /// <summary>
            /// Returns true if it is a response
            /// </summary>
            public virtual bool IsResponse
            {
                get { return false; }
            }

            /// <summary>
            /// Returns the iteration count (NO ITERATION)
            /// </summary>
            virtual public uint GetIterationCounter()
            {
                return 0;
            }
        }

//         /// <summary>
//         /// The CALL EROR TYPE
//         /// </summary>
//         public enum CallErrorType
//         {
//             /// <summary>
//             /// No error
//             /// </summary>
//             None,
//
//             /// <summary>
//             /// An exception has occured processing the request
//             /// </summary>
//             Exception,
//             //UnsupportedVersion,
//             //NullRequest,
//         }

        /// <summary>
        /// The Request class
        /// </summary>
        [DataContract(Namespace = "", Name = "Request")]
        public abstract class Request : _Data
        {
            /// <summary>
            /// The DEFAULT tenant name
            /// </summary>
            public const String DEFAULT_TENANT_NAME = "DEFAULT";

            /// <summary>
            /// The constructor
            /// </summary>
            public Request(String rid,
                           String tenant_id)
            {
                RID = rid;
                TenantID = tenant_id;
            }

            /// <summary>
            /// Returns as text
            /// </summary>
            public override String GetText(Service service)
            {
                String text = "";

                if (!String.IsNullOrWhiteSpace(RID))
                    text += service.Owner.GetFieldText("RID", RID);
                if (!String.IsNullOrWhiteSpace(TenantID) && TenantID != DEFAULT_TENANT_NAME)
                    text += service.Owner.GetFieldText("Tenant", TenantID);

                return text + base.GetText(service);
            }

            /// <summary>
            /// Casts to MultiStepRequest. Exception will be thrown if it is not a MultiStepRequest
            /// </summary>
            public MultiStepRequest CastToMultiStep
            {
                get { return (MultiStepRequest)this; }
            }

            /// <summary>
            /// The TenantID
            /// </summary>
            [DataMember(Name = "TenantID")]
            public String TenantID
            {
                get;
                protected set;
            }

            /// <summary>
            /// The Request ID (as supplied by the client)
            /// </summary>
            [DataMember(Name = "RID")]
            public String RID
            {
                get;
                private set;
            }

//             /// <summary>
//             /// The CallError reason, null if CallErrorType == CallErrorType.None
//             /// </summary>
//             public String CallError
//             {
//                 get;
//                 set;
//             }

//             /// <summary>
//             /// The CallErrorType
//             /// </summary>
//             public CallErrorType CallErrorType = CallErrorType.None;
        }

        /// <summary>
        /// The MultiStepRequest class
        /// </summary>
        [DataContract(Namespace = "", Name = "MultiStepRequest")]
        public abstract class MultiStepRequest : Request
        {
            /// <summary>
            /// The constructor
            /// </summary>
            public MultiStepRequest(String rid,
                                    String tenant_id,
                                    MultiStepResponse response,
                                    uint? iteration_count = null)
                : base(rid, tenant_id)
            {
                Debug.Assert((response != null && iteration_count == null) || (response == null));
                if (response != null)
                {
                    set_next_step(response);
                }
                else
                {
                    IterationCounter = (iteration_count == null) ? 1 : (uint)iteration_count;
                }
            }

            /// <summary>
            /// Returns as text
            /// </summary>
            public override String GetText(Service service)
            {
                Debug.Assert(service.MultiStep);

                String text = base.GetText(service);

                text += service.Owner.GetFieldText("Iteration Counter", IterationCounter);

                if (MultiStepId != null)
                    text += service.Owner.GetFieldText("MultiStep ID", MultiStepId);

                return text;
            }

            /// <summary>
            /// Returns true
            /// </summary>
            public override bool MultiStep
            {
                get { return true; }
            }

            /// <summary>
            /// Returns true if the MultiStepId is ZEROs
            /// </summary>
            public bool IsFirstStep
            {
                get { return MultiStepId == null; }
            }

            /// <summary>
            /// The MultiStepId property, ZEROs the first time
            /// </summary>
            [DataMember(Name = "MultiStepId")]
            public Guid? MultiStepId
            {
                get;
                private set;
            }

            [DataMember(Name = "IterationCounter")]
            private uint IterationCounter;

            /// <summary>
            /// Returns the IterationCounter property
            /// </summary>
            override public uint GetIterationCounter()
            {
                return IterationCounter;
            }

            void set_next_step(MultiStepResponse response)
            {
                Debug.Assert(response.MultiStepId != null);
                MultiStepId = response.MultiStepId;
                IterationCounter = response.IterationCounter + 1;
            }
        }

        /// <summary>
        /// The Response class
        /// </summary>
        [DataContract(Namespace = "", Name = "Response")]
        public abstract class Response : _Data
        {
            /// <summary>
            /// The default c-tor
            /// NOT TO BE USED!!!!
            /// </summary>
            protected Response(bool assert = true)
            {
                Debug.Assert(!assert);
                STATUS = Status.INTERNAL_ERROR;
            }

            /// <summary>
            /// The DONE c-tor
            /// </summary>
            protected Response(Request request)
            {
                Debug.Assert(request != null);
                STATUS = Status.DONE;
                RID = request.RID;
                SetLanguageId(request.GetLanguageId());
            }

            /// <summary>
            /// The NEXT c-tor
            /// </summary>
            protected Response(Request request, Msg msg)
            {
                Debug.Assert(request != null);
                Debug.Assert(msg.IsMessage());
                STATUS = Status.CONTINUE;
                RID = request.RID;

                // The "new Msg(msg)" fixes a bug!!! Do not touch this!!!
                Message = new Msg(msg);
                SetLanguageId(request.GetLanguageId());
            }

            /// <summary>
            /// The FAILURE constructor
            /// </summary>
            protected Response(Request request,
                               Msg     msg,
                               Status  status)
            {
                Debug.Assert(request != null);
                Debug.Assert(msg.IsError());
                STATUS = status;
                Debug.Assert(FAILURE);
                RID = request.RID;

                // The "new Msg(msg)" fixes a bug!!! Do not touch this!!!
                Message = new Msg(msg);
                SetLanguageId(request.GetLanguageId());
            }

            /// <summary>
            /// The GENERIC FAILURE constructor
            /// </summary>
            protected Response(Request request, Status status, String text)
            {
                STATUS = status;
                Debug.Assert(Status.FAILED > STATUS);
                // The "new Msg(msg)" fixes a bug!!! Do not touch this!!!
                Message = new Msg(new UnivText(String.IsNullOrWhiteSpace(text) ? status.ToString() : text), (int)STATUS);

                if (request != null)
                {
                    RID = request.RID;
                    SetLanguageId(request.GetLanguageId());
                }
            }

            /// <summary>
            /// Returns true if it is a response
            /// </summary>
            public override bool IsResponse
            {
                get { return true; }
            }

            /// <summary>
            /// Returns the service name
            /// </summary>
            [DataMember(Name = "ServiceName")]
            public String ServiceName
            {
                get;
                set;
            }

            /// <summary>
            /// The Msg class
            /// </summary>
            [DataContract(Namespace = "", Name = "Msg")]
            public class Msg
            {
                /// <summary>
                /// The c-tor
                /// </summary>
                public Msg(UnivText text, int id )
                {
                    Debug.Assert(text != null);
                    Debug.Assert(id != INVALID_ID);
                    Text = (text == null) ? null : text.ToString();
                    Debug.Assert(String.IsNullOrWhiteSpace(Text) == false);
                    Id = id;
                }

                /// <summary>
                /// The copy c-tor
                /// </summary>
                public Msg(Msg source)
                {
                    Id = source.Id;
                    Text = source.Text;
                }

                /// <summary>
                /// INVALID_ID
                /// </summary>
                public const int INVALID_ID = 0;
                /// <summary>
                /// CALL_ERROR
                /// </summary>
                public const int CALL_ERROR = int.MinValue;

//                 /// <summary>
//                 /// Returns true if id is null
//                 /// </summary>
//                 public static bool IsNull(int? id)
//                 {
//                     return id == null || INVALID_ID == id;
//                 }

                /// <summary>
                /// Returns true if id is less than 0
                /// </summary>
                public static bool IsError(int id)
                {
                    return INVALID_ID > id;
                }

                /// <summary>
                /// Returns true if id greater than 0
                /// </summary>
                public static bool IsMessage(int id)
                {
                    return INVALID_ID < id;
                }

//                 /// <summary>
//                 /// Returns true if Id less than 0
//                 /// </summary>
//                 public bool IsNull()
//                 {
//                     return IsNull(Id);
//                 }
//
                /// <summary>
                /// Returns true if Id less than 0
                /// </summary>
                public bool IsError()
                {
                    return IsError(Id);
                }

                /// <summary>
                /// Returns the ErrorID as int
                /// </summary>
                public int ErrorID
                {
                    get
                    {
                        Debug.Assert(IsError());
                        return -(Id);
                    }
                }

                /// <summary>
                /// Returns the Id as int
                /// </summary>
                public int MessageID
                {
                    get
                    {
                        Debug.Assert(IsMessage());
                        return Id; //-(Id);
                    }
                }

                /// <summary>
                /// Returns true if MessageId greated than 0
                /// </summary>
                public bool IsMessage()
                {
                    return IsMessage(Id);
                }

                /// <summary>
                /// Returns as text
                /// </summary>
                public String GetText(Service service)
                {
                    String text = "";
                    if (IsMessage())
                    {
                        text += service.Owner.GetFieldText("Msg", Text);
                        text += service.Owner.GetFieldText("Msg ID", service.GetMessageIdText((int)Id));
                    }
                    else
                    {
                        text += service.Owner.GetFieldText("Error", Text);
                        text += service.Owner.GetFieldText("Error ID", service.GetMessageIdText((int)Id));
                    }

                    return text;
                }

                /// <summary>
                /// </summary>
                [DataMember(Name = "Id")]
                public readonly int Id;
                /// <summary>
                /// </summary>
                [DataMember(Name = "Text")]
                public readonly String Text;
            }

            /// <summary>
            /// Casts to MultiStepResponse. Exception will be thrown if it is not a MultiStepResponse
            /// </summary>
            public MultiStepResponse CastToMultiStep
            {
                get { return (MultiStepResponse)this; }
            }

            /// <summary>
            /// Returns as text
            /// </summary>
            public override String GetText(Service service)
            {
                String text = service.Owner.GetFieldText("Status", STATUS);

                if (!String.IsNullOrWhiteSpace(RID))
                    text += service.Owner.GetFieldText("RID", RID);

                if (Message != null)
                    text += Message.GetText(service);

                return text + base.GetText(service);
            }

            /// <summary>
            /// The service return status
            /// </summary>
            public enum Status : int
            {
                // ------------------------- FAILURE --------------------------
                /// <summary>
                /// The service FAILED at application level
                /// </summary>
                FAILED = -1,
                /// <summary>
                /// The service FAILED due to an internal error
                /// </summary>
                INTERNAL_ERROR = -2,
                /// <summary>
                /// The service FAILED due to a forward compatibility issue
                /// </summary>
                UNSUPPORTED_VERSION = -3,
                /// <summary>
                /// The service FAILED because the request is null
                /// </summary>
                NULL_REQUEST = -4,
                /// <summary>
                /// The service FAILED because the request is null
                /// </summary>
                SERVICE_ACCESS_ERROR = -5,

                // ------------------------- SUCCESS --------------------------
                /// <summary>
                /// The service SUCCEEDED
                /// </summary>
                DONE = 1,
                /// <summary>
                /// The service not yet SUCCEEDED, multistep only
                /// </summary>
                CONTINUE = 2,
            }

            /// <summary>
            /// The STATUS is greater than 0
            /// </summary>
            public bool SUCCESS
            {
                get { return 0 < STATUS; }
            }

            /// <summary>
            /// The STATUS is less than 0
            /// </summary>
            public bool FAILURE
            {
                get { return 0 > STATUS; }
            }

            /// <summary>
            /// Should continue (multi-step)
            /// </summary>
            public bool DONE
            {
                get { return STATUS == Status.DONE; }
            }

            /// <summary>
            /// Should continue (multi-step)
            /// </summary>
            public bool NEXT
            {
                get { return STATUS == Status.CONTINUE; }
            }

            /// <summary>
            /// The STATUS attribute
            /// </summary>
            [DataMember(Name = "STATUS")]
            public Status STATUS
            {
                get;
                protected set;
            }

            /// <summary>
            /// The Message attribute, sometimes can be ZERO
            /// </summary>
            [DataMember(Name = "Msg")]
            public Msg Message
            {
                get;
                private set;
            }

            /// <summary>
            /// The Request ID (as supplied by the client)
            /// </summary>
            [DataMember(Name = "RID")]
            public String RID
            {
                get;
                private set;
            }
        }

        /// <summary>
        /// The MultiStepResponse class
        /// </summary>
        [DataContract(Namespace = "", Name = "MultiStepResponse")]
        public abstract class MultiStepResponse : Response
        {
            /// <summary>
            /// The default c-tor
            /// NOT TO BE USED!!!!
            /// </summary>
            protected MultiStepResponse() : base() { }

            /// <summary>
            /// The default c-tor
            /// NOT TO BE USED!!!!
            /// </summary>
            protected MultiStepResponse(Guid multi_step_id, uint iteration_counter) : base(false)
            {
                Set(multi_step_id, iteration_counter);
            }

            /// <summary>
            /// The DONE c-tor
            /// </summary>
            protected MultiStepResponse(MultiStepRequest request) :
                base(request)
            {
                IterationCounter = request.GetIterationCounter();
            }

            /// <summary>
            /// The NEXT c-tor
            /// </summary>
            protected MultiStepResponse(MultiStepRequest request, Msg msg, String step_name, uint timeout_seconds) :
                base(request, msg)
            {
                IterationCounter = request.GetIterationCounter();

                Debug.Assert(String.IsNullOrWhiteSpace(step_name) == false);

                StepName = step_name;
                TimeoutSeconds = timeout_seconds;

                CreationTime = DateTime.Now;
                ExpirationTime = CreationTime;

                if (TimeoutSeconds == 0)
                    return;

                MultiStepId = System.Guid.NewGuid();
                ExpirationTime = ((DateTime)CreationTime).AddSeconds(timeout_seconds);
            }

            /// <summary>
            /// Sets the MultiStepId and IterationCounter
            /// </summary>
            public void Set(Guid multi_step_id, uint iteration_count)
            {
                Debug.Assert(multi_step_id.Equals(Guid.Empty) == false);
                MultiStepId = multi_step_id;
                IterationCounter = iteration_count;
            }

            /// <summary>
            /// Used in NULL_REQUEST case
            /// </summary>
            public const uint NULL_REQUEST_ITERATOR_COUNTER = uint.MaxValue;

            /// <summary>
            /// The FAILURE constructor
            /// </summary>
            protected MultiStepResponse(MultiStepRequest request,
                                        Msg              msg,
                                        Status           status) :
                base(request, msg, status)
            {
                IterationCounter = (request != null) ?  request.GetIterationCounter() :
                                                        NULL_REQUEST_ITERATOR_COUNTER;
            }

            /// <summary>
            /// The GENERIC FAILURE constructor
            /// </summary>
            protected MultiStepResponse(Request request, Status status, String text) :
                base(request, status, text)
            {
            }

            /// <summary>
            /// Returns as text
            /// </summary>
            public override String GetText(Service service)
            {
                String text = base.GetText(service);

                text += service.Owner.GetFieldText("Iteration Counter", IterationCounter);

                if (MultiStepId != null)
                    text += service.Owner.GetFieldText("MultiStep ID", MultiStepId);

                if (String.IsNullOrWhiteSpace(StepName) == false)
                    text += service.Owner.GetFieldText("Step", StepName);

                if (TimeoutSeconds != null && TimeoutSeconds != 0)
                {
                    text += service.Owner.GetFieldText("Timeout Seconds", TimeoutSeconds);
                    text += service.Owner.GetFieldText("Creation Time", CreationTime);
                    text += service.Owner.GetFieldText("Expiration Time", ExpirationTime);
                }

                return text;
            }

            /// <summary>
            /// Returns true
            /// </summary>
            public override bool MultiStep
            {
                get { return true; }
            }

            /// <summary>
            /// The MultiStepId attribute
            /// </summary>
            [DataMember(Name = "MultiStepId")]
            public Guid? MultiStepId
            {
                get;
                private set;
            }

            /// <summary>
            /// The StepName attribute
            /// </summary>
            [DataMember(Name = "StepName")]
            public String StepName
            {
                get;
                private set;
            }

            /// <summary>
            /// The TimeoutSeconds attribute
            /// </summary>
            [DataMember(Name = "TimeoutSeconds")]
            public uint? TimeoutSeconds
            {
                get;
                private set;
            }

            /// <summary>
            /// The CreationTime attribute
            /// </summary>
            [DataMember(Name = "CreationTime")]
            public DateTime? CreationTime
            {
                get;
                private set;
            }

            /// <summary>
            /// The ExpirationTime attribute
            /// </summary>
            [DataMember(Name = "ExpirationTime")]
            public DateTime? ExpirationTime
            {
                get;
                private set;
            }

            /// <summary>
            /// The IterationCounter attribute
            /// </summary>
            [DataMember(Name = "IterationCounter")]
            public uint IterationCounter;

            /// <summary>
            /// Returns the IterationCounter
            /// </summary>
            override public uint GetIterationCounter()
            {
                return IterationCounter;
            }
        }
    }
}
