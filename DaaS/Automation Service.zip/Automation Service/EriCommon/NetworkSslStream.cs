﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Security;
using System.IO;
using System.Net.Sockets;
using System.Diagnostics;
using System.Security.Cryptography.X509Certificates;
using System.Security.Authentication;
using System.Threading;

namespace EriCommon
{
    class NetworkSslStream : SslStream
    {
        private readonly bool                   m_enhanced;
        private readonly NetworkMemoryStream    m_inner_stream;
        private readonly ReadContext            m_read_context;

#if DEBUG
        private bool m_busy_read  = true;   // will be set to false when authenticated
        private bool m_busy_write = true;   // will be set to false when authenticated
#endif //DEBUG

        /// <summary>
        /// The NetworkSslStream constructor.
        /// </summary>
        public NetworkSslStream(Socket socket, bool ownsSocket, bool enhanced = true)
            : base(new NetworkMemoryStream(socket, ownsSocket, enhanced))
        {
            init(enhanced, out m_enhanced, out m_inner_stream, out m_read_context);
        }

        /// <summary>
        /// The NetworkSslStream constructor.
        /// </summary>
        public NetworkSslStream(Socket socket, bool ownsSocket, bool leaveInnerStreamOpen, bool enhanced = true)
            : base(new NetworkMemoryStream(socket, ownsSocket, enhanced), leaveInnerStreamOpen)
        {
            init(enhanced, out m_enhanced, out m_inner_stream, out m_read_context);
        }

        /// <summary>
        /// The NetworkSslStream constructor.
        /// </summary>
        public NetworkSslStream(Socket socket, bool ownsSocket, bool leaveInnerStreamOpen, RemoteCertificateValidationCallback userCertificateValidationCallback, bool enhanced = true)
            : base(new NetworkMemoryStream(socket, ownsSocket, enhanced), leaveInnerStreamOpen, userCertificateValidationCallback)
        {
            init(enhanced, out m_enhanced, out m_inner_stream, out m_read_context);
        }

        /// <summary>
        /// The NetworkSslStream constructor.
        /// </summary>
        public NetworkSslStream(Socket socket, bool ownsSocket, bool leaveInnerStreamOpen, RemoteCertificateValidationCallback userCertificateValidationCallback, LocalCertificateSelectionCallback userCertificateSelectionCallback, bool enhanced = true)
            : base(new NetworkMemoryStream(socket, ownsSocket, enhanced), leaveInnerStreamOpen, userCertificateValidationCallback, userCertificateSelectionCallback)
        {
            init(enhanced, out m_enhanced, out m_inner_stream, out m_read_context);
        }

        /// <summary>
        /// The NetworkSslStream constructor.
        /// </summary>
        public NetworkSslStream(Socket socket, bool ownsSocket, bool leaveInnerStreamOpen, RemoteCertificateValidationCallback userCertificateValidationCallback, LocalCertificateSelectionCallback userCertificateSelectionCallback, EncryptionPolicy encryptionPolicy, bool enhanced = true)
            : base(new NetworkMemoryStream(socket, ownsSocket, enhanced), leaveInnerStreamOpen, userCertificateValidationCallback, userCertificateSelectionCallback, encryptionPolicy)
        {
            init(enhanced, out m_enhanced, out m_inner_stream, out m_read_context);
        }

        private void init(bool enhanced, out bool _enhanced, out NetworkMemoryStream _inner_stream, out ReadContext _read_context)
        {
            _enhanced  = enhanced;
            _inner_stream = (NetworkMemoryStream)InnerStream;

            if (enhanced)
                _read_context = new ReadContext(this);
            else
                _read_context = null;
        }

        public static int GetEncryptedSize(int count)
        {
            return NetworkMemoryStream.GetEncryptedSize(count);
        }

        public void SetWriteBufferSize(int count)
        {
            if (m_enhanced)
                m_inner_stream.SetWriteBufferSize(count, false);
        }

        #region Read overrides

        // We override the Read functions because SslStream will only return maximum of 16 KB (SSL chunk size) in a single read operation.

        /// <summary>
        /// The Read method.
        /// </summary>
        public override int Read(byte[] buffer, int offset, int count)
        {
#if DEBUG
            Debug.Assert(m_busy_read == false);
            m_busy_read = true;
#endif //DEBUG

            int bytesRead = base.Read(buffer, offset, count);

            if (m_enhanced)
            {
                int current_offset  = offset + bytesRead;
                int max_read_offset = offset + count;

                readMore(buffer, current_offset, max_read_offset, ref bytesRead);
            }

#if DEBUG
            Debug.Assert(m_busy_read);
            m_busy_read = false;
#endif //DEBUG

            return bytesRead;
        }

        /// <summary>
        /// The BeginRead method.
        /// </summary>
        public override IAsyncResult BeginRead(byte[] buffer, int offset, int count, AsyncCallback asyncCallback, Object asyncState)
        {
#if DEBUG
            Debug.Assert(m_busy_read == false);
            m_busy_read = true;
#endif //DEBUG

            if (m_enhanced)
            {
                m_read_context.Set(buffer, offset, count, asyncCallback, asyncState);
                base.BeginRead(buffer, offset, count, ReadContext.sm_Callback, m_read_context);
                return m_read_context;
            }
            else
            {
                return base.BeginRead(buffer, offset, count, asyncCallback, asyncState);
            }
        }

        /// <summary>
        /// The EndRead method.
        /// </summary>
        public override int EndRead(IAsyncResult asyncResult)
        {
#if DEBUG
            Debug.Assert(m_busy_read == true);
#endif //DEBUG

            int bytesRead;

            if (m_enhanced)
            {
                Debug.Assert(m_read_context == asyncResult);

                m_read_context.m_event.WaitOne();

                if (m_read_context.m_exception != null)
                    throw m_read_context.m_exception;

                bytesRead = m_read_context.m_bytes_read;
            }
            else
            {
                bytesRead = base.EndRead(asyncResult);
            }

#if DEBUG
            m_busy_read = false;
#endif //DEBUG

            return bytesRead;
        }

        private int onCompletionReadMore()
        {
            int bytesRead = base.EndRead(m_read_context.AsyncResult);

            int current_offset  = m_read_context.m_offset + bytesRead;
            int max_read_offset = m_read_context.m_offset + m_read_context.m_count;

            readMore(m_read_context.m_buffer, current_offset, max_read_offset, ref bytesRead);

            Debug.Assert(bytesRead <= m_read_context.m_count);

            return bytesRead;
        }

        private void readMore(byte[] buffer, int current_offset, int max_read_offset, ref int bytesRead)
        {
            int temp;

//          According to the research of EYAL, the TRY block is unnecessary
//             try
//             {
                while ((current_offset < max_read_offset) && DataAvailable)
                {
                    temp = base.Read(buffer, current_offset, max_read_offset - current_offset);

                    if (temp == 0)
                        break;

                    bytesRead += temp;
                    current_offset += temp;
                }
//             }
//             catch (System.Exception ex)
//             {
//             	if (ex is IOException)
//                     return;
//
//                 throw ex;
//             }
        }

        private bool DataAvailable
        {
            get
            {
                // MSDN:  If DataAvailable is true, a call to Read returns immediately!
                return m_inner_stream.DataAvailable;
            }
        }

        #endregion Read overrides

        #region Write overrides

        // We override the Write functions because SslStream will fragment the buffer into many small writes on the inner stream.

        /// <summary>
        /// The Write method.
        /// </summary>
        public override void Write(byte[] buffer, int offset, int count)
        {
#if DEBUG
            Debug.Assert(m_busy_write == false);
            m_busy_write = true;
#endif //DEBUG

            if (m_enhanced)
            {
                //Console.Write("BeginWrite: {0} ==> ", count);

                m_inner_stream.SetWriteBufferSize(count);
                base.Write(buffer, offset, count);      // SslStream will call m_inner_stream.Write() in a loop, breaking the original buffer to small encrypted chunks. Instead of writing the chunk, m_inner_stream will not just accumulate it into a single buffer.
                m_inner_stream.FlushMemoryToNetwork();  // now synchronously write the accumulated buffer in a single operation.
            }
            else
            {
                base.Write(buffer, offset, count);
            }

#if DEBUG
            Debug.Assert(m_busy_write);
            m_busy_write = false;
#endif //DEBUG
        }

        /// <summary>
        /// The BeginWrite method.
        /// </summary>
        public override IAsyncResult BeginWrite(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
        {
#if DEBUG
            Debug.Assert(m_busy_write == false);
            m_busy_write = true;
#endif //DEBUG

            if (m_enhanced)
            {
                //Console.Write("BeginWrite: {0} ==> ", count);

                m_inner_stream.SetWriteBufferSize(count);
                base.Write(buffer, offset, count);                                  // SslStream will call m_inner_stream.Write() in a loop, breaking the original buffer to small encrypted chunks. Instead of writing the chunk, m_inner_stream will not just accumulate it into a single buffer.
                return m_inner_stream.BeginFlushMemoryToNetwork(callback, state);   // now asynchronously write the accumulated buffer in a single operation.
            }
            else
            {
                return base.BeginWrite(buffer, offset, count, callback, state);
            }
        }

        /// <summary>
        /// The EndWrite method.
        /// </summary>
        public override void EndWrite(IAsyncResult asyncResult)
        {
#if DEBUG
            Debug.Assert(m_busy_write);
#endif //DEBUG

            if (m_enhanced)
            {
                m_inner_stream.EndWrite(asyncResult);
            }
            else
            {
                base.EndWrite(asyncResult);
            }

#if DEBUG
            m_busy_write = false;
#endif //DEBUG
        }

        #endregion Write overrides

        #region Authentication overrides

        // We override the BeginAuthenticateAs() functions because they do not release the asyncState parameter passed to them.

        private class AuthenticateContext : IAsyncResult
        {
            public static AsyncCallback sm_Callback;

            public AuthenticateContext(AsyncCallback asyncCallback, object asyncState)
            {
                m_asyncCallback = asyncCallback;
                m_asyncState = asyncState;
            }

            static AuthenticateContext()
            {
                sm_Callback = new AsyncCallback(Callback);
            }

            private static void Callback(IAsyncResult ar)
            {
                AuthenticateContext me = (AuthenticateContext)ar.AsyncState;
                me.m_ar = ar;
                me.m_asyncCallback(me);
            }

            public IAsyncResult AsyncResult
            {
                get
                {
                    m_asyncCallback = null;
                    m_asyncState    = null;
                    return m_ar;
                }

                set
                {
                    m_ar = value;
                }
            }

            #region IAsyncResult Members

            public object AsyncState
            {
                get { return m_asyncState; }
            }

            public System.Threading.WaitHandle AsyncWaitHandle
            {
                get { return null;/*throw new NotImplementedException();*/ }
            }

            public bool CompletedSynchronously
            {
                get { return (m_ar == null) ? false : m_ar.CompletedSynchronously; }
            }

            public bool IsCompleted
            {
                get { return (m_ar == null) ? false : m_ar.IsCompleted; }
            }

            #endregion

            private AsyncCallback m_asyncCallback;
            private Object m_asyncState;
            private IAsyncResult m_ar = null;
        }

        /// <summary>
        /// The BeginAuthenticateAsServer method.
        /// </summary>
        public override IAsyncResult BeginAuthenticateAsServer(X509Certificate serverCertificate, AsyncCallback asyncCallback, object asyncState)
        {
            AuthenticateContext authenticate_context = new AuthenticateContext(asyncCallback, asyncState);
            IAsyncResult ret = base.BeginAuthenticateAsServer(serverCertificate, AuthenticateContext.sm_Callback, authenticate_context);

            if ((ret is AuthenticateContext) == false)
                authenticate_context.AsyncResult = ret;

            return authenticate_context;
        }

        /// <summary>
        /// The BeginAuthenticateAsServer method.
        /// </summary>
        public override IAsyncResult BeginAuthenticateAsServer(X509Certificate serverCertificate, bool clientCertificateRequired, SslProtocols enabledSslProtocols, bool checkCertificateRevocation, AsyncCallback asyncCallback, object asyncState)
        {
            // note: base class implementation of the first function overload is to call this function
            AuthenticateContext authenticate_context = asyncState is AuthenticateContext ? (AuthenticateContext)asyncState : new AuthenticateContext(asyncCallback, asyncState);
            IAsyncResult ret = base.BeginAuthenticateAsServer(serverCertificate, clientCertificateRequired, enabledSslProtocols, checkCertificateRevocation, AuthenticateContext.sm_Callback, authenticate_context);
            authenticate_context.AsyncResult = ret;

            return authenticate_context;
        }

        /// <summary>
        /// The EndAuthenticateAsServer method.
        /// </summary>
        public override void EndAuthenticateAsServer(IAsyncResult asyncResult)
        {
            AuthenticateContext authenticate_context = (AuthenticateContext)asyncResult;
            base.EndAuthenticateAsServer(authenticate_context.AsyncResult);
#if DEBUG
            on_authenticate();
#endif //DEBUG
        }

        /// <summary>
        /// The BeginAuthenticateAsClient method.
        /// </summary>
        public override IAsyncResult BeginAuthenticateAsClient(string targetHost, AsyncCallback asyncCallback, object asyncState)
        {
            AuthenticateContext authenticate_context = new AuthenticateContext(asyncCallback, asyncState);
            IAsyncResult ret = base.BeginAuthenticateAsClient(targetHost, AuthenticateContext.sm_Callback, authenticate_context);

            if ((ret is AuthenticateContext) == false)
                authenticate_context.AsyncResult = ret;

            return authenticate_context;
        }

        /// <summary>
        /// The BeginAuthenticateAsClient method.
        /// </summary>
        public override IAsyncResult BeginAuthenticateAsClient(string targetHost, X509CertificateCollection clientCertificates, SslProtocols enabledSslProtocols, bool checkCertificateRevocation, AsyncCallback asyncCallback, object asyncState)
        {
            // note: base class implementation of the first function overload is to call this function
            AuthenticateContext authenticate_context = asyncState is AuthenticateContext ? (AuthenticateContext)asyncState : new AuthenticateContext(asyncCallback, asyncState);
            IAsyncResult ret = base.BeginAuthenticateAsClient(targetHost, clientCertificates, enabledSslProtocols, checkCertificateRevocation, AuthenticateContext.sm_Callback, authenticate_context);
            authenticate_context.AsyncResult = ret;

            return authenticate_context;
        }

        /// <summary>
        /// The EndAuthenticateAsClient method.
        /// </summary>
        public override void EndAuthenticateAsClient(IAsyncResult asyncResult)
        {
            AuthenticateContext authenticate_context = (AuthenticateContext)asyncResult;
            base.EndAuthenticateAsClient(authenticate_context.AsyncResult);
#if DEBUG
            on_authenticate();
#endif //DEBUG
        }

#if DEBUG
        void on_authenticate()
        {
            m_busy_read = m_busy_write = false;
        }

        /// <summary>
        /// The AuthenticateAsClient method.
        /// </summary>
        public override void AuthenticateAsClient(string targetHost)
        {
            base.AuthenticateAsClient(targetHost);
            on_authenticate();
        }

        /// <summary>
        /// The AuthenticateAsClient method.
        /// </summary>
        public override void AuthenticateAsClient(string targetHost, X509CertificateCollection clientCertificates, SslProtocols enabledSslProtocols, bool checkCertificateRevocation)
        {
            base.AuthenticateAsClient(targetHost, clientCertificates, enabledSslProtocols, checkCertificateRevocation);
            on_authenticate();
        }

        /// <summary>
        /// The AuthenticateAsServer method.
        /// </summary>
        public override void AuthenticateAsServer(X509Certificate serverCertificate)
        {
            base.AuthenticateAsServer(serverCertificate);
            on_authenticate();
        }

        /// <summary>
        /// The AuthenticateAsServer method.
        /// </summary>
        public override void AuthenticateAsServer(X509Certificate serverCertificate, bool clientCertificateRequired, SslProtocols enabledSslProtocols, bool checkCertificateRevocation)
        {
            base.AuthenticateAsServer(serverCertificate, clientCertificateRequired, enabledSslProtocols, checkCertificateRevocation);
            on_authenticate();
        }

#endif //DEBUG

        #endregion Authentication overrides

        private class NetworkMemoryStream : NetworkStream
        {
            private static readonly int PACKET_SIZE     = 16 * 1024;
            private static readonly int HEADER_SIZE     = 5;
            private static readonly int TRAILER_SIZE    = 36;
            private static readonly int HT_SIZE         = HEADER_SIZE + TRAILER_SIZE;

            private readonly bool m_enhanced;

            private byte[]  m_buffer    = null;
            private int     m_count     = 0;
            private int     m_max_count = 0;

            public NetworkMemoryStream(Socket socket, bool ownsSocket, bool enhanced = true) : base(socket, ownsSocket)
            {
                m_enhanced = enhanced;
                SetWriteBufferSize(PACKET_SIZE, false); // enough for SSL handshake. Call SetWriteBufferSize() after that.
            }

            public void SetWriteBufferSize(int count, bool factor = true)
            {
                if (m_max_count < count)
                {
                    m_max_count = count;

                    int size = GetEncryptedSize(count);

                    if (m_buffer == null || size > m_buffer.Length)
                    {
                        int new_size = factor ? ((size * 3) / 2) : size;
                        m_buffer = new byte[new_size];
                    }
                }
            }

            public static int GetEncryptedSize(int count)
            {
                int packets = (count / PACKET_SIZE) + 1;
                return count + (packets * HT_SIZE) + PACKET_SIZE;
            }

            public void FlushMemoryToNetwork()
            {
                Debug.Assert(m_enhanced);

                int count = m_count;
                m_count = 0;

                //Console.WriteLine(" >>>>> {0} ", count);
                base.Write(m_buffer, 0, count);
            }

            public IAsyncResult BeginFlushMemoryToNetwork(AsyncCallback callback, object state)
            {
                Debug.Assert(m_enhanced);

                int count = m_count;
                m_count = 0;

                //Console.WriteLine(" >>>>> {0} ", count);
                return base.BeginWrite(m_buffer, 0, count, callback, state);
            }

            public override void Write(byte[] buffer, int offset, int count)
            {
                if (m_enhanced == false)
                {
                    base.Write(buffer, offset, count);
                    return;
                }

                //Console.Write("{0} ", count);

                if (m_buffer.Length < m_count + count)
                {
                    Debug.Assert(false);    // should not happen
                    Array.Resize(ref m_buffer, m_count + count);
                }

                Unsafe.MemCpy(buffer,
                              (uint)offset,
                              m_buffer,
                              (uint)m_count,
                              (uint)count);

                m_count += count;
            }
        }

        private class ReadContext : IAsyncResult
        {
            public static AsyncCallback sm_Callback = new AsyncCallback(Callback);

            public ReadContext(NetworkSslStream owner) { m_owner = owner; }

            public void Set(byte[] buffer, int offset, int count, AsyncCallback asyncCallback, object asyncState)
            {
                m_asyncCallback             = asyncCallback;
                m_asyncState                = asyncState;
                m_buffer                    = buffer;
                m_offset                    = offset;
                m_count                     = count;

                m_bytes_read                = 0;
                m_completed                 =
                m_completed_synchronously   = false;
                m_event.Reset();
            }

            private static void Callback(IAsyncResult ar)
            {
                ReadContext me = (ReadContext)ar.AsyncState;
                me.m_ar = ar;

                try
                {
                    me.m_bytes_read = me.m_owner.onCompletionReadMore();
                    me.m_exception = null;
                }
                catch (System.Exception ex)
                {
                    me.m_exception = ex;
                }

                me.m_completed_synchronously = ar.CompletedSynchronously;
                me.m_completed = true;
                me.m_event.Set();

                if (me.m_asyncCallback != null)
                     me.m_asyncCallback(me);
            }

            public IAsyncResult AsyncResult
            {
                get
                {
                    return m_ar;
                }
            }

            #region IAsyncResult Members

            public object AsyncState
            {
                get { return m_asyncState; }
            }

            public System.Threading.WaitHandle AsyncWaitHandle
            {
                get { return m_event; }
            }

            public bool CompletedSynchronously
            {
                get { return m_completed_synchronously; }
            }

            public bool IsCompleted
            {
                get { return m_completed; }
            }

            #endregion

            private readonly NetworkSslStream m_owner;

            public  AsyncCallback   m_asyncCallback = null;
            private Object          m_asyncState    = null;
            public  IAsyncResult    m_ar            = null;

            public Int32            m_offset;
            public Int32            m_count;
            public byte[]           m_buffer;
            public int              m_bytes_read    = 0;

            public Exception        m_exception     = null;
            public ManualResetEvent m_event         = new ManualResetEvent(false);
            public bool             m_completed;
            public bool             m_completed_synchronously;
        }
    }
}
