﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EriCommon
{
    /// <summary>
    /// The OutBlobMsg class.  
    /// </summary>
    public class OutBlobMsg
    {
        /// <summary>
        /// OutBlobMsg CTOR.  
        /// </summary>
        public OutBlobMsg(UInt32 version)
        {
            Write(version);
        }

        /// <summary>
        /// Returns the blob.  
        /// </summary>
        public String Blob
        {
            get { return m_blob;  }
        }

        /// <summary>
        /// Writes a string.  
        /// </summary>
        public void WriteString(String val)
        {
            Write(val);
        }

        /// <summary>
        /// Writes a bool.  
        /// </summary>
        public void WriteBool(bool val)
        {
            Write(val);
        }

        /// <summary>
        /// Writes an int.  
        /// </summary>
        public void WriteInt32(Int32 val)
        {
            Write(val);
        }

        /// <summary>
        /// Writes an uint.  
        /// </summary>
        public void WriteUInt32(UInt32 val)
        {
            Write(val);
        }

        /// <summary>
        /// Writes an int.  
        /// </summary>
        public void WriteInt64(Int64 val)
        {
            Write(val);
        }

        /// <summary>
        /// Writes an uint.  
        /// </summary>
        public void WriteUInt64(UInt64 val)
        {
            Write(val);
        }

        /// <summary>
        /// Writes a string.  
        /// </summary>
        public void Write(String val)
        {
            m_blob += (val.Length.ToString().Length.ToString() + val.Length.ToString() + val);
        }

        /// <summary>
        /// Writes a bool.  
        /// </summary>
        public void Write(bool val)
        {
            Write((val) ? "1" : "0");
        }

        /// <summary>
        /// Writes an int.  
        /// </summary>
        public void Write(Int32 val)
        {
            Write(val.ToString());
        }

        /// <summary>
        /// Writes an uint.  
        /// </summary>
        public void Write(UInt32 val)
        {
            Write(val.ToString());
        }

        /// <summary>
        /// Writes an int.  
        /// </summary>
        public void Write(Int64 val)
        {
            Write(val.ToString());
        }

        /// <summary>
        /// Writes an uint.  
        /// </summary>
        public void Write(UInt64 val)
        {
            Write(val.ToString());
        }

        /// <summary>
        /// Writes an enum.  
        /// </summary>
        public void WriteEnum(Int32 val)
        {
            Write(val);
        }

        /// <summary>
        /// the blob.  
        /// </summary>
        protected String m_blob;
    }

    /// <summary>
    /// The OutBlobMsg class.  
    /// </summary>
    public class InBlobMsg
    {
        /// <summary>
        /// OutBlobMsg CTOR.  
        /// </summary>
        public InBlobMsg(String blob)
        {
            m_blob = blob;
            Read(out m_version);
        }

        /// <summary>
        /// Returns the blob.  
        /// </summary>
        public UInt32 Version
        {
            get { return m_version; }
        }

        public Int32 Length
        {
            get { return m_blob.Length; }
        }

        /// <summary>m_version
        /// Read a string.  
        /// </summary>
        public String ReadString()
        {
            String val;
            return Read(out val);
        }

        /// <summary>
        /// Read a bool.  
        /// </summary>
        public bool ReadBool()
        {
            bool val;
            return Read(out val);
        }

        /// <summary>
        /// Read a Int32.  
        /// </summary>
        public Int32 ReadInt32()
        {
            Int32 val;
            return Read(out val);
        }

        /// <summary>
        /// Read a UInt32.  
        /// </summary>
        public UInt32 ReadUInt32()
        {
            UInt32 val;
            return Read(out val);
        }

        /// <summary>
        /// Read a Int64.  
        /// </summary>
        public Int64 ReadInt64()
        {
            Int64 val;
            return Read(out val);
        }

        /// <summary>
        /// Read a UInt64.  
        /// </summary>
        public UInt64 ReadUInt64()
        {
            UInt64 val;
            return Read(out val);
        }

        /// <summary>
        /// Read a string.  
        /// </summary>
        public String Read(out String val)
        {
            int read_pos = 0;

            Int32 len_num_digits = Int32.Parse(m_blob.Substring(read_pos, 1));
            read_pos++;

            Int32 len = Int32.Parse(m_blob.Substring(read_pos, len_num_digits));
            read_pos += len_num_digits;

            val = m_blob.Substring(read_pos, len);
            read_pos += len;

#if DEBUG
            Console.WriteLine("[{0}][{1}][{2}]", len_num_digits, len, val);
#endif
            m_blob = m_blob.Remove(0, read_pos);

            return val;
        }

        /// <summary>
        /// Read a bool.  
        /// </summary>
        public bool Read(out bool val)
        {
            String temp;
            Read(out temp);

            if (temp == "1") { val = true; return val; }
            if (temp == "0") { val = true; return val; }

            throw new Exception( String.Format( "Invalid bool value '{0}'", temp) );
        }

        /// <summary>
        /// Read an int.  
        /// </summary>
        public Int32 Read(out Int32 val)
        {
            String temp;
            Read(out temp);
            val = Int32.Parse(temp);
            return val;
        }

        /// <summary>
        /// Read an uint.  
        /// </summary>
        public UInt32 Read(out UInt32 val)
        {
            String temp;
            Read(out temp);
            val = UInt32.Parse(temp);
            return val;
        }

        /// <summary>
        /// Read an Int64.  
        /// </summary>
        public Int64 Read(out Int64 val)
        {
            String temp;
            Read(out temp);
            val = Int64.Parse(temp);
            return val;
        }

        /// <summary>
        /// Read an UInt64.  
        /// </summary>
        public UInt64 Read(out UInt64 val)
        {
            String temp;
            Read(out temp);
            val = UInt64.Parse(temp);
            return val;
        }

        /// <summary>
        /// Read an enum.  
        /// </summary>
        public Int32 ReadEnum()
        {
            Int32 val;
            return Read(out val);
        }

        /// <summary>
        /// the blob.  
        /// </summary>
        protected String m_blob;
        /// <summary>
        /// the version.  
        /// </summary>
        protected UInt32 m_version;
    }
}
