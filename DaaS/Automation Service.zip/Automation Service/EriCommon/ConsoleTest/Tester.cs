﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using TracerX;
using EriCommon;

using System.Configuration;
using System.Net.Sockets;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;

namespace ConsoleTest
{
    class Tester
    {
        public static void Main(string[] args)
        {
            // EXAMPLE: You must call this method at the beginning of your Main function
            ThreadHelper.SetMainThreadName();

            // EXAMPLE: Open the LOGGING 'service'
            LogHelper.OpenServiceLog();

            // EXAMPLE: Make your Main implementation safe.
            SafeCall.Run(main, args);

            Console.ReadKey();
        }

        static void main(object stam)
        {
//             IndexOf.Test_05_CompareUnsafeSafe();
//             IndexOf.Test_06_CompareUnsafeWithSearchMark();
//             CopyArray.Test_05_CompareUnsafeSafe();

            try
            {
                ReadHttpHeader.CompareTcp();
                ReadHttpHeader.CompareSsl();
                ReadHttpHeader.CompareSslEx();
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.AllMessages());
                throw ex;
            }
        }
    }

    static class ReadHttpHeader
    {
        public static void CompareTcp()
        {
            TcpListener tcp_listener = new TcpListener(IPAddress.Loopback, 0);
            tcp_listener.Start();
            int port = ((IPEndPoint)tcp_listener.LocalEndpoint).Port;

            IAsyncResult accept_result = tcp_listener.BeginAcceptTcpClient(null,null);

            TcpClient client = new TcpClient("localhost", port);
            TcpClient server = tcp_listener.EndAcceptTcpClient(accept_result);

            NetworkStream client_stream = client.GetStream();
            NetworkStream server_stream = server.GetStream();

            const int n_lines = 16;
            byte[] line = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 13, 10 };
            int header_length = line.Length * n_lines;
            byte[] http_header = new byte[header_length];

            int cnt;

            for (cnt = 0; cnt < n_lines; cnt++)
                Unsafe.MemCpy(line, 0, http_header, (uint)(cnt * line.Length), (uint)line.Length);

            const int MEGA = 1024 * 1024;
            int n_packets = MEGA / header_length;

            byte[] headers = new byte[header_length * n_packets];
            for (cnt = 0; cnt < n_packets; cnt++)
                Unsafe.MemCpy(http_header, 0, headers, (uint)(cnt * header_length), (uint)header_length);

            DateTime start_time;

            // Test reading chuncks

            // Send
            client_stream.Write(headers, 0, headers.Length);

            // Receive
            start_time = DateTime.Now;

            for (cnt = 0; cnt < n_packets; cnt++)
                server_stream.Read(http_header, 0, header_length);

            TimeSpan fast_elapsed = DateTime.Now.Subtract(start_time);

            // Test reading byte by byte

            // Send
            client_stream.Write(headers, 0, headers.Length);

            // Receive
            start_time = DateTime.Now;

            for (cnt = 0; cnt < n_packets; cnt++)
                for (int cnt_byte = 0; cnt_byte < header_length; cnt_byte++ )
                    server_stream.Read(http_header, cnt_byte, 1);

            TimeSpan slow_elapsed = DateTime.Now.Subtract(start_time);

            Int64 fast_elapsed_ticks = fast_elapsed.Ticks,
                  slow_elapsed_ticks = slow_elapsed.Ticks;

            double percent = (double)fast_elapsed_ticks * 100 / slow_elapsed_ticks;

            Console.WriteLine(String.Format("TCP: Percent={0:00.000}, Fast={1,4}, Slow={2,4}", percent, fast_elapsed_ticks / 10000, slow_elapsed_ticks / 10000));
        }

        private static bool CertificateValidationCallback(object sender,
                                                          X509Certificate certificate,
                                                          X509Chain chain,
                                                          SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }

        private static RemoteCertificateValidationCallback sm_CertificateValidationCallback = new RemoteCertificateValidationCallback(CertificateValidationCallback);

        public static void CompareSsl()
        {
            TcpListener tcp_listener = new TcpListener(IPAddress.Loopback, 0);
            tcp_listener.Start();
            int port = ((IPEndPoint)tcp_listener.LocalEndpoint).Port;

            IAsyncResult tcp_accept_result = tcp_listener.BeginAcceptTcpClient(null, null);

            TcpClient client = new TcpClient("localhost", port);
            TcpClient server = tcp_listener.EndAcceptTcpClient(tcp_accept_result);

            NetworkStream tcp_client_stream = client.GetStream();
            NetworkStream tcp_server_stream = server.GetStream();

            SslStream client_stream = new SslStream(tcp_client_stream, false, sm_CertificateValidationCallback);
            SslStream server_stream = new SslStream(tcp_server_stream, false, sm_CertificateValidationCallback);

            X509Certificate2 new_cert = CertificateManager.Instance.LoadOrGenerateCertificate();

            IAsyncResult ssl_accept_result = server_stream.BeginAuthenticateAsServer(new_cert, null, null);
            IAsyncResult ssl_connect_result = client_stream.BeginAuthenticateAsClient("YochaiG.ericom.local", null, null);
            server_stream.EndAuthenticateAsServer(ssl_accept_result);
            client_stream.EndAuthenticateAsClient(ssl_connect_result);

            const int n_lines = 16;
            byte[] line = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 13, 10 };
            int header_length = line.Length * n_lines;
            byte[] http_header = new byte[header_length];

            int cnt;

            for (cnt = 0; cnt < n_lines; cnt++)
                Unsafe.MemCpy(line, 0, http_header, (uint)(cnt * line.Length), (uint)line.Length);

            const int MEGA = 1024 * 1024 / 16;
            int n_packets = MEGA / header_length;

            byte[] headers = new byte[header_length * n_packets];
            for (cnt = 0; cnt < n_packets; cnt++)
                Unsafe.MemCpy(http_header, 0, headers, (uint)(cnt * header_length), (uint)header_length);

            DateTime start_time;

            // Test reading chuncks

            // Receive
            start_time = DateTime.Now;

            for (cnt = 0; cnt < n_packets; cnt++)
            {
                client_stream.Write(headers, 0, header_length);
                server_stream.Read(http_header, 0, header_length);
            }

            TimeSpan fast_elapsed = DateTime.Now.Subtract(start_time);

            // Test reading byte by byte

            // Receive
            start_time = DateTime.Now;

            for (cnt = 0; cnt < n_packets; cnt++)
            {
                client_stream.Write(headers, 0, header_length);
                for (int cnt_byte = 0; cnt_byte < header_length; cnt_byte++)
                    server_stream.Read(http_header, cnt_byte, 1);
            }

            TimeSpan slow_elapsed = DateTime.Now.Subtract(start_time);

            Int64 fast_elapsed_ticks = fast_elapsed.Ticks,
                  slow_elapsed_ticks = slow_elapsed.Ticks;

            double percent = (double)fast_elapsed_ticks * 100 / slow_elapsed_ticks;

            Console.WriteLine(String.Format("SSL: Percent={0:00.000}, Fast={1,4}, Slow={2,4}", percent, fast_elapsed_ticks / 10000, slow_elapsed_ticks / 10000));
//            Console.WriteLine(String.Format("SSL: Percent={0,3}, Fast={1,4}, Slow={2,4}", percent, fast_elapsed_ticks / 10000, slow_elapsed_ticks / 10000));
        }

        public static void CompareSslEx()
        {
            TcpListener tcp_listener = new TcpListener(IPAddress.Loopback, 0);
            tcp_listener.Start();
            int port = ((IPEndPoint)tcp_listener.LocalEndpoint).Port;

            IAsyncResult tcp_accept_result = tcp_listener.BeginAcceptTcpClient(null, null);

            TcpClient client = new TcpClient("localhost", port);
            TcpClient server = tcp_listener.EndAcceptTcpClient(tcp_accept_result);

            NetworkStream tcp_client_stream = client.GetStream();
            NetworkStream tcp_server_stream = server.GetStream();

            SslStreamEx client_stream = new SslStreamEx(tcp_client_stream, false, sm_CertificateValidationCallback);
            SslStreamEx server_stream = new SslStreamEx(tcp_server_stream, false, sm_CertificateValidationCallback);

            X509Certificate2 new_cert = CertificateManager.Instance.LoadOrGenerateCertificate();

            IAsyncResult ssl_accept_result = server_stream.BeginAuthenticateAsServer(new_cert, null, null);
            IAsyncResult ssl_connect_result = client_stream.BeginAuthenticateAsClient("YochaiG.ericom.local", null, null);
            client_stream.EndAuthenticateAsClient(ssl_connect_result);
            server_stream.EndAuthenticateAsServer(ssl_accept_result);

            const int n_lines = 16;
            byte[] line = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 13, 10 };
            int header_length = line.Length * n_lines;
            byte[] http_header = new byte[header_length];

            int cnt;

            for (cnt = 0; cnt < n_lines; cnt++)
                Unsafe.MemCpy(line, 0, http_header, (uint)(cnt * line.Length), (uint)line.Length);

            const int MEGA = 1024 * 1024;
            int n_packets = MEGA / header_length;

            byte[] headers = new byte[header_length * n_packets];
            for (cnt = 0; cnt < n_packets; cnt++)
                Unsafe.MemCpy(http_header, 0, headers, (uint)(cnt * header_length), (uint)header_length);

            DateTime start_time;

            // Test reading chuncks

            // Receive
            start_time = DateTime.Now;

            client_stream.Write(headers, 0, headers.Length);

            for (cnt = 0; cnt < n_packets; cnt++)
            {
                server_stream.Read(http_header, 0, header_length);
            }

            TimeSpan fast_elapsed = DateTime.Now.Subtract(start_time);

            // Test reading byte by byte

            // Receive
            start_time = DateTime.Now;

            client_stream.Write(headers, 0, headers.Length);
            for (cnt = 0; cnt < n_packets; cnt++)
            {
//                client_stream.Write(headers, 0, header_length);
                for (int cnt_byte = 0; cnt_byte < header_length; cnt_byte++)
                    server_stream.Read(http_header, cnt_byte, 1);
            }

            TimeSpan slow_elapsed = DateTime.Now.Subtract(start_time);

            Int64 fast_elapsed_ticks = fast_elapsed.Ticks,
                  slow_elapsed_ticks = slow_elapsed.Ticks;

            double percent = (double)fast_elapsed_ticks * 100 / slow_elapsed_ticks;

            Console.WriteLine(String.Format("EX!: Percent={0:00.000}, Fast={1,4}, Slow={2,4}", percent, fast_elapsed_ticks / 10000, slow_elapsed_ticks / 10000));
//            Console.WriteLine(String.Format("EX!: Percent={0,3}, Fast={1,4}, Slow={2,4}", percent, fast_elapsed_ticks / 10000, slow_elapsed_ticks / 10000));
        }
    }

    static class IndexOf
    {
        const int max_factor = 1024 * 64;
        const int multiply_factor = 5;

        public static void Test_05_CompareUnsafeSafe()
        {
            Console.WriteLine("Compare UNSAFE & SAFE");
            for (int factor = 1; factor <= max_factor; factor *= 2)
                CompareUnsafeSafe(factor);
            Console.WriteLine("Done!\n");
        }

        static void CompareUnsafeSafe(int factor)
        {
            factor *= multiply_factor;

            byte[] pattern = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 13, 10 };
            byte[] terminator = new byte[] { 13, 10 };
            byte[] http_header = new byte[(pattern.Length * factor) + 128];

            int cnt;

            for (cnt = 0; cnt < factor; cnt++)
                Unsafe.MemCpy(pattern, 0, http_header, (uint)(cnt * pattern.Length), (uint)pattern.Length);

            byte[] http_header_terminator = new byte[] { 13, 10, 13, 10 };
            Unsafe.MemCpy(terminator, 0, http_header, (uint)(cnt * pattern.Length), (uint)terminator.Length);

            int retval;
            int expected = (factor * pattern.Length) - 2;

            retval = http_header.IndexOf(http_header_terminator);
            Debug.Assert(retval == expected);
            retval = Unsafe.IndexOf(http_header, http_header_terminator);
            Debug.Assert(retval == expected);

            int max_tests = (1024 * 1024) / factor;

            DateTime start_time;
            start_time = DateTime.Now;

            for (int count = 0; count < max_tests; count++)
                retval = http_header.IndexOf(http_header_terminator);

            TimeSpan safe_elapsed = DateTime.Now.Subtract(start_time);

            start_time = DateTime.Now;

            for (int count = 0; count < max_tests; count++)
                retval = Unsafe.IndexOf(http_header, http_header_terminator);

            TimeSpan unsafe_elapsed = DateTime.Now.Subtract(start_time);

            Int64 safe_elapsed_ticks = safe_elapsed.Ticks,
                  unsafe_elapsed_ticks = unsafe_elapsed.Ticks;

            Int64 delta = unsafe_elapsed_ticks - safe_elapsed_ticks;
            Int64 percent = unsafe_elapsed_ticks * 100 / safe_elapsed_ticks;

            Console.WriteLine(String.Format("Lines={0}, Percent={1}, Unsafe={2}, Safe={3}", factor, percent, unsafe_elapsed_ticks, safe_elapsed_ticks));
        }

        public static void Test_06_CompareUnsafeWithSearchMark()
        {
            Console.WriteLine("Compare UNSAFE & SearchMark");
            for (int factor = 1; factor <= max_factor; factor *= 2)
                CompareUnsafeWithSearchMark(factor);
            Console.WriteLine("Done!\n");
        }

        static void CompareUnsafeWithSearchMark(int factor)
        {
            factor *= multiply_factor;

            byte[] pattern = new byte[] { 1, 3, 2, 4, 5, 6, 7, 8, 9, 0, 6, 2, 43, 1, 4, 13, 10 };
            byte[] terminator = new byte[] { 13, 10, 7, 7, 8, 99 };
            byte[] http_header = new byte[(pattern.Length * factor) + 128];

            int cnt;

            for (cnt = 0; cnt < factor; cnt++)
                Unsafe.MemCpy(pattern, 0, http_header, (uint)(cnt * pattern.Length), (uint)pattern.Length);

            byte[] http_header_terminator = new byte[] { 13, 10, 13, 10 };
            Unsafe.MemCpy(terminator, 0, http_header, (uint)(cnt * pattern.Length), (uint)terminator.Length);

            int retval;
            int expected = (factor * pattern.Length) - 2;

            retval = SearchMark(http_header, 0, http_header.Length, http_header_terminator);
            Debug.Assert(retval == expected);
            retval = Unsafe.IndexOf(http_header, http_header_terminator);
            Debug.Assert(retval == expected);

            int max_tests = (1024 * 1024) / factor;

            DateTime start_time;
            start_time = DateTime.Now;

            for (int count = 0; count < max_tests; count++)
                retval = SearchMark(http_header, 0, http_header.Length, http_header_terminator);

            TimeSpan safe_elapsed = DateTime.Now.Subtract(start_time);

            start_time = DateTime.Now;

            for (int count = 0; count < max_tests; count++)
                retval = Unsafe.IndexOf(http_header, http_header_terminator);

            TimeSpan unsafe_elapsed = DateTime.Now.Subtract(start_time);

            Int64 safe_elapsed_ticks = safe_elapsed.Ticks,
                  unsafe_elapsed_ticks = unsafe_elapsed.Ticks;

            Int64 delta = unsafe_elapsed_ticks - safe_elapsed_ticks;
            Int64 percent = unsafe_elapsed_ticks * 100 / safe_elapsed_ticks;

            Console.WriteLine(String.Format("Lines={0}, Percent={1}, Unsafe={2}, Safe={3}", factor, percent, unsafe_elapsed_ticks, safe_elapsed_ticks));
        }

        static public int SearchMark(byte[] source, int offset, int length, byte[] mark)
        {
            int pos = offset;
            int endOffset = offset + length - 1;
            int matchCount = 0;

            while (true)
            {
                pos = Array.IndexOf(source, mark[0], pos, length - pos + offset);

                if (pos < 0)
                    return -1;

                matchCount = 1;

                for (int i = 1; i < mark.Length; i++)
                {
                    int checkPos = pos + i;

                    if (checkPos > endOffset)
                    {
                        //found end, return matched chars count
                        return (0 - i);
                    }

                    if (!source[checkPos].Equals(mark[i]))
                        break;

                    matchCount++;
                }

                if (matchCount == mark.Length)
                    return pos;

                //Reset next round read pos
                pos += matchCount;
                //clear matched chars count
                matchCount = 0;
            }
        }
    }

    static class CopyArray
    {
        const int max_factor = 1024 * 1024;
        const int multiply_factor = 32;
        const int shift_left_by = 1;
        static byte[] buffer_1 = new byte[64 * 1024 * 1024];
        static byte[] buffer_2 = new byte[64 * 1024 * 1024];

        public static void Test_05_CompareUnsafeSafe()
        {
            Console.WriteLine("Two different buffers:");
            for (int factor = 1; factor <= max_factor; factor <<= shift_left_by)
                CompareUnsafeSafe(factor);
            Console.WriteLine("-----------------------------------------------------------");

            Console.WriteLine("Overlapping, shifting left:\n");
            for (int factor = 1; factor <= max_factor; factor <<= shift_left_by)
                CompareUnsafeSafe_ShiftLeft(factor);
            Console.WriteLine("-----------------------------------------------------------");

            Console.WriteLine("Overlapping, shifting right:\n");
            for (int factor = 1; factor <= max_factor; factor <<= shift_left_by)
                CompareUnsafeSafe_ShiftRight(factor);
        }

        static void CompareUnsafeSafe(int factor)
        {
            factor *= multiply_factor;

            int max_tests = ((1024 * 1024 * 1024) / factor) * 4;

            DateTime start_time;
            start_time = DateTime.Now;

            for (int count = 0; count < max_tests; count++)
                Array.Copy(buffer_1, 0, buffer_2, 0, factor);

            TimeSpan safe_elapsed = DateTime.Now.Subtract(start_time);

            start_time = DateTime.Now;

            for (int count = 0; count < max_tests; count++)
                Unsafe.MemCpy(buffer_1, 0, buffer_2, 0, (uint)factor);

            TimeSpan unsafe_elapsed = DateTime.Now.Subtract(start_time);

            Int64 safe_elapsed_ticks = safe_elapsed.Ticks,
                  unsafe_elapsed_ticks = unsafe_elapsed.Ticks;

            Int64 delta = unsafe_elapsed_ticks - safe_elapsed_ticks;
            Int64 percent = unsafe_elapsed_ticks * 100 / safe_elapsed_ticks;

            Console.WriteLine(String.Format("Length={0,8}, Percent={1,3}, Unsafe={2,4}, Safe={3,4}", factor, percent, unsafe_elapsed_ticks / 10000, safe_elapsed_ticks / 10000));
        }

        static void CompareUnsafeSafe_ShiftLeft(int factor)
        {
            factor *= multiply_factor;

            byte[] buffer = buffer_1;

            int max_tests = ((1024 * 1024 * 1024) / factor) * 4;

            DateTime start_time;
            start_time = DateTime.Now;

            for (int count = 0; count < max_tests; count++)
                Array.Copy(buffer, factor / 2, buffer, 0, factor);

            TimeSpan safe_elapsed = DateTime.Now.Subtract(start_time);

            start_time = DateTime.Now;

            for (int count = 0; count < max_tests; count++)
                Unsafe.MemCpy(buffer, (uint)(factor / 2), buffer, 0, (uint)factor);

            TimeSpan unsafe_elapsed = DateTime.Now.Subtract(start_time);

            Int64 safe_elapsed_ticks = safe_elapsed.Ticks,
                  unsafe_elapsed_ticks = unsafe_elapsed.Ticks;

            Int64 delta = unsafe_elapsed_ticks - safe_elapsed_ticks;
            Int64 percent = unsafe_elapsed_ticks * 100 / safe_elapsed_ticks;

            Console.WriteLine(String.Format("Length={0,8}, Percent={1,3}, Unsafe={2,4}, Safe={3,4}", factor, percent, unsafe_elapsed_ticks / 10000, safe_elapsed_ticks / 10000));
        }

        static void CompareUnsafeSafe_ShiftRight(int factor)
        {
            factor *= multiply_factor;

            byte[] buffer = buffer_1;

            int max_tests = ((1024 * 1024 * 1024) / factor) * 4;

            DateTime start_time;
            start_time = DateTime.Now;

            for (int count = 0; count < max_tests; count++)
                Array.Copy(buffer, 0, buffer, factor / 2, factor);

            TimeSpan safe_elapsed = DateTime.Now.Subtract(start_time);

            start_time = DateTime.Now;

            for (int count = 0; count < max_tests; count++)
                Unsafe.MemCpy(buffer, 0, buffer, (uint)(factor / 2), (uint)factor);

            TimeSpan unsafe_elapsed = DateTime.Now.Subtract(start_time);

            Int64 safe_elapsed_ticks = safe_elapsed.Ticks,
                  unsafe_elapsed_ticks = unsafe_elapsed.Ticks;

            Int64 delta = unsafe_elapsed_ticks - safe_elapsed_ticks;
            Int64 percent = unsafe_elapsed_ticks * 100 / safe_elapsed_ticks;

            Console.WriteLine(String.Format("Length={0,8}, Percent={1,3}, Unsafe={2,4}, Safe={3,4}", factor, percent, unsafe_elapsed_ticks / 10000, safe_elapsed_ticks / 10000));
        }
    }
}
