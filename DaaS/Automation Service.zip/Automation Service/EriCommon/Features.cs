﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Runtime.Serialization;

namespace EriCommon
{
    /// <summary>
    /// The Features class
    /// </summary>
    [DataContract(Namespace = "", Name = "Features")]
    public class Features
    {
        /// <summary>
        /// The default c-tor
        /// </summary>
        public Features()
        {
            m_items = new SortedList<String, UInt32>();
        }

        /// <summary>
        /// The copy c-tor
        /// </summary>
        public Features(Features other)
        {
            m_items = new SortedList<String, UInt32>(other.m_items);
        }

        /// <summary>
        /// Adds a feature
        /// </summary>
        public void Add(String name, UInt32 version = 0)
        {
            m_items.Add(name, version);
        }

        /// <summary>
        /// Returns true if the feature exists and the it's version is equal or greater than minimum_version
        /// </summary>
        public bool IsSupported(String name, out UInt32 current_version, UInt32 minimum_version = 0)
        {
            return m_items.TryGetValue(name, out current_version) &&
                   current_version >= minimum_version;
        }

        /// <summary>
        /// Returns true if the feature exists and the it's version is equal or greater than minimum_version
        /// </summary>
        public bool IsSupported(String name, UInt32 minimum_version = 0)
        {
            UInt32 current_version;
            return IsSupported(name, out current_version, minimum_version);
        }

        /// <summary>
        /// Returns the number of registered features
        /// </summary>
        public UInt32 Count
        {
            get { return (UInt32)m_items.Count; }
        }

        /// <summary>
        /// Returns a string containing a list of features separated by the specified separator
        /// The version number is added between () if it is greater tahn ZERO
        /// </summary>
        public String GetList(String separator = null)
        {
            if(String.IsNullOrEmpty(separator))
                separator = ", ";

            string retval = "";
            uint cnt = 0;

            foreach (String key in m_items.Keys)
            {
                UInt32 version = 0;
                if (m_items.TryGetValue(key, out version))
                {
                    if (++cnt != 1)
                        retval += separator;

                    if (version != 0)
                        retval += String.Format("{0} ({1})", key, version);
                    else
                        retval += String.Format("{0}", key);
                }
            }

            return retval;
        }

        /// <summary>
        /// Returns a string containing a list of features, each one in separate line
        /// The version number is added between () if it is greater tahn ZERO
        /// </summary>
        public override String ToString()
        {
            string retval = "";
            uint cnt = 0;
            uint max_cnt = (uint)m_items.Keys.Count;

            String format_prefix;
            if      (max_cnt <   10) format_prefix = "{0,1}";
            else if (max_cnt <  100) format_prefix = "{0,2}";
            else if (max_cnt < 1000) format_prefix = "{0,3}";
            else                     format_prefix = "{0}";

            foreach (String key in m_items.Keys)
            {
                UInt32 version = 0;
                if (m_items.TryGetValue(key, out version))
                {
                    if (++cnt != 1)
                        retval += "\n";

                    if (version != 0)
                        retval += String.Format(format_prefix + ". {1} ({2})", cnt, key, version);
                    else
                        retval += String.Format(format_prefix + ". {1}", cnt, key);
                }
            }

            return retval;
        }

        [DataMember(Name = "Items")]
        private SortedList<String, UInt32> m_items;
    }
}
