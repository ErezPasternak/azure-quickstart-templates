﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EriCommon
{
    /// <summary>
    /// The Constants static class contains all the constants of the EriCommon namespace.
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// Is true if the DEBUG conditional compilation flag is set, otherwise is false.
        /// </summary>
        public const bool IsDebug =
#if DEBUG
            true;
#else
            false;
#endif
    }
}
