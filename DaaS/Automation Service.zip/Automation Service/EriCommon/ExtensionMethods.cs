﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Threading;
using System.Security.Cryptography;

namespace EriCommon
{
    /// <summary>
    /// The ExtensionMethods static class contains static methods extending other classes and types.
    /// </summary>
    public static class ExtensionMethods
    {
        #region Misc
        /// <summary>
        /// Returns the length of the string representation of the instance of T.
        /// </summary>
        public static Int32 GetLength<T>(this T i)
        {
            return i.ToString().Length;
        }

        #endregion Misc

        #region Synchronization
        /// <summary>
        /// The GetSingleAccessLock extension method for the NamedAutoResetEvent class.
        /// </summary>
        public static NamedSingleAccessLock GetSingleAccessLock(this NamedAutoResetEvent handle)
        {
            return new NamedSingleAccessLock(handle);
        }

        /// <summary>
        /// The GetSingleAccessLock with timeout extension method for the NamedAutoResetEvent class.
        /// </summary>
        public static NamedSingleAccessLock GetSingleAccessLock(this NamedAutoResetEvent handle, Int32 milliseconds)
        {
            return new NamedSingleAccessLock(handle, milliseconds);
        }

        /// <summary>
        /// The GetSingleAccessLock extension method for the AutoResetEvent class.
        /// </summary>
        public static SingleAccessLock GetSingleAccessLock(this AutoResetEvent handle)
        {
            return new SingleAccessLock(handle);
        }

        /// <summary>
        /// The GetSingleAccessLock with timeout extension method for the AutoResetEvent class.
        /// </summary>
        public static SingleAccessLock GetSingleAccessLock(this AutoResetEvent handle, Int32 milliseconds)
        {
            return new SingleAccessLock(handle, milliseconds);
        }

        #endregion Synchronization

        #region Exception
        /// <summary>
        /// Exception.AllMessages returns all the messages of the exception and it's inner exception, recursively
        /// </summary>
        public static String AllMessages(this Exception ex, uint n_shift_left, char separator = '\n')
        {
            String text = "";
            String format = String.Format("{{0,{0}}}{{1}}", n_shift_left);

            while (ex != null)
            {
                if (text.Length > 0)
                    text += String.Format(format, "", separator);

                text += ex.Message;

                ex = ex.InnerException;
            }

            return text;
        }

        /// <summary>
        /// Exception.SameType returns true if the type of the exceptions and recursively their inner exceptions are the same
        /// </summary>
        public static bool SameType(this Exception me, Exception other)
        {
            if (other == null)
                return false;

            if (me.GetType() != other.GetType())
                return false;

            if (me.InnerException != null)
                return me.InnerException.SameType(other.InnerException);

            return other.InnerException == null;
        }

        /// <summary>
        /// Exception.AllMessages returns all the messages of the exception and it's inner exception, recursively
        /// </summary>
        public static String AllMessages(this Exception ex, char separator = '\n')
        {
            return ex.AllMessages(0, separator);
        }

        #endregion Exception

        #region String

        /// <summary>
        /// The extended String.LastIndexOf method
        /// </summary>
        public static int LastIndexOfEx(this String s, char value, int n_occurrences, int start = -1)
        {
            if (start < 0)
                start = s.Length - 1;

            int idx = -1;

            while (0 < n_occurrences--)
            {
                idx = s.LastIndexOf(value, start);

                if (idx < 0)
                    return idx;

                start = idx - 1;
            }

            return idx;
        }

        /// <summary>
        /// The extended String.LastIndexOf method
        /// </summary>
        public static int LastIndexOfEx(this String s, String value, int n_occurrences, int start = -1)
        {
            if (start < 0)
                start = s.Length - 1;

            int idx = -1;

            while (0 < n_occurrences--)
            {
                idx = s.LastIndexOf(value, start);

                if (idx < 0)
                    return idx;

                start = idx - 1;
            }

            return idx;
        }

        /// <summary>
        /// The String.ShiftLinesRight method
        /// </summary>
        public static String ShiftLinesRight(this String s, uint n_spaces, bool including_first_line = true)
        {
            if( n_spaces == 0 || (including_first_line == false && s.IndexOf('\n') < 0))
                return s;

            String format = String.Format("{{0,{0}}}", n_spaces),
                   spaces = String.Format(format, "");
            String text = including_first_line ? spaces + s : s;
            spaces = "\n" + spaces;

            text = text.Replace("\n", spaces);

            return text;
        }

        /// <summary>
        /// The String.ShiftLinesRight method
        /// </summary>
        public static String Reverse(this String s)
        {
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }

        /// <summary>
        /// The String.GetSingleSpaced method
        /// </summary>
        public static String GetSingleSpaced(this String s)
        {
            String curr = s,
                   prev;

            do
            {
                prev = curr;
                curr = curr.Replace("\x20\x20", "\x20");
            } while (prev != curr);

            return s;
        }

        /// <summary>
        /// The String.GetFirst method
        /// </summary>
        public static char GetFirst(this String s)
        {
            return (s.Length > 0) ? s[0] : '\x0';
        }
/*
        /// <summary>
        /// Converts a byte[] to String
        /// </summary>

        USE StringHelper.BytesToHexString()
 *
        public static String ByteArrayToString(byte[] ba)
        {
            StringBuilder hex = new StringBuilder(ba.Length * 2);

            for (int i = 0; i < ba.Length; i++)       // <-- use for loop is faster than foreach
                hex.Append(ba[i].ToString("X2"));   // <-- ToString is faster than AppendFormat

            return hex.ToString();
        }

        USE StringHelper.HexStringToBytes()
 *
        /// <summary>
        /// Converts a String to a byte[]
        /// </summary>
        public static byte[] StringToByteArray(this String hex)
        {
            int NumberChars = hex.Length / 2;
            byte[] bytes = new byte[NumberChars];
            StringReader sr = new StringReader(hex);
            for (int i = 0; i < NumberChars; i++)
                bytes[i] = Convert.ToByte(new string(new char[2] { (char)sr.Read(), (char)sr.Read() }), 16);
            sr.Dispose();
            return bytes;
        }
*/
        private static byte[] get_key_array(String k, bool use_hashing)
        {
            if (String.IsNullOrEmpty(k))
                k = sm_enpass_prefix;

            byte[] keyArray;

            if (use_hashing)
            {
                MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(k));
                //Always release the resources and flush data
                // of the Cryptographic service provide. Best Practice
                hashmd5.Clear();
            }
            else
            {
                keyArray = UTF8Encoding.UTF8.GetBytes(k);
            }

            return keyArray;
        }

        private static ICryptoTransform get_crypto_transform(byte[] keyArray, bool encrypt, out TripleDESCryptoServiceProvider tdes)
        {
            tdes = new TripleDESCryptoServiceProvider();
            //set the secret key for the tripleDES algorithm
            tdes.Key = keyArray;
            //mode of operation. there are other 4 modes.
            //We choose ECB(Electronic code Book)
            tdes.Mode = CipherMode.ECB;
            //padding mode(if any extra byte added)
            tdes.Padding = PaddingMode.PKCS7;

            return (encrypt) ? tdes.CreateEncryptor() : tdes.CreateDecryptor();
        }

        /// <summary>
        /// Encodes a string
        /// </summary>
        public static String Enpass(this String s, String k, bool use_hashing)
        {
            if(s == null)
                throw new ArgumentNullException("The string which needs to be encrypted can not be null.");

            if (s.IsDepass())
            {
                return s;
            }

            Int32 n = sm_random_generator.Next(),
                  m = (Int32)(n ^ sm_enpass_XOR);

            String temp = n.ToString() + sm_enpass_separator + s + sm_enpass_separator + m.ToString();
#if DEBUG
            string[] split = temp.Split(new String[] { sm_enpass_separator }, StringSplitOptions.None);

            if (split.Length != 3)
                return null;
#endif
            temp = temp.Reverse();

            byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(temp);
            byte[] keyArray = get_key_array(k, use_hashing);

            TripleDESCryptoServiceProvider tdes;
            ICryptoTransform cTransform = get_crypto_transform(keyArray, true, out tdes);
            //transform the specified region of bytes array to resultArray
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            //Release resources held by TripleDes Encryptor
            tdes.Clear();
            //Return the encrypted data into unreadable string format
            return sm_enpass_prefix + Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }

        /// <summary>
        /// returns true if the string was encoded with Enpass.
        /// </summary>
        public static bool IsEnpass(this String s)
        {
            return s.IndexOf(sm_enpass_prefix) == 0;
        }

        /// <summary>
        /// returns true if the string was not encoded with Enpass.
        /// </summary>
        public static bool IsDepass(this String s)
        {
            return s.IndexOf(sm_depass_prefix) == 0;
        }

        /// <summary>
        /// Depass a string
        /// </summary>
        public static String Depass(this String s, String k, bool use_hashing)
        {
            if (s == null)
                throw new ArgumentNullException("The string which needs to be decrypted can not be null.");

            if (s.IsDepass())
            {
                s = s.Substring(sm_enpass_prefix.Length);
                return s;
            }

            if (s.IsEnpass() == false)
                return null;

            s = s.Substring(sm_enpass_prefix.Length);

            if (String.IsNullOrEmpty(k))
                k = sm_enpass_prefix;

            byte[] encrypted_bytes;

            try
            {
                encrypted_bytes = Convert.FromBase64String(s);

                byte[] keyArray = get_key_array(k, use_hashing);

                TripleDESCryptoServiceProvider tdes;
                ICryptoTransform cTransform = get_crypto_transform(keyArray, false, out tdes);
                //transform the specified region of bytes array to resultArray
                byte[] resultArray = cTransform.TransformFinalBlock(encrypted_bytes, 0, encrypted_bytes.Length);
                //Release resources held by TripleDes Decryptor
                tdes.Clear();

                String temp = UTF8Encoding.UTF8.GetString(resultArray);
                temp = temp.Reverse();

                string[] split = temp.Split(new String[] { sm_enpass_separator }, StringSplitOptions.None);

                if (split.Length != 3)
                    return null;

                unchecked
                {
                    Int32 n = Int32.Parse(split[0]),
                          m = Int32.Parse(split[2]) ^ (int)sm_enpass_XOR;

                    if (n != m)
                        return null;
                }

                return split[1];
            }
            catch (Exception /*ex*/)
            {
                return null;
            }

        }

        private static String sm_enpass_prefix = ":dedocne".Reverse();
        private static String sm_depass_prefix = ":dedoced".Reverse();
        private static Random sm_random_generator = new Random();
        private const  String sm_enpass_separator = "\t\rYOCHAI\r\t";
        private const  uint   sm_enpass_XOR = 0xA5A55A5A;

        #endregion String

        #region Timer
        /// <summary>
        /// Sets the timer for a constant 'interval' period. The first callback will occur after 'interval'.
        /// </summary>
        public static void Set(this Timer t, long interval)
        {
            t.Change(interval, interval);
        }

        /// <summary>
        /// Sets the timer once. The callback will occur after 'interval'.
        /// </summary>
        public static void SetOnce(this Timer t, long interval)
        {
            t.Change(interval, Timeout.Infinite);
        }

        /// <summary>
        /// Cancel the timer.
        /// </summary>
        public static void Cancel(this Timer t)
        {
            t.Change(Timeout.Infinite, Timeout.Infinite);
        }

        #endregion Timer

        #region IndexOf

        /// <summary>
        /// Returns the index of a sub byte[]
        /// </summary>
        public static int IndexOf(this byte[] me, byte[] to_be_found, int my_start_index, int my_count, int to_be_found_start_index, int to_be_found_count)
        {
            int retval = -1;

            if (me == null)
                return retval;
            if (me.Length <= my_start_index)
                return retval;
            if (my_count == 0)
                return retval;

            if (to_be_found == null)
                return retval;
            if (to_be_found.Length <= to_be_found_start_index)
                return retval;
            if (to_be_found_count == 0)
                return retval;

            if(my_start_index + my_count > me.Length)
                my_count = me.Length - my_start_index;

            if(to_be_found_start_index + to_be_found_count > to_be_found.Length)
                to_be_found_count = to_be_found.Length - to_be_found_start_index;

            if (my_count < to_be_found_count)
                return retval;

            if (me == to_be_found &&
                my_start_index == to_be_found_start_index &&
                my_count >= to_be_found_count)
            {
                return my_start_index;
            }

            byte first_byte = to_be_found[0];
            to_be_found_start_index++;
            to_be_found_count--;

            for (; ; )
            {
                int pos = Array.IndexOf<byte>(me, first_byte, my_start_index, my_count);

                if (pos < 0)
                    return retval;

                if (to_be_found_count == 0)
                    return pos;

                my_start_index = pos + 1;
                my_count = me.Length - my_start_index;

                if (my_count < to_be_found_count)
                    return retval;

                int s_idx = my_start_index,
                    s_end = s_idx + my_count,
                    f_idx = to_be_found_start_index,
                    f_end = f_idx + to_be_found_count;

                do
                {
                    if(me[s_idx] != to_be_found[f_idx])
                        break;

                    s_idx++;
                    f_idx++;
                } while (s_idx < s_end && f_idx < f_end);

                if (f_idx == f_end)
                    return pos;

                if (my_count == to_be_found_count)
                    return retval;
            }

        }

        /// <summary>
        /// Returns the index of a sub byte[]
        /// </summary>
        public static int IndexOf(this byte[] me, byte[] to_be_found, int my_start_index, int my_count)
        {
            return IndexOf(me, to_be_found, my_start_index, my_count, 0, to_be_found.Length);
        }

        /// <summary>
        /// Returns the index of a sub byte[]
        /// </summary>
        public static int IndexOf(this byte[] me, byte[] to_be_found)
        {
            return IndexOf(me, to_be_found, 0, me.Length, 0, to_be_found.Length);
        }

#       endregion IndexOf

        #region XML
        /// <summary>
        /// Build a WINDOWS/UNIX style path string
        /// </summary>
        public static String GetPath(this XmlNode node)
        {
            XmlNode parent = node.ParentNode;

            if( parent != null )
                return parent.GetPath() + '/' + node.Name;

            return "";// node.Name; return "" instead of "#document"
        }

        /// <summary>
        /// Adds a sub-node
        /// </summary>
        public static XmlNode CreateNode(this XmlNode parent, String name, String inner_text = null)
        {
            XmlDocument doc = parent.OwnerDocument;
            if (doc == null)
                doc = (XmlDocument)parent;

            XmlNode node = doc.CreateElement(name);

            if (inner_text != null)
                node.InnerText = inner_text;

            parent.AppendChild(node);
            return node;
        }

        public static string AsString(this XmlDocument doc)
        {
            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter tx = new XmlTextWriter(sw))
                {
                    doc.WriteTo(tx);
                    string strXmlText = sw.ToString();
                    return strXmlText;
                }
            }
        }

        #endregion XML

        /// <summary>
        /// Checks if the ZEROs
        /// </summary>
        public static bool IsZERO(this Guid guid)
        {
            return guid.CompareTo(Guid.Empty) == 0;
        }
    }

}
