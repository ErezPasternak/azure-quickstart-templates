﻿//
// This code was written by Keith Brown, and may be freely used.
// Want to learn more about .NET? Visit pluralsight.com today!
//
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EriCommon.SelfSignedCertificate
{
    /// <summary>
    /// EYAL!!!
    /// </summary>
    public enum KeyType : int
    {
        /// <summary>
        /// EYAL!!!
        /// </summary>
        Exchange = 1,
        /// <summary>
        /// EYAL!!!
        /// </summary>
        Signature = 2,
    }
}
