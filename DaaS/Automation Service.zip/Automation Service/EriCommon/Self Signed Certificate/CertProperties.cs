﻿//
// This code was written by Keith Brown, and may be freely used.
// Want to learn more about .NET? Visit pluralsight.com today!
//
using System;
using System.Net;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography.X509Certificates;

namespace EriCommon.SelfSignedCertificate
{
    /// <summary>
    /// EYAL!!!
    /// </summary>
    public class SelfSignedCertProperties
    {
        /// <summary>
        /// EYAL!!!
        /// </summary>
        public DateTime ValidFrom { get; set; }

        /// <summary>
        /// EYAL!!!
        /// </summary>
        public DateTime ValidTo { get; set; }

        /// <summary>
        /// EYAL!!!
        /// </summary>
        public X500DistinguishedName Name { get; set; }

        /// <summary>
        /// EYAL!!!
        /// </summary>
        public int KeyBitLength { get; set; }

        /// <summary>
        /// EYAL!!!
        /// </summary>
        public bool IsPrivateKeyExportable { get { return true; } private set { } }

        /// <summary>
        /// EYAL!!!
        /// </summary>
        public SelfSignedCertProperties(String subject_name)
        {
            DateTime today = DateTime.Today;
            ValidFrom = today.AddDays(-1);
            ValidTo = today.AddYears(10);
            KeyBitLength = 1024;
            Name = new X500DistinguishedName("cn=" + subject_name);
        }
    }
}
