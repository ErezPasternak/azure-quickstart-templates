﻿//
// This code was written by Keith Brown, and may be freely used.
// Want to learn more about .NET? Visit pluralsight.com today!
//
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EriCommon.SelfSignedCertificate
{
    /// <summary>
    /// EYAL!!!
    /// </summary>
    public class KeyExchangeKey : CryptKey
    {
        internal KeyExchangeKey(CryptContext ctx, IntPtr handle) : base(ctx, handle)  {}

        /// <summary>
        /// EYAL!!!
        /// </summary>
        public override KeyType Type
        {
            get { return KeyType.Exchange; }
        }
    }
}
