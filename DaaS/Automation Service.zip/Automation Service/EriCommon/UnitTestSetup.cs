﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Reflection;

using TracerX;

namespace EriCommon
{
    /// <summary>
    /// The Debugger class
    /// </summary>
    public static class Debugger
    {
        /// <summary>
        /// See the corresponding Debug.Assert method
        /// </summary>
        [Conditional("DEBUG")]
        public static void Assert(bool condition)
        {
            if (UnitTestSetup.Started)
                return;

            Debug.Assert(condition);
        }

        /// <summary>
        /// See the corresponding Debug.Assert method
        /// </summary>
        [Conditional("DEBUG")]
        public static void Assert(bool condition, string message)
        {
            if (UnitTestSetup.Started)
                return;

            Debug.Assert(condition, message);
        }

        /// <summary>
        /// See the corresponding Debug.Assert method
        /// </summary>
        [Conditional("DEBUG")]
        public static void Assert(bool condition, string message, string detailMessage)
        {
            if (UnitTestSetup.Started)
                return;

            Debug.Assert(condition, message, detailMessage);
        }

        /// <summary>
        /// See the corresponding Debug.Assert method
        /// </summary>
        [Conditional("DEBUG")]
        public static void Assert(bool condition, string message, string detailMessageFormat, params object[] args)
        {
            if (UnitTestSetup.Started)
                return;

            Debug.Assert(condition, message, detailMessageFormat, args);
        }

    }

    /// <summary>
    /// The UnitTestSetup class
    /// </summary>
    public static class UnitTestSetup
    {
        /// <summary>
        /// The unit test assembly
        /// </summary>
        static public Assembly Assembly
        {
            get;
            private set;
        }

        /// <summary>
        /// Started
        /// </summary>
        static public bool Started
        {
            get { return null != Assembly; }
        }

        /// <summary>
        /// Initialize
        /// </summary>
        static public void InitializeOutProcess()
        {
            Assembly = Assembly.GetEntryAssembly();
        }

        /// <summary>
        /// Initialize
        /// </summary>
        static public void InitializeInProcess(Assembly assembly)
        {
            Debug.Assert(Assembly == null);
            Debug.Assert(assembly != null);

            Assembly = assembly;

            Logger.SetMainAssembly(Assembly);
            AppCfg.Initialize();
            LogHelper.OpenServiceLog();
            Translator.Initialize();
        }
    }
}
