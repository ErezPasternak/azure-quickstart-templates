// This is the main DLL file.

#include "stdafx.h"

#include "Native.h"

using namespace System::ComponentModel;

//using EriCommon;
using namespace EriCommon;

#include <exception>
using namespace std;

LONG ConvertToManagedExceptionIfNeeded(PEXCEPTION_POINTERS ExceptionInfo);
// DWORD treate_except( const EXCEPTION_POINTERS& ep )
// {
// 	return EXCEPTION_EXECUTE_HANDLER;
// }

void Native::Test::Raise_0xC0000417()
{
#if 1
	__try
	{
		raise(10);
	}
	__except( ConvertToManagedExceptionIfNeeded( GetExceptionInformation() ) )
	{
		;
	}
#else
	raise(10);
#endif
}

void Native::Test::raise( int x )
{
	if( x == 0 )
	{
#if 1
		raise();
#else
		Exception^ e = gcnew Exception();

		EriCommon::SafeCall::ExceptionHandler(e, "From managed code!!!");
#endif
		return;
	}

	raise( x-1 );
}

void Native::Test::raise()
{
#if 1
	char* p = NULL;
	*p = 77;
#else
	::RaiseException( 0xC0000417, 0, 0, NULL );
#endif
}

#define CLR_EXCEPTION_CODE 0xE0434F4D

#define CPP_EXCEPTION_CODE 0xE06D7363

ref class ExceptionConverter {

public:

	static Exception^ GetException(

		unsigned int ExceptionCode,

		void* pExceptionObject) {



			//More complicated logic can be added here



			if (pExceptionObject == NULL)
//http://code.google.com/p/llamakiss/source/browse/trunk/Win32Exception.h?r=1
				return gcnew Win32Exception(ExceptionCode);



			std::exception& rException =

				*(std::exception*)pExceptionObject;

			return gcnew ApplicationException(

				gcnew String(rException.what()));

	}

};

LONG ConvertToManagedExceptionIfNeeded(PEXCEPTION_POINTERS ExceptionInfo) 
{
		void* pExceptionObject = NULL;



		PEXCEPTION_RECORD ExceptionRecord =

			ExceptionInfo->ExceptionRecord;

		switch (ExceptionRecord->ExceptionCode){

		case CLR_EXCEPTION_CODE:

			//Don't touch CLR exceptions.

			return EXCEPTION_EXECUTE_HANDLER;

		case CPP_EXCEPTION_CODE:

			pExceptionObject = (void*)

				ExceptionRecord->ExceptionInformation[1];

		default:

			break;

		}

		Exception^ e = gcnew Exception(gcnew String("BlaBlaBla")); //ExceptionConverter::GetException( ExceptionRecord->ExceptionCode, pExceptionObject );
		
		EriCommon::SafeCall::ExceptionHandler(e, "From managed code!!!");

//		Exception^ e2 = gcnew Exception(gcnew String("HaHaHa"));
//		throw e2;

		return EXCEPTION_EXECUTE_HANDLER;
}

