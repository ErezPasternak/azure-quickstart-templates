// Native.h

#pragma once

#include <windows.h>

using namespace System;

namespace Native {

	public ref class Test
	{
	public:
		Test()	{	}

		void Raise_0xC0000417();

	private:

		void raise( int x );
		void raise();

	};
}
