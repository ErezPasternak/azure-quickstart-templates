﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using TracerX;

namespace EriCommon
{
    /// <summary>
    /// The FileHelper static class contains static methods dealing with files.
    /// </summary>
    public static class FileHelper
    {
        #region Public
        /// <summary>
        /// Renames a file located in the TracerX log folder.
        /// The filename uses the logger's file prefix + file_name_suffix + the version counter + file_extension
        /// </summary>
        public static string RenameFile(string file_name_suffix, string file_extension)
        {
            string simpleName = Logger.FileBase.NamePrefix + file_name_suffix,
                   letter = "",
                   filepath = "";

            char c = 'A';
            c--;

            for (;;)
            {
                try
                {
                    filepath = simpleName + letter;
                    string retval = Logger.RenameFile(filepath, file_extension);

                    if (letter != "")
                    {
                        Logger.Current.Warn(string.Format("The file '{0}_nn.{1}' will be open as {2}_nn.{1}",
                                            simpleName,
                                            file_extension,
                                            filepath));
                    }

                    return retval;
                }
                catch (System.Exception ex)
                {
#if DEBUG
                    bool append_stack_trace = true;
#else
                    bool append_stack_trace = false;
#endif
                    Logger.Current.ErrorEx(string.Format("Unable to rename the file '{0}_nn.{1}'", filepath, file_extension),
                                           ex,
                                           append_stack_trace);

                    if (c > 'Z')
                        throw;

                    c++;
                    letter = string.Format("({0})", c);
                }
            }
        }
        #endregion
    }
}
