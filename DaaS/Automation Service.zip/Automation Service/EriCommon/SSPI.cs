﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Security.Principal;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.ComponentModel;

namespace EriCommon
{
    //http://www.pinvoke.net/default.aspx/secur32.initializesecuritycontext

    using HANDLE = System.IntPtr;

    /// <summary>
    /// The SSPI wrapper class
    /// </summary>
    public class SSPI
    {
        /// <summary>
        /// The SecBufferType enum
        /// </summary>
        public enum SecBufferType
        {
            /// <summary>
            /// </summary>
            SECBUFFER_VERSION = 0,
            /// <summary>
            /// </summary>
            SECBUFFER_EMPTY = 0,
            /// <summary>
            /// </summary>
            SECBUFFER_DATA = 1,
            /// <summary>
            /// </summary>
            SECBUFFER_TOKEN = 2
        }

        /// <summary>
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public struct SecHandle //=PCtxtHandle
        {
            IntPtr dwLower; // ULONG_PTR translates to IntPtr not to uint
            IntPtr dwUpper; // this is crucial for 64-Bit Platforms
        }

        /// <summary>
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public struct SecBuffer : IDisposable
        {
            /// <summary>
            /// </summary>
            public int cbBuffer;
            /// <summary>
            /// </summary>
            public int BufferType;
            /// <summary>
            /// </summary>
            public IntPtr pvBuffer;

            /// <summary>
            /// </summary>
            public SecBuffer(int bufferSize)
            {
                cbBuffer = bufferSize;
                BufferType = (int)SecBufferType.SECBUFFER_TOKEN;
                pvBuffer = Marshal.AllocHGlobal(bufferSize);
            }

            /// <summary>
            /// </summary>
            public SecBuffer(byte[] secBufferBytes)
            {
                cbBuffer = secBufferBytes.Length;
                BufferType = (int)SecBufferType.SECBUFFER_TOKEN;
                pvBuffer = Marshal.AllocHGlobal(cbBuffer);
                Marshal.Copy(secBufferBytes, 0, pvBuffer, cbBuffer);
            }

            /// <summary>
            /// </summary>
            public SecBuffer(byte[] secBufferBytes, SecBufferType bufferType)
            {
                cbBuffer = secBufferBytes.Length;
                BufferType = (int)bufferType;
                pvBuffer = Marshal.AllocHGlobal(cbBuffer);
                Marshal.Copy(secBufferBytes, 0, pvBuffer, cbBuffer);
            }

            /// <summary>
            /// </summary>
            public void Dispose()
            {
                if (pvBuffer != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(pvBuffer);
                    pvBuffer = IntPtr.Zero;
                }
            }
        }

        /// <summary>
        /// </summary>
        public struct MultipleSecBufferHelper
        {
            /// <summary>
            /// </summary>
            public byte[] Buffer;
            /// <summary>
            /// </summary>
            public SecBufferType BufferType;

            /// <summary>
            /// </summary>
            public MultipleSecBufferHelper(byte[] buffer, SecBufferType bufferType)
            {
                if (buffer == null || buffer.Length == 0)
                {
                    throw new ArgumentException("buffer cannot be null or 0 length");
                }

                Buffer = buffer;
                BufferType = bufferType;
            }
        };

        /// <summary>
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public struct SecBufferDesc : IDisposable
        {
            /// <summary>
            /// </summary>
            public int ulVersion;
            /// <summary>
            /// </summary>
            public int cBuffers;
            /// <summary>
            /// </summary>
            public IntPtr pBuffers; //Point to SecBuffer

            /// <summary>
            /// </summary>
            public SecBufferDesc(int bufferSize)
            {
                ulVersion = (int)SecBufferType.SECBUFFER_VERSION;
                cBuffers = 1;
                SecBuffer ThisSecBuffer = new SecBuffer(bufferSize);
                pBuffers = Marshal.AllocHGlobal(Marshal.SizeOf(ThisSecBuffer));
                Marshal.StructureToPtr(ThisSecBuffer, pBuffers, false);
            }

            /// <summary>
            /// </summary>
            public SecBufferDesc(byte[] secBufferBytes)
            {
                ulVersion = (int)SecBufferType.SECBUFFER_VERSION;
                cBuffers = 1;
                SecBuffer ThisSecBuffer = new SecBuffer(secBufferBytes);
                pBuffers = Marshal.AllocHGlobal(Marshal.SizeOf(ThisSecBuffer));
                Marshal.StructureToPtr(ThisSecBuffer, pBuffers, false);
            }

            /// <summary>
            /// </summary>
            public SecBufferDesc(MultipleSecBufferHelper[] secBufferBytesArray)
            {
                if (secBufferBytesArray == null || secBufferBytesArray.Length == 0)
                {
                    throw new ArgumentException("secBufferBytesArray cannot be null or 0 length");
                }

                ulVersion = (int)SecBufferType.SECBUFFER_VERSION;
                cBuffers = secBufferBytesArray.Length;

                //Allocate memory for SecBuffer Array....
                pBuffers = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(SecBuffer)) * cBuffers);

                for (int Index = 0; Index < secBufferBytesArray.Length; Index++)
                {
                    //Super hack: Now allocate memory for the individual SecBuffers
                    //and just copy the bit values to the SecBuffer array!!!
                    SecBuffer ThisSecBuffer = new SecBuffer(secBufferBytesArray[Index].Buffer, secBufferBytesArray[Index].BufferType);

                    //We will write out bits in the following order:
                    //int cbBuffer;
                    //int BufferType;
                    //pvBuffer;
                    //Note that we won't be releasing the memory allocated by ThisSecBuffer until we
                    //are disposed...
                    int CurrentOffset = Index * Marshal.SizeOf(typeof(SecBuffer));
                    Marshal.WriteInt32(pBuffers, CurrentOffset, ThisSecBuffer.cbBuffer);
                    Marshal.WriteInt32(pBuffers, CurrentOffset + Marshal.SizeOf(ThisSecBuffer.cbBuffer), ThisSecBuffer.BufferType);
                    Marshal.WriteIntPtr(pBuffers, CurrentOffset + Marshal.SizeOf(ThisSecBuffer.cbBuffer) + Marshal.SizeOf(ThisSecBuffer.BufferType), ThisSecBuffer.pvBuffer);
                }
            }

            /// <summary>
            /// </summary>
            public void Dispose()
            {
                if (pBuffers != IntPtr.Zero)
                {
                    if (cBuffers == 1)
                    {
                        SecBuffer ThisSecBuffer = (SecBuffer)Marshal.PtrToStructure(pBuffers, typeof(SecBuffer));
                        ThisSecBuffer.Dispose();
                    }
                    else
                    {
                        for (int Index = 0; Index < cBuffers; Index++)
                        {
                            //The bits were written out the following order:
                            //int cbBuffer;
                            //int BufferType;
                            //pvBuffer;
                            //What we need to do here is to grab a hold of the pvBuffer allocate by the individual
                            //SecBuffer and release it...
                            int CurrentOffset = Index * Marshal.SizeOf(typeof(SecBuffer));
                            IntPtr SecBufferpvBuffer = Marshal.ReadIntPtr(pBuffers, CurrentOffset + Marshal.SizeOf(typeof(int)) + Marshal.SizeOf(typeof(int)));
                            Marshal.FreeHGlobal(SecBufferpvBuffer);
                        }
                    }

                    Marshal.FreeHGlobal(pBuffers);
                    pBuffers = IntPtr.Zero;
                }
            }

            /// <summary>
            /// </summary>
            public byte[] GetSecBufferByteArray()
            {
                byte[] Buffer = null;

                if (pBuffers == IntPtr.Zero)
                {
                    throw new InvalidOperationException("Object has already been disposed!!!");
                }

                if (cBuffers == 1)
                {
                    SecBuffer ThisSecBuffer = (SecBuffer)Marshal.PtrToStructure(pBuffers, typeof(SecBuffer));

                    if (ThisSecBuffer.cbBuffer > 0)
                    {
                        Buffer = new byte[ThisSecBuffer.cbBuffer];
                        Marshal.Copy(ThisSecBuffer.pvBuffer, Buffer, 0, ThisSecBuffer.cbBuffer);
                    }
                }
                else
                {
                    int BytesToAllocate = 0;

                    for (int Index = 0; Index < cBuffers; Index++)
                    {
                        //The bits were written out the following order:
                        //int cbBuffer;
                        //int BufferType;
                        //pvBuffer;
                        //What we need to do here calculate the total number of bytes we need to copy...
                        int CurrentOffset = Index * Marshal.SizeOf(typeof(SecBuffer));
                        BytesToAllocate += Marshal.ReadInt32(pBuffers, CurrentOffset);
                    }

                    Buffer = new byte[BytesToAllocate];

                    for (int Index = 0, BufferIndex = 0; Index < cBuffers; Index++)
                    {
                        //The bits were written out the following order:
                        //int cbBuffer;
                        //int BufferType;
                        //pvBuffer;
                        //Now iterate over the individual buffers and put them together into a
                        //byte array...
                        int CurrentOffset = Index * Marshal.SizeOf(typeof(SecBuffer));
                        int BytesToCopy = Marshal.ReadInt32(pBuffers, CurrentOffset);
                        IntPtr SecBufferpvBuffer = Marshal.ReadIntPtr(pBuffers, CurrentOffset + Marshal.SizeOf(typeof(int)) + Marshal.SizeOf(typeof(int)));
                        Marshal.Copy(SecBufferpvBuffer, Buffer, BufferIndex, BytesToCopy);
                        BufferIndex += BytesToCopy;
                    }
                }

                return (Buffer);
            }
        }

        /// <summary>
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public struct SECURITY_INTEGER
        {
            /// <summary>
            /// </summary>
            public uint LowPart;
            /// <summary>
            /// </summary>
            public int HighPart;
            /// <summary>
            /// </summary>
            public SECURITY_INTEGER(int dummy)
            {
                LowPart = 0;
                HighPart = 0;
            }
        };

        /// <summary>
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public struct SECURITY_HANDLE
        {
            /// <summary>
            /// </summary>
            public IntPtr LowPart;
            /// <summary>
            /// </summary>
            public IntPtr HighPart;
            /// <summary>
            /// </summary>
            public SECURITY_HANDLE(int dummy)
            {
                LowPart = HighPart = IntPtr.Zero;
            }
        };

        /// <summary>
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public struct SecPkgContext_Sizes
        {
            /// <summary>
            /// </summary>
            public uint cbMaxToken;
            /// <summary>
            /// </summary>
            public uint cbMaxSignature;
            /// <summary>
            /// </summary>
            public uint cbBlockSize;
            /// <summary>
            /// </summary>
            public uint cbSecurityTrailer;
        };

        /// <summary>
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public struct SecPkgInfo
        {
            /// <summary>
            /// </summary>
            //ulong is 32 bit so we need to use a 32 bit int
            public UInt32 fCapabilities;
            /// <summary>
            /// </summary>
            //ushort is 16 bit
            public UInt16 wVersion;
            /// <summary>
            /// </summary>
            public UInt16 wRPCID;
            /// <summary>
            /// </summary>
            public UInt32 cbMaxToken;
//          [MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPStr)]
//          public string Name;
            private IntPtr name;
            /// <summary>
            /// </summary>
            public string Name
            {
                get { return Marshal.PtrToStringAuto(name); }
            }
//          [MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPStr)]
//          public string Comment;
            private IntPtr comment;
            /// <summary>
            /// </summary>
            public string Comment
            {
                get { return Marshal.PtrToStringAuto(comment); }
            }
        }

        /// <summary>
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public struct SecPkgContext_PackageInfo
        {
            /// <summary>
            /// </summary>
            public IntPtr PackageInfo;
        };

        /// <summary>
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public struct SecPkgContext_Names
        {
            private IntPtr user_name;
            /// <summary>
            /// </summary>
            public string UserName
            {
                get { return Marshal.PtrToStringAuto(user_name); }
            }
        }

        /// <summary>
        /// </summary>
        public enum PackageType
        {
            /// <summary>
            /// </summary>
            Kerberos,
            /// <summary>
            /// </summary>
            NTLM,
            /// <summary>
            /// </summary>
            Negotiate,
        }

        /// <summary>
        /// Converts the value string to the corresponding package type
        /// </summary>
        static public PackageType Parse(string value)
        {
            return (PackageType)Enum.Parse(typeof(PackageType), value);
        }

        /// <summary>
        /// </summary>
        public class Helper
        {
            /// <summary>
            /// </summary>
            public const int TOKEN_QUERY = 0x00008;
            /// <summary>
            /// </summary>
            public const int SEC_E_OK = 0;
            /// <summary>
            /// </summary>
            public const int SEC_I_CONTINUE_NEEDED = 0x90312;
            const int SECPKG_CRED_OUTBOUND = 2;
            const int SECURITY_NATIVE_DREP = 0x10;
            const int SECPKG_CRED_INBOUND = 1;
            const int MAX_TOKEN_SIZE = 12288;
            //For AcquireCredentialsHandle in 3er Parameter "fCredentialUse"

            SECURITY_HANDLE _hInboundCred = new SECURITY_HANDLE(0);
            /// <summary>
            /// </summary>
            public SECURITY_HANDLE _hServerContext = new SECURITY_HANDLE(0);

            SECURITY_HANDLE _hOutboundCred = new SECURITY_HANDLE(0);
            /// <summary>
            /// </summary>
            public SECURITY_HANDLE _hClientContext = new SECURITY_HANDLE(0);

            /// <summary>
            /// </summary>
            public const int ISC_REQ_DELEGATE = 0x00000001;
            /// <summary>
            /// </summary>
            public const int ISC_REQ_MUTUAL_AUTH = 0x00000002;
            /// <summary>
            /// </summary>
            public const int ISC_REQ_REPLAY_DETECT = 0x00000004;
            /// <summary>
            /// </summary>
            public const int ISC_REQ_SEQUENCE_DETECT = 0x00000008;
            /// <summary>
            /// </summary>
            public const int ISC_REQ_CONFIDENTIALITY = 0x00000010;
            /// <summary>
            /// </summary>
            public const int ISC_REQ_USE_SESSION_KEY = 0x00000020;
            /// <summary>
            /// </summary>
            public const int ISC_REQ_PROMPT_FOR_CREDS = 0x00000040;
            /// <summary>
            /// </summary>
            public const int ISC_REQ_USE_SUPPLIED_CREDS = 0x00000080;
            /// <summary>
            /// </summary>
            public const int ISC_REQ_ALLOCATE_MEMORY = 0x00000100;
            /// <summary>
            /// </summary>
            public const int ISC_REQ_USE_DCE_STYLE = 0x00000200;
            /// <summary>
            /// </summary>
            public const int ISC_REQ_DATAGRAM = 0x00000400;
            /// <summary>
            /// </summary>
            public const int ISC_REQ_CONNECTION = 0x00000800;
            /// <summary>
            /// </summary>
            public const int ISC_REQ_CALL_LEVEL = 0x00001000;
            /// <summary>
            /// </summary>
            public const int ISC_REQ_FRAGMENT_SUPPLIED = 0x00002000;
            /// <summary>
            /// </summary>
            public const int ISC_REQ_EXTENDED_ERROR = 0x00004000;
            /// <summary>
            /// </summary>
            public const int ISC_REQ_STREAM = 0x00008000;
            /// <summary>
            /// </summary>
            public const int ISC_REQ_INTEGRITY = 0x00010000;
            /// <summary>
            /// </summary>
            public const int ISC_REQ_IDENTIFY = 0x00020000;
            /// <summary>
            /// </summary>
            public const int ISC_REQ_NULL_SESSION = 0x00040000;
            /// <summary>
            /// </summary>
            public const int ISC_REQ_MANUAL_CRED_VALIDATION = 0x00080000;
            /// <summary>
            /// </summary>
            public const int ISC_REQ_RESERVED1 = 0x00100000;
            /// <summary>
            /// </summary>
            public const int ISC_REQ_FRAGMENT_TO_FIT = 0x00200000;

            /// <summary>
            /// </summary>
            public const int SECPKG_ATTR_SIZES = 0;
            /// <summary>
            /// </summary>
            public const int SECPKG_ATTR_NAMES = 1;
            /// <summary>
            /// </summary>
            public const int SECPKG_ATTR_PACKAGE_INFO = 10;

            /// <summary>
            /// </summary>
            public const int STANDARD_CONTEXT_ATTRIBUTES = ISC_REQ_CONFIDENTIALITY | ISC_REQ_REPLAY_DETECT | ISC_REQ_SEQUENCE_DETECT | ISC_REQ_CONNECTION;

            bool _bGotClientCredentials = false;
            bool _bGotServerCredentials = false;
            bool _bGotServerContext     = false;

            [DllImport("secur32", CharSet = CharSet.Auto)]
            static extern int AcquireCredentialsHandle(
                                    string                  pszPrincipal,       //SEC_CHAR*
                                    string                  pszPackage,         //SEC_CHAR* //"Kerberos","NTLM","Negotiate"
                                    int                     fCredentialUse,
                                    IntPtr                  PAuthenticationID,  //_LUID AuthenticationID,//pvLogonID, //PLUID
                                    IntPtr                  pAuthData,          //PVOID
                                    int                     pGetKeyFn,          //SEC_GET_KEY_FN
                                    IntPtr                  pvGetKeyArgument,   //PVOID
                                    ref SECURITY_HANDLE     phCredential,       //SecHandle //PCtxtHandle ref
                                    ref SECURITY_INTEGER    ptsExpiry);         //PTimeStamp //TimeStamp ref

            [DllImport("secur32", CharSet = CharSet.Auto, SetLastError = true)]
            static extern int InitializeSecurityContext(
                                    ref SECURITY_HANDLE     phCredential,   //PCredHandle
                                    IntPtr                  phContext,      //PCtxtHandle
                                    string                  pszTargetName,
                                    int                     fContextReq,
                                    int                     Reserved1,
                                    int                     TargetDataRep,
                                    IntPtr                  pInput,         //PSecBufferDesc SecBufferDesc
                                    int                     Reserved2,
                                    out SECURITY_HANDLE     phNewContext,   //PCtxtHandle
                                    out SecBufferDesc       pOutput,        //PSecBufferDesc SecBufferDesc
                                    out uint                pfContextAttr,  //managed ulong == 64 bits!!!
                                    out SECURITY_INTEGER    ptsExpiry);     //PTimeStamp

            [DllImport("secur32", CharSet = CharSet.Auto, SetLastError = true)]
            static extern int InitializeSecurityContext(
                                    ref SECURITY_HANDLE     phCredential,   //PCredHandle
                                    ref SECURITY_HANDLE     phContext,      //PCtxtHandle
                                    string                  pszTargetName,
                                    int                     fContextReq,
                                    int                     Reserved1,
                                    int                     TargetDataRep,
                                    ref SecBufferDesc       pInput,         //PSecBufferDesc SecBufferDesc
                                    int                     Reserved2,
                                    out SECURITY_HANDLE     phNewContext,   //PCtxtHandle
                                    out SecBufferDesc       pOutput,        //PSecBufferDesc SecBufferDesc
                                    out uint                pfContextAttr,  //managed ulong == 64 bits!!!
                                    out SECURITY_INTEGER    ptsExpiry);     //PTimeStamp

            [DllImport("secur32.Dll", CharSet = CharSet.Auto, SetLastError = false)]
            static extern int AcceptSecurityContext(
                                    ref SECURITY_HANDLE     phCredential,
                                    IntPtr                  phContext,
                                    ref SecBufferDesc       pInput,
                                    uint                    fContextReq,
                                    uint                    TargetDataRep,
                                    out SECURITY_HANDLE     phNewContext,
                                    out SecBufferDesc       pOutput,
                                    out uint                pfContextAttr,    //managed ulong == 64 bits!!!
                                    out SECURITY_INTEGER    ptsTimeStamp);

            [DllImport("secur32.Dll", CharSet = CharSet.Auto, SetLastError = false)]
            static extern int AcceptSecurityContext(
                                    ref SECURITY_HANDLE     phCredential,
                                    ref SECURITY_HANDLE     phContext,
                                    ref SecBufferDesc       pInput,
                                    uint                    fContextReq,
                                    uint                    TargetDataRep,
                                    out SECURITY_HANDLE     phNewContext,
                                    out SecBufferDesc       pOutput,
                                    out uint                pfContextAttr,    //managed ulong == 64 bits!!!
                                    out SECURITY_INTEGER    ptsTimeStamp);

            /// <summary>
            /// </summary>
            [DllImport("secur32.Dll", CharSet = CharSet.Auto, SetLastError = false)]
            public static extern int ImpersonateSecurityContext(ref SECURITY_HANDLE phContext);

            /// <summary>
            /// </summary>
            [DllImport("secur32.Dll", CharSet = CharSet.Auto, SetLastError = false)]
            public static extern int QueryContextAttributes(
                                    ref SECURITY_HANDLE     phContext,
                                    uint                    ulAttribute,
                                    out SecPkgContext_Sizes pContextAttributes);

            /// <summary>
            /// </summary>
            [DllImport("secur32.Dll", CharSet = CharSet.Auto, SetLastError = false)]
            public static extern int QueryContextAttributes(
                                    ref SECURITY_HANDLE phContext,
                                    uint ulAttribute,
                                    out SecPkgContext_PackageInfo pContextAttributes);

            /// <summary>
            /// </summary>
            [DllImport("secur32.Dll", CharSet = CharSet.Auto, SetLastError = false)]
            public static extern int QueryContextAttributes(
                                    ref SECURITY_HANDLE phContext,
                                    uint ulAttribute,
                                    out SecPkgContext_Names pContextAttributes);

            /// <summary>
            /// </summary>
            [DllImport("secur32.Dll", CharSet = CharSet.Auto, SetLastError = false)]
            public static extern int EncryptMessage(
                                    ref SECURITY_HANDLE phContext,
                                    uint                fQOP,        //managed ulong == 64 bits!!!
                                    ref SecBufferDesc   pMessage,
                                    uint                MessageSeqNo);    //managed ulong == 64 bits!!!

            /// <summary>
            /// </summary>
            [DllImport("secur32.Dll", CharSet = CharSet.Auto, SetLastError = false)]
            public static extern int DecryptMessage(
                                    ref SECURITY_HANDLE phContext,
                                    ref SecBufferDesc   pMessage,
                                    uint                MessageSeqNo,
                                    out uint            pfQOP);

            /// <summary>
            /// </summary>
            [DllImport("secur32.Dll", CharSet = CharSet.Auto, SetLastError = false)]
            public static extern int MakeSignature(
                                    ref SECURITY_HANDLE phContext,          // Context to use
                                    uint                fQOP,               // Quality of Protection
                                    ref SecBufferDesc   pMessage,           // Msg to sign
                                    uint                MessageSeqNo);      // Msg Sequence Num.

            /// <summary>
            /// </summary>
            [DllImport("secur32.Dll", CharSet = CharSet.Auto, SetLastError = false)]
            public static extern int VerifySignature(
                                    ref SECURITY_HANDLE phContext,      // Context to use
                                    ref SecBufferDesc   pMessage,       // Msg to sign
                                    uint                MessageSeqNo,   // Msg Sequence Num.
                                    out uint            pfQOP);         // Quality of Protection

            /// <summary>
            /// </summary>
            public static string WindowsIdentityName
            {
                get { return sm_AccountName; }
            }

            private static string sm_AccountName = WindowsIdentity.GetCurrent().Name;

            /// <summary>
            /// </summary>
            public string AccountName
            {
                get { return _sAccountName; }
            }

            string _sAccountName = WindowsIdentityName;

            /// <summary>
            /// </summary>
            public Helper()
            {

            }

            /// <summary>
            /// </summary>
            public Helper(string sRemotePrincipal)
            {
                _sAccountName = sRemotePrincipal;
            }

            class Exception : System.Exception
            {
                public Exception( String SSPI_api_name, int ss ) :
                    base(String.Format("The call to '{0}' has failed (0x{1:X}).\n{2}", SSPI_api_name, ss, new Win32Exception(ss).Message))
                {

                }
            }

            /// <summary>
            /// </summary>
            public void InitializeClient( PackageType package_type,
                                          out byte[]  client_token,
                                          byte[]      server_token,
                                          out bool    bContinueProcessing )
            {
                client_token = null;
                bContinueProcessing = true;

                SECURITY_INTEGER ClientLifeTime = new SECURITY_INTEGER(0);

                int ss = -1;

                if (!_bGotClientCredentials)
                {
                    if ((ss = AcquireCredentialsHandle( _sAccountName,
                                                        package_type.ToString(), //"Kerberos",
                                                        SECPKG_CRED_OUTBOUND,
                                                        IntPtr.Zero,
                                                        IntPtr.Zero,
                                                        0,
                                                        IntPtr.Zero,
                                                        ref _hOutboundCred,
                                                        ref ClientLifeTime)) != SEC_E_OK)
                    {
                        throw new Exception("AcquireCredentialsHandle", ss);
                    }

                    _bGotClientCredentials = true;
                }

                SecBufferDesc ClientToken = new SecBufferDesc(MAX_TOKEN_SIZE);

                try
                {
                    uint ContextAttributes = 0;

                    if (server_token == null)
                    {
                        ss = InitializeSecurityContext( ref _hOutboundCred,
                                                        IntPtr.Zero,
                                                        _sAccountName,          // null string pszTargetName,
                                                        STANDARD_CONTEXT_ATTRIBUTES,
                                                        0,                      //int Reserved1,
                                                        SECURITY_NATIVE_DREP,   //int TargetDataRep
                                                        IntPtr.Zero,            //Always zero first time around...
                                                        0,                      //int Reserved2,
                                                        out _hClientContext,    //pHandle CtxtHandle = SecHandle
                                                        out ClientToken,        //ref SecBufferDesc pOutput, //PSecBufferDesc
                                                        out ContextAttributes,  //ref int pfContextAttr,
                                                        out ClientLifeTime );   //ref IntPtr ptsExpiry ); //PTimeStamp

                    }
                    else
                    {
                        SecBufferDesc ServerToken = new SecBufferDesc(server_token);

                        try
                        {
                            ss = InitializeSecurityContext( ref _hOutboundCred,
                                                            ref _hClientContext,
                                                            _sAccountName,          // null string pszTargetName,
                                                            STANDARD_CONTEXT_ATTRIBUTES,
                                                            0,                      //int Reserved1,
                                                            SECURITY_NATIVE_DREP,   //int TargetDataRep
                                                            ref ServerToken,        //Always zero first time around...
                                                            0,                      //int Reserved2,
                                                            out _hClientContext,    //pHandle CtxtHandle = SecHandle
                                                            out ClientToken,        //ref SecBufferDesc pOutput, //PSecBufferDesc
                                                            out ContextAttributes,  //ref int pfContextAttr,
                                                            out ClientLifeTime);    //ref IntPtr ptsExpiry ); //PTimeStamp
                        }
                        finally
                        {
                            ServerToken.Dispose();
                        }
                    }

                    if (ss != SEC_E_OK && ss != SEC_I_CONTINUE_NEEDED)
                    {
                        throw new Exception("InitializeSecurityContext", ss);
                    }

                    client_token = ClientToken.GetSecBufferByteArray();
                }
                finally
                {
                    ClientToken.Dispose();
                }

                bContinueProcessing = ss != SEC_E_OK;
            }

            /// <summary>
            /// </summary>
            public void InitializeServer( PackageType   package_type,
                                          byte[]        client_token,
                                          out byte[]    server_token,
                                          out bool      bContinueProcessing )
            {
                server_token = null;
                bContinueProcessing = true;
                SECURITY_INTEGER NewLifeTime = new SECURITY_INTEGER(0);

                int ss = -1;

                if (!_bGotServerCredentials)
                {
                    if ((ss = AcquireCredentialsHandle( _sAccountName,
                                                        package_type.ToString(), //"Kerberos",
                                                        SECPKG_CRED_INBOUND,
                                                        IntPtr.Zero,
                                                        IntPtr.Zero,
                                                        0,
                                                        IntPtr.Zero,
                                                        ref _hInboundCred,
                                                        ref NewLifeTime )) != SEC_E_OK)
                    {
                        throw new Exception("AcquireCredentialsHandle", ss);
                    }

                    _bGotServerCredentials = true;
                }

                SecBufferDesc ServerToken = new SecBufferDesc(MAX_TOKEN_SIZE);
                SecBufferDesc ClientToken = new SecBufferDesc(client_token);

                try
                {
                    uint uNewContextAttr = 0;

                    if (!_bGotServerContext)
                    {
                        ss = AcceptSecurityContext( ref _hInboundCred,          // [in] handle to the credentials
                                                    IntPtr.Zero,                // [in/out] handle of partially formed context.  Always NULL the first time through
                                                    ref ClientToken,            // [in] pointer to the input buffers
                                                    STANDARD_CONTEXT_ATTRIBUTES,// [in] required context attributes
                                                    SECURITY_NATIVE_DREP,       // [in] data representation on the target
                                                    out _hServerContext,        // [in/out] receives the new context handle
                                                    out ServerToken,            // [in/out] pointer to the output buffers
                                                    out uNewContextAttr,        // [out] receives the context attributes
                                                    out NewLifeTime );          // [out] receives the life span of the security context
                    }
                    else
                    {
                        ss = AcceptSecurityContext( ref _hInboundCred,          // [in] handle to the credentials
                                                    ref _hServerContext,        // [in/out] handle of partially formed context.  Always NULL the first time through
                                                    ref ClientToken,            // [in] pointer to the input buffers
                                                    STANDARD_CONTEXT_ATTRIBUTES,// [in] required context attributes
                                                    SECURITY_NATIVE_DREP,       // [in] data representation on the target
                                                    out _hServerContext,        // [in/out] receives the new context handle
                                                    out ServerToken,            // [in/out] pointer to the output buffers
                                                    out uNewContextAttr,        // [out] receives the context attributes
                                                    out NewLifeTime);           // [out] receives the life span of the security context
                    }

                    if (ss != SEC_E_OK && ss != SEC_I_CONTINUE_NEEDED)
                    {
                        throw new Exception("AcceptSecurityContext", ss);
                    }

                    if (!_bGotServerContext)
                    {
                        _bGotServerContext = true;
                    }

                    server_token = ServerToken.GetSecBufferByteArray();

                    bContinueProcessing = ss != SEC_E_OK;
                }
                finally
                {
                    ClientToken.Dispose();
                    ServerToken.Dispose();
                }
            }

            /// <summary>
            /// </summary>
            public SecPkgInfo GetPackageInfo(bool bUseClientContext)
            {
                SecPkgContext_PackageInfo info;

                SECURITY_HANDLE EncryptionContext = _hServerContext;

                if (bUseClientContext)
                {
                    EncryptionContext = _hClientContext;
                }

                int ss = -1;

                if ((ss = QueryContextAttributes(ref EncryptionContext, SECPKG_ATTR_PACKAGE_INFO, out info)) != SEC_E_OK)
                {
                    throw new Exception("QueryContextAttributes", ss);
                }

                SecPkgInfo PackageInfo = (SecPkgInfo)Marshal.PtrToStructure(info.PackageInfo, typeof(SecPkgInfo));

                return PackageInfo;
            }

            /// <summary>
            /// </summary>
            public SecPkgContext_Names GetNames(bool bUseClientContext)
            {
                SecPkgContext_Names names;

                SECURITY_HANDLE EncryptionContext = _hServerContext;

                if (bUseClientContext)
                {
                    EncryptionContext = _hClientContext;
                }

                int ss = -1;

                if ((ss = QueryContextAttributes(ref EncryptionContext, SECPKG_ATTR_NAMES, out names)) != SEC_E_OK)
                {
                    throw new Exception("QueryContextAttributes", ss);
                }

                return names;
            }

            /// <summary>
            /// </summary>
            public void EncryptMessage(byte[] message, bool bUseClientContext, out byte[] encryptedBuffer)
            {
                encryptedBuffer = null;

                SECURITY_HANDLE EncryptionContext = _hServerContext;

                if (bUseClientContext)
                {
                    EncryptionContext = _hClientContext;
                }

                SecPkgContext_Sizes ContextSizes = new SecPkgContext_Sizes();

                int ss = -1;

                if ((ss = QueryContextAttributes(ref EncryptionContext, SECPKG_ATTR_SIZES, out ContextSizes)) != SEC_E_OK)
                {
                    throw new Exception("QueryContextAttributes", ss);
                }

                MultipleSecBufferHelper[] ThisSecHelper = new MultipleSecBufferHelper[2];
                ThisSecHelper[0] = new MultipleSecBufferHelper(message, SecBufferType.SECBUFFER_DATA);
                ThisSecHelper[1] = new MultipleSecBufferHelper(new byte[ContextSizes.cbSecurityTrailer], SecBufferType.SECBUFFER_TOKEN);

                SecBufferDesc DescBuffer = new SecBufferDesc(ThisSecHelper);

                try
                {
                    if ((ss = EncryptMessage(ref EncryptionContext, 0, ref DescBuffer, 0)) != SEC_E_OK)
                    {
                        throw new Exception("EncryptMessage", ss);
                    }

                    encryptedBuffer = DescBuffer.GetSecBufferByteArray();
                }
                finally
                {
                    DescBuffer.Dispose();
                }
            }

            /// <summary>
            /// </summary>
            public void DecryptMessage(int messageLength, byte[] encryptedBuffer, bool bUseClientContext,
                                       out byte[] decryptedBuffer)
            {
                decryptedBuffer = null;

                SECURITY_HANDLE DecryptionContext = _hServerContext;

                if (bUseClientContext)
                {
                    DecryptionContext = _hClientContext;
                }

                byte[] EncryptedMessage = new byte[messageLength];
                Array.Copy(encryptedBuffer, 0, EncryptedMessage, 0, messageLength);

                int SecurityTrailerLength = encryptedBuffer.Length - messageLength;

                byte[] SecurityTrailer = new byte[SecurityTrailerLength];
                Array.Copy(encryptedBuffer, messageLength, SecurityTrailer, 0, SecurityTrailerLength);

                MultipleSecBufferHelper[] ThisSecHelper = new MultipleSecBufferHelper[2];
                ThisSecHelper[0] = new MultipleSecBufferHelper(EncryptedMessage, SecBufferType.SECBUFFER_DATA);
                ThisSecHelper[1] = new MultipleSecBufferHelper(SecurityTrailer, SecBufferType.SECBUFFER_TOKEN);
                SecBufferDesc DescBuffer = new SecBufferDesc(ThisSecHelper);

                int ss = -1;

                try
                {
                    uint EncryptionQuality = 0;

                    if ((ss = DecryptMessage(ref DecryptionContext, ref DescBuffer, 0, out EncryptionQuality)) != SEC_E_OK)
                    {
                        throw new Exception("DecryptMessage", ss);
                    }

                    decryptedBuffer = new byte[messageLength];
                    Array.Copy(DescBuffer.GetSecBufferByteArray(), 0, decryptedBuffer, 0, messageLength);
                }
                finally
                {
                    DescBuffer.Dispose();
                }
            }

            /// <summary>
            /// </summary>
            public void SignMessage(byte[] message, bool bUseClientContext, out byte[] signedBuffer,
                                    ref SECURITY_HANDLE hServerContext)
            {
                signedBuffer = null;

                SECURITY_HANDLE EncryptionContext = _hServerContext;

                if (bUseClientContext)
                {
                    EncryptionContext = _hClientContext;
                }

                SecPkgContext_Sizes ContextSizes = new SecPkgContext_Sizes();

                int ss = -1;

                if ((ss = QueryContextAttributes(ref EncryptionContext, SECPKG_ATTR_SIZES, out ContextSizes)) != SEC_E_OK)
                {
                    throw new Exception("QueryContextAttributes", ss);
                }

                MultipleSecBufferHelper[] ThisSecHelper = new MultipleSecBufferHelper[2];
                ThisSecHelper[0] = new MultipleSecBufferHelper(message, SecBufferType.SECBUFFER_DATA);
                ThisSecHelper[1] = new MultipleSecBufferHelper(new byte[ContextSizes.cbMaxSignature], SecBufferType.SECBUFFER_TOKEN);

                SecBufferDesc DescBuffer = new SecBufferDesc(ThisSecHelper);

                try
                {
                    if ((ss = MakeSignature(ref EncryptionContext, 0, ref DescBuffer, 0)) != SEC_E_OK)
                    {
                        throw new Exception("MakeSignature", ss);
                    }

                    //SSPIHelper.SignAndVerify(ref _hClientContext,ref hServerContext,ref DescBuffer);
                    uint EncryptionQuality = 0;
                    VerifySignature(ref this._hServerContext, ref DescBuffer, 0, out EncryptionQuality);

                    signedBuffer = DescBuffer.GetSecBufferByteArray();
                }
                finally
                {
                    DescBuffer.Dispose();
                }
            }

            /// <summary>
            /// </summary>
            public void VerifyMessage(int messageLength, byte[] signedBuffer, bool bUseClientContext,
                                        out byte[] verifiedBuffer)
            {
                verifiedBuffer = null;

                SECURITY_HANDLE DecryptionContext = _hServerContext;

                if (bUseClientContext)
                {
                    DecryptionContext = _hClientContext;
                }

                byte[] SignedMessage = new byte[messageLength];
                Array.Copy(signedBuffer, 0, SignedMessage, 0, messageLength);

                int SignatureLength = signedBuffer.Length - messageLength;

                byte[] Signature = new byte[SignatureLength];
                Array.Copy(signedBuffer, messageLength, Signature, 0, SignatureLength);

                MultipleSecBufferHelper[] ThisSecHelper = new MultipleSecBufferHelper[2];
                ThisSecHelper[0] = new MultipleSecBufferHelper(SignedMessage, SecBufferType.SECBUFFER_DATA);
                ThisSecHelper[1] = new MultipleSecBufferHelper(Signature, SecBufferType.SECBUFFER_TOKEN);
                SecBufferDesc DescBuffer = new SecBufferDesc(ThisSecHelper);
                try
                {
                    uint EncryptionQuality = 0;

                    int ss = VerifySignature(ref DecryptionContext, ref DescBuffer, 0, out EncryptionQuality);

                    if (ss != SEC_E_OK)
                    {
                        throw new Exception("VerifySignature", ss);
                    }

                    verifiedBuffer = new byte[messageLength];
                    Array.Copy(DescBuffer.GetSecBufferByteArray(), 0, verifiedBuffer, 0, messageLength);
                }
                finally
                {
                    DescBuffer.Dispose();
                }
            }

        }

        /// <summary>
        /// </summary>
        public abstract class _Base
        {
            /// <summary>
            /// </summary>
            public abstract bool IsClient();
            /// <summary>
            /// </summary>
            public bool IsServer()
            {
                return !IsClient();
            }

            /// <summary>
            /// </summary>
            public SecPkgInfo GetPackageInfo()
            {
                return m_Helper.GetPackageInfo(IsClient());
            }

            /// <summary>
            /// </summary>
            public string GetPackageType()
            {
                return GetPackageInfo().Name;
            }

            /// <summary>
            /// </summary>
            public string GetPackageComment()
            {
                return GetPackageInfo().Comment;
            }

            /// <summary>
            /// </summary>
            public SecPkgContext_Names GetNames()
            {
                return m_Helper.GetNames(IsClient());
            }

            /// <summary>
            /// </summary>
            public string GetUserName()
            {
                return GetNames().UserName;
            }

            /// <summary>
            /// </summary>
            public void EncryptMessage(byte[] message, out byte[] encryptedBuffer)
            {
                m_Helper.EncryptMessage(message, IsClient(), out encryptedBuffer);
            }

            /// <summary>
            /// </summary>
            public void DecryptMessage(int messageLength, byte[] encryptedBuffer, out byte[] decryptedBuffer)
            {
                m_Helper.DecryptMessage(messageLength, encryptedBuffer, IsClient(), out decryptedBuffer);
            }

            /// <summary>
            /// </summary>
            protected _Base(SSPI.PackageType package_type, string sRemotePrincipalName)
            {
                m_Helper = (sRemotePrincipalName == null) ? new Helper() :
                                                            new Helper(sRemotePrincipalName);

                m_package_type = package_type;
            }

            /// <summary>
            /// </summary>
            protected readonly Helper m_Helper;
            /// <summary>
            /// </summary>
            protected readonly SSPI.PackageType m_package_type;
        }

        /// <summary>
        /// </summary>
        public class Server : _Base
        {
            /// <summary>
            /// </summary>
            public override bool IsClient()
            {
                return false;
            }

            /// <summary>
            /// </summary>
            public Server(SSPI.PackageType package_type)
                : base(package_type, null)
            {
            }

            /// <summary>
            /// </summary>
            public string MyPrincipalName
            {
                get { return m_Helper.AccountName; }
            }

            /// <summary>
            /// </summary>
            public bool Accept(byte[] client_token, out byte[] server_token)
            {
                bool continue_handshake;
                m_Helper.InitializeServer(m_package_type, client_token, out server_token, out continue_handshake);
                return continue_handshake == false;
            }

            /// <summary>
            /// </summary>
            public bool Accept(byte[] client_token, out byte[] server_token, out bool continue_handshake)
            {
                m_Helper.InitializeServer(m_package_type, client_token, out server_token, out continue_handshake);
                return continue_handshake == false;
            }
        }

        /// <summary>
        /// </summary>
        public class Client : _Base
        {
            /// <summary>
            /// </summary>
            public override bool IsClient()
            {
                return true;
            }

            /// <summary>
            /// </summary>
            public Client(SSPI.PackageType package_type, string sRemotePrincipalName)
                : base(package_type, sRemotePrincipalName)
            {
                Debug.Assert(String.IsNullOrWhiteSpace(sRemotePrincipalName) == false);
            }

            /// <summary>
            /// </summary>
            public bool Connect(byte[] server_token, out byte[] client_token)
            {
                bool continue_handshake;
                m_Helper.InitializeClient(m_package_type, out client_token, server_token, out continue_handshake);
                return continue_handshake == false;
            }

            /// <summary>
            /// </summary>
            public bool Connect(byte[] server_token, out byte[] client_token, out bool continue_handshake)
            {
                m_Helper.InitializeClient(m_package_type, out client_token, server_token, out continue_handshake);
                return continue_handshake == false;
            }
        }

        /// <summary>
        /// A test helper method
        /// </summary>
        public static void TestHelper()
        {
            try
            {

                Helper MyClientHelper = new Helper();
                Helper MyServerHelper = new Helper();

                byte[] ClientToken = null;
                byte[] ServerToken = null;
                bool bContinueClient = true, bContinueServer = true;
                while (bContinueClient || bContinueServer)
                {
                    MyClientHelper.InitializeClient(PackageType.Kerberos, out ClientToken, ServerToken, out bContinueClient);
                    MyServerHelper.InitializeServer(PackageType.Kerberos, ClientToken, out ServerToken, out bContinueServer);
                }
                byte[] Message = System.Text.Encoding.ASCII.GetBytes("hi there");
                byte[] EncryptedBuffer = null;

                MyClientHelper.EncryptMessage(Message, true, out EncryptedBuffer);

                byte[] DecryptedBuffer;
                MyServerHelper.DecryptMessage(Message.Length, EncryptedBuffer, false, out DecryptedBuffer);
                Console.WriteLine(System.Text.Encoding.ASCII.GetString(DecryptedBuffer));
            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.AllMessages());
            }
        }

        /// <summary>
        /// A Client/Server test method
        /// </summary>
        public static void TestCS()
        {
            PackageType package_type;
            package_type = PackageType.NTLM;
            package_type = PackageType.Kerberos;
            //package_type = PackageType.Negotiate;

            try
            {
                Server server = new Server(package_type);
                string s = server.MyPrincipalName;

                Client client = new Client(package_type, s);

                string pt;

                byte[] ClientToken = null;
                byte[] ServerToken = null;
                bool bContinueClient = true, bContinueServer = true;
                while (bContinueClient || bContinueServer)
                {
                    if (bContinueClient)
                        client.Connect(ServerToken, out ClientToken, out bContinueClient);

                    if (bContinueServer)
                        server.Accept(ClientToken, out ServerToken, out bContinueServer);
                }

                pt = server.GetPackageType();
                pt = server.GetPackageComment();
                pt = client.GetPackageType();
                pt = client.GetPackageComment();
                pt = server.GetUserName();
                pt = client.GetUserName();

                byte[] Message = System.Text.Encoding.ASCII.GetBytes("hi there");
                byte[] EncryptedBuffer = null;

                client.EncryptMessage(Message, out EncryptedBuffer);

                byte[] DecryptedBuffer;
                server.DecryptMessage(Message.Length, EncryptedBuffer, out DecryptedBuffer);
                Console.WriteLine(System.Text.Encoding.ASCII.GetString(DecryptedBuffer));
            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.AllMessages());
            }
        }
    }
}
