﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EriCommon
{
    /// <summary>
    /// The StringHelper static class contains static methods dealing with strings.
    /// </summary>
    public static class StringHelper
    {
        /// <summary>
        /// Converts a byte array to a string containing pairs of hexa characters (compatible to HexStringToBytes input ).
        /// </summary>
        public static string BytesToHexString(byte[] bytes)
        {
            if (bytes == null)
            {
                throw new ArgumentNullException("bytes");
            }

            return BitConverter.ToString(bytes).Replace("-", "");
        }

        /// <summary>
        /// Converts a string containing pairs of hexa characters to a byte array.
        /// </summary>
        public static byte[] HexStringToBytes(string hexString)
        {
            if (hexString == null)
            {
                throw new ArgumentNullException("hexString");
            }

            if ((hexString.Length & 1) != 0)
            {
                throw new ArgumentOutOfRangeException("hexString", hexString, "hexString must contain an even number of characters.");
            }

            byte[] result = new byte[hexString.Length / 2];

            for (int i = 0; i < hexString.Length; i += 2)
            {
                result[i / 2] = byte.Parse(hexString.Substring(i, 2), System.Globalization.NumberStyles.HexNumber);
            }

            return result;
        }
    }
}
