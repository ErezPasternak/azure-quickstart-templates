﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Text;
using TracerX;
using System.Threading;

namespace EriCommon
{
    /// <summary>
    /// The SafeCall static class contains static methods dealing with files.
    /// </summary>
    public static class SafeCall
    {
        #region Public Delegates

        /// <summary>
        /// DoIt delegate with context, returning nothing.
        /// </summary>
        public delegate void DoIt<CONTEXT>(CONTEXT context);
        /// <summary>
        /// ReturnIt delegate with context, returning something.
        /// </summary>
        public delegate RETVAL ReturnIt<RETVAL, CONTEXT>(CONTEXT context);
        /// <summary>
        /// DoIt_NC delegate without context, returning nothing.
        /// </summary>
        public delegate void DoIt_NC();
        /// <summary>
        /// ReturnIt_NC delegate without context, returning something.
        /// </summary>
        public delegate RETVAL ReturnIt_NC<RETVAL>();
        /// <summary>
        /// RerunAfterException delegate with context.
        /// </summary>
        public delegate bool RerunAfterException<CONTEXT>(Exception e, CONTEXT context);
        /// <summary>
        /// RerunAfterException_NC delegate without context.
        /// </summary>
        public delegate bool RerunAfterException_NC(Exception e);
        /// <summary>
        /// Main delegate.
        /// </summary>
        public delegate void Main(string[] args);

        #endregion

        #region Public Methods

        /// <summary>
        /// The ServiceProgramMain static method.
        /// </summary>
        public static void ServiceProgramMain(Main main, string[] args, bool use_AppCfg = true, bool stop_threads_on_main_exit = false, bool system_information_reporting_enabled = true)
        {
            try
            {
                init_service_program(use_AppCfg, system_information_reporting_enabled);
                Exception e = Run<string[]>(new DoIt<string[]>(main), args);

                if (e != null && sm_unhandled_exception_app_handler != null)
                    sm_unhandled_exception_app_handler(e);
            }
            finally
            {
                if (stop_threads_on_main_exit)
                {
                    SystemInformation.StopReporting();
                    TimersThread.StopDefault();
                }
            }
        }

        /// <summary>
        /// The ServiceProgramMain static method.
        /// </summary>
        public static void ServiceProgramMain(string logger_name, out Logger logger, Main main, string[] args, bool use_AppCfg = true, bool system_information_reporting_enabled = true)
        {
            init_service_program(use_AppCfg, system_information_reporting_enabled);
            logger = Logger.GetLogger(logger_name);
            Exception e = Run<string[]>(new DoIt<string[]>(main), args);

            if (e != null && sm_unhandled_exception_app_handler != null)
                sm_unhandled_exception_app_handler(e);
        }

        #region Run method returning something
        /// <summary>
        /// Run a method with context that returns something.
        /// </summary>
        public static RETVAL Run<RETVAL, CONTEXT>(ReturnIt<RETVAL, CONTEXT> return_it, CONTEXT context, RETVAL return_on_exception)
        {
            try
            {
                return return_it(context);
            }
            catch (Exception e)
            {
                ExceptionHandler(e, null);
            }

            return return_on_exception;
        }

        /// <summary>
        /// Run a method without context that returns something.
        /// </summary>
        public static RETVAL Run<RETVAL>(ReturnIt_NC<RETVAL> return_it, RETVAL return_on_exception)
        {
            try
            {
                return return_it();
            }
            catch (Exception e)
            {
                ExceptionHandler(e, null);
            }

            return return_on_exception;
        }
        #endregion

        #region Run method returning nothing
        /// <summary>
        /// Run a void method with context.
        /// </summary>
        public static Exception Run<CONTEXT>(DoIt<CONTEXT> do_it, CONTEXT context, RerunAfterException<CONTEXT> rerun_after_exception)
        {
            for(;;)
            {
                try
                {
                    do_it(context);
                    break;
                }
                catch (Exception e)
                {
                    ExceptionHandler(e, null);

                    if (rerun_after_exception(e, context))
                        continue;

                    return e;
                }
            }

            return null;
        }

        /// <summary>
        /// Run method with context, returning Exception.
        /// </summary>
        public static Exception Run<CONTEXT>(DoIt<CONTEXT> do_it, CONTEXT context)
        {
            return Run<CONTEXT>(do_it, context, DoNotRerunAfterException);
        }

        /// <summary>
        /// Run method without context, returning Exception.
        /// </summary>
        public static Exception Run(DoIt_NC do_it, RerunAfterException_NC rerun_after_exception)
        {
            for (;;)
            {
                try
                {
                    do_it();
                    break;
                }
                catch (Exception e)
                {
                    ExceptionHandler(e, null);

                    if (rerun_after_exception(e))
                        continue;

                    return e;
                }
            }

            return null;
        }

        /// <summary>
        /// Run method without context, returning Exception.
        /// </summary>
        public static Exception Run(DoIt_NC do_it)
        {
            return Run(do_it, DoNotRerunAfterException_NC);
        }

        /// <summary>
        /// DoNotRerunAfterException method with context.
        /// </summary>
        public static bool DoNotRerunAfterException<CONTEXT>(Exception e, CONTEXT context)
        {
            return false;
        }

        /// <summary>
        /// DoNotRerunAfterException_NC method without context.
        /// </summary>
        public static bool DoNotRerunAfterException_NC(Exception e)
        {
            return false;
        }

        /// <summary>
        /// The standard exception handler.
        /// </summary>
        public static void ExceptionHandler(Exception e, string text)
        {
            exceptionHandler(e, 0, text, false);
        }

        #endregion

        /// <summary>
        /// RegisterUnhandledExceptionHandler method, registers the unhandledExceptionHandler.
        /// </summary>
        public static void RegisterUnhandledExceptionHandler()
        {
            AppDomain currentDomain = AppDomain.CurrentDomain;
            currentDomain.UnhandledException += unhandledExceptionHandler;
        }

        #endregion

        #region Private Methods

        private static void init_service_program(bool use_AppCfg, bool system_information_reporting_enabled)
        {
            if (Thread.CurrentThread.Name == null)
                ThreadHelper.SetMainThreadName();
            if (use_AppCfg)
                AppCfg.Initialize();
            LogHelper.OpenServiceLog();
            RegisterUnhandledExceptionHandler();
            SystemInformation.StartReporting(0, system_information_reporting_enabled);
        }

        /// <summary>
        /// The unhandled exception application handler prototype
        /// </summary>
        public delegate void UnhandledExceptionAppHandler(Exception e);

        private static UnhandledExceptionAppHandler sm_unhandled_exception_app_handler = null;

        /// <summary>
        /// Sets the unhandled exception application handler
        /// </summary>
        public static void SetUnhandledExceptionAppHandler(UnhandledExceptionAppHandler app_handler)
        {
            sm_unhandled_exception_app_handler = new UnhandledExceptionAppHandler(app_handler);
        }

        private static void unhandledExceptionHandler(object sender, UnhandledExceptionEventArgs args)
        {
            exceptionHandler((Exception)args.ExceptionObject, 0, "Unhandled Exception", true);

            if (sm_unhandled_exception_app_handler != null)
                sm_unhandled_exception_app_handler((Exception)args.ExceptionObject);
        }

        private static void exceptionHandler(Exception e, int level, string text, bool fatal)
        {
            if (level > 0)
                text = String.Format("Inner Exception #{0}", level);

            if (text == null)
            {
                if (fatal)
                    sm_logger.Fatal(e/*, e.StackTrace*/);
                else
                    sm_logger.Error(e/*, e.StackTrace*/);
            }
            else
            {
                if (fatal)
                    sm_logger.FatalEx(text, e, true);
                else
                    sm_logger.ErrorEx(text, e, true);
            }

            if (e.InnerException != null)
            {
                exceptionHandler(e.InnerException, level + 1, null, fatal);
            }
        }

        private static Logger sm_logger = Logger.GetLogger(ReflectionHelper.GetClassName());

        #endregion
    }
}
