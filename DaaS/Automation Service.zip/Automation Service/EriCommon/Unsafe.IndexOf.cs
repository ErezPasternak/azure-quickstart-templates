﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using TracerX;

namespace EriCommon
{
    /// <summary>
    /// The Unsafe class provide unsafe, low-level static methods.
    /// </summary>
    public unsafe partial class Unsafe
    {
        #region IndexOf
        /// <summary>
        /// Returns the index of a sub byte[]
        /// </summary>
        public static int IndexOf(byte[] me, byte[] to_be_found, int my_start_index, int my_count, int to_be_found_start_index, int to_be_found_count)
        {
            int retval = -1;

            if (me == null)
                return retval;
            if (me.Length <= my_start_index)
                return retval;
            if (my_count == 0)
                return retval;

            if (to_be_found == null)
                return retval;
            if (to_be_found.Length <= to_be_found_start_index)
                return retval;
            if (to_be_found_count == 0)
                return retval;

            if (my_start_index + my_count > me.Length)
                my_count = me.Length - my_start_index;

            if (to_be_found_start_index + to_be_found_count > to_be_found.Length)
                to_be_found_count = to_be_found.Length - to_be_found_start_index;

            if (my_count < to_be_found_count)
                return retval;

            if (me == to_be_found &&
                my_start_index == to_be_found_start_index &&
                my_count >= to_be_found_count)
            {
                return my_start_index;
            }

            byte first_byte = to_be_found[0];
            to_be_found_start_index++;
            to_be_found_count--;

            unsafe
            {
                fixed (byte* me_ptr = me) fixed (byte* to_be_found_ptr = to_be_found)
                {
                    byte* p1 = me_ptr,
                          p2 = to_be_found_ptr+1;

                    int idx;
                    int pos;
                    int max_pos = me.Length;

                    for (; ; )
                    {
                        for(pos = my_start_index; pos < max_pos; pos++)
                            if(me_ptr[pos] == first_byte)
                                break;

                        if (pos == max_pos)
                            return retval;

                        if (to_be_found_count == 0)
                            return pos;

                        my_start_index = pos + 1;
                        my_count = me.Length - my_start_index;

                        if (my_count < to_be_found_count)
                            return retval;

                        p1 = me_ptr + pos + 1;

                        for (idx = 0; idx < to_be_found_count; idx++)
                        {
                            if (p1[idx] != p2[idx])
                                break;
                        }

                        if (idx == to_be_found_count)
                            return pos;

                        if (my_count == to_be_found_count)
                            return retval;
                    }
                }
            }
        }

        /// <summary>
        /// Returns the index of a sub byte[]
        /// </summary>
        public static int IndexOf(byte[] me, byte[] to_be_found, int my_start_index, int my_count)
        {
            return IndexOf(me, to_be_found, my_start_index, my_count, 0, to_be_found.Length);
        }

        /// <summary>
        /// Returns the index of a sub byte[]
        /// </summary>
        public static int IndexOf(byte[] me, byte[] to_be_found)
        {
            return IndexOf(me, to_be_found, 0, me.Length, 0, to_be_found.Length);
        }

        #endregion IndexOf
    }

//         [DllImport("msvcrt.dll", CallingConvention = CallingConvention.Cdecl)]
//         static extern IntPtr memchr(IntPtr a, byte chr, int count);
//
//         [DllImport("msvcrt.dll", CallingConvention = CallingConvention.Cdecl)]
//         static extern int memcmp(IntPtr buf1, IntPtr buf2, int count);
//
//         /// <summary>
//         /// Returns the index of a sub byte[]
//         /// </summary>
//         public static int IndexOf_BAD /*125%*/(byte[] me, byte[] to_be_found, int my_start_index, int my_count, int to_be_found_start_index, int to_be_found_count)
//         {
//             int retval = -1;
//
//             if (me == null)
//                 return retval;
//             if (me.Length <= my_start_index)
//                 return retval;
//             if (my_count == 0)
//                 return retval;
//
//             if (to_be_found == null)
//                 return retval;
//             if (to_be_found.Length <= to_be_found_start_index)
//                 return retval;
//             if (to_be_found_count == 0)
//                 return retval;
//
//             if (my_start_index + my_count > me.Length)
//                 my_count = me.Length - my_start_index;
//
//             if (to_be_found_start_index + to_be_found_count > to_be_found.Length)
//                 to_be_found_count = to_be_found.Length - to_be_found_start_index;
//
//             if (my_count < to_be_found_count)
//                 return retval;
//
//             if (me == to_be_found &&
//                 my_start_index == to_be_found_start_index &&
//                 my_count >= to_be_found_count)
//             {
//                 return my_start_index;
//             }
//
//             byte first_byte = to_be_found[0];
//             to_be_found_start_index++;
//             to_be_found_count--;
//
//             unsafe
//             {
//                 fixed (byte* me_ptr = me) fixed (byte* to_be_found_ptr = to_be_found)
//                 {
//                     IntPtr p_me = new IntPtr(me_ptr + my_start_index);
//                     IntPtr p_be_found = new IntPtr(to_be_found_ptr + to_be_found_start_index);
//
//                     for (; ; )
//                     {
//                         IntPtr p = memchr(p_me, first_byte, my_count);
//
//                         if (p.ToPointer() == null)
//                             return retval;
//
//                         if (to_be_found_count == 0)
//                             return (int)((byte*)p.ToPointer() - me_ptr);
//
//                         p_me = p + 1;
//                         my_count = me.Length - (int)((byte*)p_me.ToPointer() - me_ptr);
//
//                         if (my_count < to_be_found_count)
//                             return retval;
//
//                         int cmpval = memcmp(p_me, p_be_found, to_be_found_count);
//                         if(cmpval == 0)
//                             return (int)((byte*)p.ToPointer() - me_ptr);
//
//                         if (my_count == to_be_found_count)
//                             return retval;
//                     }
//                 }
//             }
//         }
}
