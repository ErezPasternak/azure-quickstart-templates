﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net.Security;
using System.Security;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using TracerX;

namespace EriCommon
{
    /// <summary>
    /// SslStreamEx replaces the System.Net.Security.SslStream class.
    /// It is supporting multiple asynchronous writes, that the System.Net.Security.SslStream avoids.
    /// </summary>
    public partial class SslStreamEx_OLD : Stream
    {
        #region Public
        /// <summary>
        /// IOwner interface, used after the authentication is done.
        /// </summary>
        public interface IOwner
        {
            /// <summary>
            /// Returns a memory buffer.
            /// </summary>
            byte[] GetWriteBuffer(uint size, ref Object asyncState);
            /// <summary>
            /// Called before writing the memory buffer to the outer stream.
            /// </summary>
            void OnReadyToWriteOnOuterStream(Object asyncState);
        }

        /// <summary>
        /// SslStreamEx ctor for client stream
        /// </summary>
        public SslStreamEx_OLD(Stream outer_stream, bool leaveInnerStreamOpen, IOwner owner, bool multiple_read_required = false)
        {
            init(outer_stream, owner, multiple_read_required);
            m_ssl_stream = new SslStream(m_inner_stream, leaveInnerStreamOpen);
        }

        /// <summary>
        /// SslStreamEx ctor for server stream
        /// </summary>
        public SslStreamEx_OLD(Stream outer_stream, bool leaveInnerStreamOpen, RemoteCertificateValidationCallback userCertificateValidationCallback, LocalCertificateSelectionCallback userCertificateSelectionCallback, IOwner owner, bool multiple_read_required = false)
        {
            init(outer_stream, owner, multiple_read_required);
            m_ssl_stream = new SslStream(m_inner_stream, leaveInnerStreamOpen, userCertificateValidationCallback, userCertificateSelectionCallback);
        }

        /// <summary>
        /// Gets/sets the IOwner interface, used after the authentication is done.
        /// </summary>
        public IOwner Owner
        {
            get
            {
                return (IsAuthenticated) ? m_owner : m_hold_owner;
            }

            set
            {
                if (IsAuthenticated) m_owner      = value;
                else                 m_hold_owner = value;
            }
        }

        /// <summary>
        /// Authentificates the peer (the peer is the client).
        /// </summary>
        public void AuthenticateAsServer(X509Certificate serverCertificate)
        {
            m_ssl_stream.AuthenticateAsServer(serverCertificate);
            restore_owner();
        }

        /// <summary>
        /// Authentificates the peer (the peer is the client).
        /// </summary>
        public void AuthenticateAsServer(X509Certificate serverCertificate, bool record_raw_data)
        {
            if (record_raw_data)
                m_inner_stream.m_raw_data = new byte[0];

            AuthenticateAsServer(serverCertificate);

            m_inner_stream.m_raw_data = null;
        }

        /// <summary>
        /// Authentificates the peer (the peer is the server).
        /// </summary>
        public void AuthenticateAsClient(string targetHost)
        {
            m_ssl_stream.AuthenticateAsClient(targetHost);
            restore_owner();
        }

        /// <summary>
        /// Same as SslStream.BeginAuthenticateAsServer
        /// </summary>
        public IAsyncResult BeginAuthenticateAsServer(X509Certificate serverCertificate, bool clientCertificateRequired, SslProtocols enabledSslProtocols, bool checkCertificateRevocation, AsyncCallback asyncCallback, object asyncState)
        {
            AuthenticateContext authenticate_context = new AuthenticateContext(asyncCallback, asyncState);
            return m_ssl_stream.BeginAuthenticateAsServer(serverCertificate, clientCertificateRequired, enabledSslProtocols, checkCertificateRevocation, AuthenticateContext.sm_Callback, authenticate_context);
        }

        /// <summary>
        /// Same as SslStream.BeginAuthenticateAsServer
        /// </summary>
        public IAsyncResult BeginAuthenticateAsServer(X509Certificate serverCertificate, bool clientCertificateRequired, SslProtocols enabledSslProtocols, bool checkCertificateRevocation, AsyncCallback asyncCallback, object asyncState, bool record_raw_data)
        {
            if (record_raw_data)
                m_inner_stream.m_raw_data = new byte[0];

            return BeginAuthenticateAsServer(serverCertificate, clientCertificateRequired, enabledSslProtocols, checkCertificateRevocation, asyncCallback, asyncState);
        }

        /// <summary>
        /// Same as SslStream.BeginAuthenticateAsClient
        /// </summary>
        public IAsyncResult BeginAuthenticateAsClient(string targetHost, AsyncCallback asyncCallback, object asyncState)
        {
            AuthenticateContext authenticate_context = new AuthenticateContext(asyncCallback, asyncState);
            return m_ssl_stream.BeginAuthenticateAsClient(targetHost, AuthenticateContext.sm_Callback, authenticate_context);
        }

        /// <summary>
        /// Same as SslStream.EndAuthenticateAsServer
        /// </summary>
        public void EndAuthenticateAsServer(IAsyncResult asyncResult)
        {
            restore_owner();
            AuthenticateContext authenticate_context = (AuthenticateContext)asyncResult;
            m_ssl_stream.EndAuthenticateAsServer(authenticate_context.AsyncResult);
            m_inner_stream.m_raw_data = null;
        }

        /// <summary>
        /// Returns the handshake raw data, in case of handshake failure.
        /// </summary>
        public byte[] GetHandshakeRawData()
        {
            Debug.Assert(m_inner_stream.m_raw_data != null);
            byte[] raw_data = m_inner_stream.m_raw_data;
            m_inner_stream.m_raw_data = null;
            return raw_data;
        }

        /// <summary>
        /// Same as SslStream.EndAuthenticateAsClient
        /// </summary>
        public void EndAuthenticateAsClient(IAsyncResult asyncResult)
        {
            restore_owner();
            AuthenticateContext authenticate_context = (AuthenticateContext)asyncResult;
            m_ssl_stream.EndAuthenticateAsClient(authenticate_context.AsyncResult);
        }

        /// <summary>
        /// Same as SslStream.IsAuthenticated
        /// </summary>
        public bool IsAuthenticated
        {
            get { return m_ssl_stream.IsAuthenticated; }
        }

        /// <summary>
        /// The SSL chunk header size.
        /// According to my research on OPENSSL, the header size is 35 bytes.
        /// </summary>
        public const uint SslChunckHeaderSize = 128;

        /// <summary>
        /// The SSL chunk max size (worst case).
        /// This is the worst case.
        /// </summary>
        public const uint SslChunckMaxSize_WorstCase = 1 * 1024; // 1KB

        /// <summary>
        /// The SSL chunk max size (as used by .NET).
        /// According to Eyal's research on .NET, this is the chunk size used by .NET.
        /// </summary>
        public const uint SslChunckMaxSize_DotNetCase = 16 * 1024; // 16KB, empiric observation of Eyal

        /// <summary>
        /// The SSL chunk max size used for calculation (GetEncrypedSize and GetCleartextSize methods).
        /// </summary>
        public const uint SslChunckMaxSize = SslChunckMaxSize_WorstCase;

        /// <summary>
        /// Returns the corresponding encrypted size of the cleartext_size.
        /// The value is calculated using empiric constants.
        /// </summary>
        public static uint GetEncrypedSize(uint cleartext_size, uint chunk_max_size = SslChunckMaxSize, uint chunk_header_size = SslChunckHeaderSize)
        {
            uint n_chuncks        = (cleartext_size / chunk_max_size) + (((cleartext_size % chunk_max_size) != 0) ? 1U : 0U),
                 all_headers_size = n_chuncks * chunk_header_size;

            return cleartext_size + all_headers_size;
        }

        /// <summary>
        /// Returns the corresponding clear-text size of the encrypted_size.
        /// The value is calculated using empiric constants.
        /// </summary>
        public static uint GetCleartextSize(uint encrypted_size, uint chunk_max_size = SslChunckMaxSize, uint chunk_header_size = SslChunckHeaderSize)
        {
            Debug.Assert(encrypted_size > chunk_header_size);
            Debug.Assert(chunk_max_size > chunk_header_size);

            double d = (double)(encrypted_size - chunk_header_size) /
                       (1.0 + ((double)chunk_header_size / (double)chunk_max_size));

            uint size = (uint)d;
            if (d > (double)size)   // was rounded down
                size++;

            return size;
        }

        /// <summary>
        /// Returns the minimum encrypted buffer size.
        /// </summary>
        public static uint GetMinimumEncryptedSize
        {
            get
            {
                return 2 * SslChunckMaxSize;
            }
        }

        /// <summary>
        /// Verifies the GetEncrypedSize and GetCleartextSize methods.
        /// </summary>
        public static void Verify_GetEncrypedSize_GetCleartextSize_methods(uint size, uint chunk_max_size)
        {
            uint cleartext_size = GetCleartextSize(size, chunk_max_size);
            uint encrypted_size = GetEncrypedSize(cleartext_size, chunk_max_size);

            Debug.Assert(encrypted_size <= size);
        }

        /// <summary>
        /// Test the GetEncrypedSize and GetCleartextSize methods with different chunk sizes and sizes
        /// </summary>
        public static void Test_GetEncrypedSize_GetCleartextSize_methods()
        {
            for (uint chunk_max_size = 1024; chunk_max_size <= 1024 * 1024; chunk_max_size *= 2)
                for (uint size = chunk_max_size / 2; size < 32 * 1024 * 1024; size++)
                    Verify_GetEncrypedSize_GetCleartextSize_methods(size, chunk_max_size);
        }

        #endregion Public

        #region Stream Members

        /// <summary>
        /// Same as SslStream.CanRead
        /// </summary>
        public override bool CanRead
        {
            get { return m_ssl_stream.CanRead; }
        }

        /// <summary>
        /// Same as SslStream.CanSeek
        /// </summary>
        public override bool CanSeek
        {
            get { return m_ssl_stream.CanSeek; }
        }

        /// <summary>
        /// Same as SslStream.CanWrite
        /// </summary>
        public override bool CanWrite
        {
            get { return m_ssl_stream.CanWrite; }
        }

        /// <summary>
        /// Same as SslStream.Flush
        /// </summary>
        public override void Flush()
        {
            m_ssl_stream.Flush();
        }

        /// <summary>
        /// Same as SslStream.Close
        /// </summary>
        public override void Close()
        {
            m_ssl_stream.Close();
        }

        /// <summary>
        /// Same as SslStream.Length
        /// </summary>
        public override long Length
        {
            get { return m_ssl_stream.Length; }
        }

        /// <summary>
        /// Same as SslStream.Position
        /// </summary>
        public override long Position
        {
            get
            {
                return m_ssl_stream.Position;
            }
            set
            {
                m_ssl_stream.Position = value;
            }
        }

        /// <summary>
        /// Same as SslStream.Seek
        /// </summary>
        public override long Seek(long offset, SeekOrigin origin)
        {
            return m_ssl_stream.Seek(offset, origin);
        }

        /// <summary>
        /// Same as SslStream.SetLength
        /// </summary>
        public override void SetLength(long value)
        {
            m_ssl_stream.SetLength(value);
        }

        /// <summary>
        /// Same as SslStream.Read
        /// </summary>
        public override int Read(byte[] buffer, int offset, int count)
        {
            Debug.Assert(buffer != null);
            Debug.Assert(offset >= 0);
            Debug.Assert(count > 0);
            Debug.Assert(buffer.Length >= offset + count);
            Debug.Assert(m_current_read_context == null);

            if (m_current_read_context != null)
                throw new NotSupportedException("An asynchronous read operation is already in progress.");

            return m_ssl_stream.Read(buffer, offset, count);
        }

        /// <summary>
        /// Same as SslStream.Write
        /// </summary>
        public override void Write(byte[] buffer, int offset, int count)
        {
            Debug.Assert(buffer != null);
            Debug.Assert(offset >= 0);
            Debug.Assert(count > 0);
            Debug.Assert(buffer.Length >= offset + count);

            m_ssl_stream.Write(buffer, offset, count);
        }

        /// <summary>
        /// Same as SslStream.BeginRead
        /// If the owner was set, the read from the outer_stream uses the maximum size.
        /// </summary>
        public override IAsyncResult BeginRead(byte[] buffer, int offset, int count, AsyncCallback asyncCallback, Object asyncState)
        {
            Debug.Assert(buffer != null);
            Debug.Assert(offset >= 0);
            Debug.Assert(count > 0);
            Debug.Assert(buffer.Length >= offset + count);

            lock (m_read_lock)
            {
                if (sm_enhanced_read)
                {
                    return ReadContext.BeginReadEx(this, buffer, offset, count, asyncCallback, asyncState);
                }
                else
                {
                    return m_ssl_stream.BeginRead(buffer, offset, count, asyncCallback, asyncState);
                }
            }
        }

        /// <summary>
        /// Same as SslStream.EndRead
        /// </summary>
        public override int EndRead(IAsyncResult asyncResult)
        {
            lock (m_read_lock)
            {
                if (sm_enhanced_read)
                {
                    return ReadContext.EndReadEx(this, asyncResult);
                }
                else
                {
                    return m_ssl_stream.EndRead(asyncResult);
                }
            }
        }

        /// <summary>
        /// Same as SslStream.BeginWrite
        /// If the owner was set, then multiple writes are supported.
        /// </summary>
        public override IAsyncResult BeginWrite(byte[] buffer, int offset, int count, AsyncCallback asyncCallback, Object asyncState)
        {
            Debug.Assert(buffer != null);
            Debug.Assert(offset >= 0);
            Debug.Assert(count > 0);
            Debug.Assert(buffer.Length >= offset + count);

            lock (m_write_lock)
            {
                if (m_owner != null && sm_enhanced_write)
                {
                    return m_inner_stream.BeginWriteEx(buffer, offset, count, asyncCallback, asyncState);
                }
                else
                {
                    return m_ssl_stream.BeginWrite(buffer, offset, count, asyncCallback, asyncState);
                }
            }
        }

        /// <summary>
        /// Same as SslStream.EndWrite
        /// </summary>
        public override void EndWrite(IAsyncResult asyncResult)
        {
//            lock (m_write_lock)
            {
                if (m_owner != null && sm_enhanced_write)
                {
                    m_inner_stream.EndWrite(asyncResult);
                }
                else
                {
                    m_ssl_stream.EndWrite(asyncResult);
                }
            }
        }

        /// <summary>
        /// Same as SslStream.ReadTimeout
        /// </summary>
        public override int ReadTimeout
        {
            get { return m_ssl_stream.ReadTimeout; }
            set { m_ssl_stream.ReadTimeout = value; }
        }

        /// <summary>
        /// Same as SslStream.WriteTimeout
        /// </summary>
        public override int WriteTimeout
        {
            get { return m_ssl_stream.WriteTimeout; }
            set { m_ssl_stream.WriteTimeout = value; }
        }

        #endregion Stream Members

        #region Private

        private void init(Stream outer_stream, IOwner owner, bool multiple_read_required)
        {
            lock (sm_id_lock)
            {
                sm_id++;
                m_id = sm_id;
            }

            m_inner_stream = new InnerStream(this, outer_stream);
            if (multiple_read_required == false)
                m_single_read_context = new ReadContext(this);
            else
                m_pending_reads = new Queue<ReadContext>();

            m_owner = null;
            m_hold_owner = owner;
        }

        private void restore_owner()
        {
            m_owner = m_hold_owner;
            m_hold_owner = null;
        }

//         protected virtual void Dispose(bool disposing)
//         {
//             m_hold_owner = null;
//             m_owner = null;
//             m_inner_stream.Dispose();
//             m_ssl_stream.Dispose();
//             m_single_read_context = null;
//             m_pending_reads = null;
//             m_current_read_context = null;
//         }

        private static Object sm_id_lock = new Object();
        private static uint sm_id = 0;
        private /*readonly*/ uint m_id;

        private /*readonly*/ InnerStream m_inner_stream;
        private readonly SslStream   m_ssl_stream;
        private /*readonly*/ ReadContext m_single_read_context;
        private /*readonly*/ Queue<ReadContext> m_pending_reads;

        private ReadContext m_current_read_context;
        private IOwner m_owner,
                       m_hold_owner;

        /// <summary>
        /// FOR DEBUGGING: setting sm_enhanced_read to false, the SslStreamEx will act as the .NET SslStream class on READ actions.
        /// </summary>
        public static bool sm_enhanced_read = true;
        /// <summary>
        /// FOR DEBUGGING: setting sm_enhanced_write to false, the SslStreamEx will act as the .NET SslStream class on WRITE actions.
        /// </summary>
        public static bool sm_enhanced_write = true;

        private Object m_read_lock = new Object(),
                       m_write_lock = new Object();

        private class AuthenticateContext : IAsyncResult
        {
            public static AsyncCallback sm_Callback;

            public AuthenticateContext(AsyncCallback asyncCallback, object asyncState)
            {
                m_asyncCallback = asyncCallback;
                m_asyncState = asyncState;
            }

            static AuthenticateContext()
            {
                sm_Callback = new AsyncCallback(Callback);
            }

            private static void Callback(IAsyncResult ar)
            {
                AuthenticateContext me = (AuthenticateContext)ar.AsyncState;
                me.m_ar = ar;
                me.m_asyncCallback(me);
            }

            public IAsyncResult AsyncResult
            {
                get
                {
                    m_asyncCallback = null;
                    m_asyncState = null;
                    return m_ar;
                }
            }

            #region IAsyncResult Members

            public object AsyncState
            {
                get { return m_asyncState; }
            }

            public System.Threading.WaitHandle AsyncWaitHandle
            {
                get { return null;/*throw new NotImplementedException();*/ }
            }

            public bool CompletedSynchronously
            {
                get { return (m_ar == null) ? false : m_ar.CompletedSynchronously; }
            }

            public bool IsCompleted
            {
                get { return (m_ar == null) ? false : m_ar.IsCompleted; }
            }

            #endregion

            private AsyncCallback m_asyncCallback;
            private Object m_asyncState;
            private IAsyncResult m_ar = null;
        }

        #endregion Private
    }
}
