﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Security;
using System.IO;
using System.Net.Sockets;
using System.Diagnostics;
using System.Security.Cryptography.X509Certificates;
using System.Security.Authentication;

namespace EriCommon
{
    public partial class SslStreamEx : SslStream
    {
        class MemStream : Stream
        {
            private static readonly int PACKET_SIZE     = 16 * 1024;
            private static readonly int HEADER_SIZE     = 5;
            private static readonly int TRAILER_SIZE    = 36;
            private static readonly int HT_SIZE         = HEADER_SIZE + TRAILER_SIZE;

            private readonly Stream m_outer_stream;

            private byte[]  m_buffer    = null;
            private int     m_count     = 0;
            private int     m_max_count = 0;

            public MemStream(Stream outer_stream)
            {
                m_outer_stream = outer_stream;
                SetWriteBufferSize(PACKET_SIZE, false); // enough for SSL handshake. Call SetWriteBufferSize() after that.
            }

            public void SetWriteBufferSize(int count, bool factor = true)
            {
                if (m_max_count < count)
                {
                    m_max_count = count;

                    int size = GetEncryptedSize(count);

                    if (m_buffer == null || size > m_buffer.Length)
                    {
                        int new_size = factor ? ((size * 3) / 2) : size;
                        m_buffer = new byte[new_size];
                    }
                }
            }

            public static int GetEncryptedSize(int count)
            {
                int packets = (count / PACKET_SIZE) + 1;
                return count + (packets * HT_SIZE) + PACKET_SIZE;
            }

            public void FlushToOuterStream()
            {
                int count = m_count;
                m_count = 0;

                //Console.WriteLine(" >>>>> {0} ", count);
                m_outer_stream.Write(m_buffer, 0, count);
            }

            public IAsyncResult BeginFlushToOuterStream(AsyncCallback callback, object state)
            {
                int count = m_count;
                m_count = 0;

                //Console.WriteLine(" >>>>> {0} ", count);
                return m_outer_stream.BeginWrite(m_buffer, 0, count, callback, state);
            }

            #region Stream class Overrides

            public override bool CanRead
            {
                get { return m_outer_stream.CanRead; }
            }

            public override bool CanSeek
            {
                get { return m_outer_stream.CanSeek; }
            }

            public override bool CanTimeout
            {
                get { return m_outer_stream.CanTimeout; }
            }

            public override bool CanWrite
            {
                get { return m_outer_stream.CanWrite; }
            }

            public override long Length
            {
                get { return m_outer_stream.Length; }
            }

            public override long Position
            {
                get
                {
                    return m_outer_stream.Position;
                }
                set
                {
                    m_outer_stream.Position = value;
                }
            }

            public override int ReadTimeout
            {
                get
                {
                    return m_outer_stream.ReadTimeout;
                }
                set
                {
                    m_outer_stream.ReadTimeout = value;
                }
            }

            public override int WriteTimeout
            {
                get
                {
                    return m_outer_stream.WriteTimeout;
                }
                set
                {
                    m_outer_stream.WriteTimeout = value;
                }
            }

            public override IAsyncResult BeginRead(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
            {
                return m_outer_stream.BeginRead(buffer, offset, count, callback, state);
            }

            public override IAsyncResult BeginWrite(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
            {
                return m_outer_stream.BeginWrite(buffer, offset, count, callback, state);
            }

            public override void Close()
            {
                m_outer_stream.Close();
            }

            public override int EndRead(IAsyncResult asyncResult)
            {
                return m_outer_stream.EndRead(asyncResult);
            }

            public override void EndWrite(IAsyncResult asyncResult)
            {
                m_outer_stream.EndWrite(asyncResult);
            }

            public override void Flush()
            {
                m_outer_stream.Flush();
            }

            public override int Read(byte[] buffer, int offset, int count)
            {
                return m_outer_stream.Read(buffer, offset, count);
            }

            public override int ReadByte()
            {
                return m_outer_stream.ReadByte();
            }

            public override long Seek(long offset, SeekOrigin origin)
            {
                return m_outer_stream.Seek(offset, origin);
            }

            public override void SetLength(long value)
            {
                m_outer_stream.SetLength(value);
            }

            public override void Write(byte[] buffer, int offset, int count)
            {
                //Console.Write("{0} ", count);

                if (m_buffer.Length < m_count + count)
                {
                    Debug.Assert(false);    // should not happen
                    Array.Resize(ref m_buffer, m_count + count);
                }

                Unsafe.MemCpy(buffer,
                              (uint)offset,
                              m_buffer,
                              (uint)m_count,
                              (uint)count);

                m_count += count;
            }

            public override void WriteByte(byte value)
            {
                m_outer_stream.WriteByte(value);
            }

            #endregion Stream class Overrides
        }
    }
}
