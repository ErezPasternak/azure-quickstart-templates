﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using TracerX;
using System.Configuration;
using System.Xml;

namespace EriCommon
{
    /// <summary>
    /// The AppConfig class manages the application configuration file.
    /// </summary>
    public class AppCfg
    {
        /// <summary>
        /// Sets/gets the InhibitLoad property
        /// </summary>
        public static bool InhibitLoad
        {
            get { return sm_inhibit_load; }
            set { if (sm_first_time) sm_inhibit_load = value; }
        }

        private static object sm_Load_lock = new object();

        /// <summary>
        /// Gets the Load Locker object
        /// </summary>
        public static object LoadLocker
        {
            get { return sm_Load_lock; }
        }

        /// <summary>
        /// Loads the settings
        /// </summary>
        public static void Load()
        {
            lock (sm_Load_lock)
            {
                Settings.Load();
            }
        }

        /// <summary>
        /// The Settings class
        /// </summary>
        public class Settings
        {
            /// <summary>
            /// The constructor
            /// </summary>
            public Settings(String name)
            {
                m_name = name;
                refresh_settings_event += refresh;
            }

            /// <summary>
            /// The destructor
            /// </summary>
            ~Settings()
            {
                refresh_settings_event -= refresh;
            }

            /// <summary>
            /// The Name property
            /// </summary>
            public String Name
            {
                get { return m_name; }
            }

            /// <summary>
            /// Loads the settings
            /// </summary>
            public static void Load()
            {
                if (refresh_settings_event != null)
                {
                    lock (refresh_settings_event)
                    {
                        sm_first_time = sm_load_count == 0;

                        if (sm_first_time && InhibitLoad)
                            return;

                        sm_load_count++;
                        sm_log_text = "";
                        sm_write_to_log = sm_first_time || sm_logger.IsLevelInUse(TracerX.TraceLevel.Info);

                        sm_logger.DebugFormat("{0} the configuration...", sm_first_time ? "Loading" : "Reloading");

                        refresh_settings_event();

                        if (sm_log_text != "")
                        {
                            sm_logger.InfoFormat("Configuration {0}\n{1}",
                                                  sm_first_time ? "loaded" : "reloaded",
                                                  sm_log_text);
                        }
                        else
                        {
                            sm_logger.DebugFormat("Configuration {0}.", sm_first_time ? "loaded" : "reloaded");
                        }
                    }
                }
            }

            /// <summary>
            /// Subscribes a refresh handler
            /// </summary>
            public void Subscribe(RefreshItemHandler handler)
            {
                lock (this)
                {
                    refresh_items_event += handler;
                }
            }

            /// <summary>
            /// Unsubscribes a refresh handler
            /// </summary>
            public void Unsubscribe(RefreshItemHandler handler)
            {
                lock (this)
                {
                    refresh_items_event -= handler;
                }
            }

            /// <summary>
            /// The values property
            /// </summary>
            public NameValueCollection values
            {
                get 
                {
                    ConfigurationManager.RefreshSection(m_name);
                    return (NameValueCollection)ConfigurationManager.GetSection(m_name); 
                }
            }

            public void Write(XmlNode parent)
            {
                XmlNode node = parent.CreateNode(m_name);

                NameValueCollection vals = values;

                foreach( String key in vals.Keys)
                {
                    XmlNode subnode = node.CreateNode(key, vals[key]);
                }
            }

            void refresh()
            {
                if (refresh_items_event != null)
                {
                    String hold_log_text = sm_log_text;
                    sm_log_text = "";

                    ConfigurationManager.RefreshSection(m_name);
                    NameValueCollection settings = (NameValueCollection)ConfigurationManager.GetSection(m_name);
                    sm_logger.DebugFormat("{0} '{1}...'", sm_first_time ? "Loading" : "Reloading", m_name);
                    refresh_items_event(settings);
                    sm_logger.DebugFormat("'{0}' {1}", m_name, sm_first_time ? "loaded" : "reloaded");

                    if (sm_log_text != "")
                    {
                        hold_log_text += String.Format("    {0}:\n{1}", m_name, sm_log_text);
                        sm_log_text = hold_log_text;
                    }
                }
            }

            /// <summary>
            /// The RefreshItemHandler definition
            /// </summary>
            public delegate void RefreshItemHandler(NameValueCollection settings);
            private event RefreshItemHandler refresh_items_event;

            private readonly String     m_name;

            private delegate void RefreshSessingsHandler();
            private static event RefreshSessingsHandler refresh_settings_event;

        }

        /// <summary>
        /// The LogSettings
        /// </summary>
        public static Settings LogSettings
        {
            get { return sm_logSettings; }
        }

        /// <summary>
        /// The Item class
        /// </summary>
        public abstract class Item
        {
            /// <summary>
            /// The c-tor
            /// </summary>
            public Item(Settings settings, String name)
            {
                m_settings = settings;
                m_name     = name;
            }

            /// <summary>
            /// The d-tor
            /// </summary>
            ~Item()
            {
            }

            /// <summary>
            /// The Name property
            /// </summary>
            public String Name
            {
                get { return m_name; }
            }

            /// <summary>
            /// The Settings property
            /// </summary>
            public Settings Settings
            {
                get { return m_settings; }
            }

            /// <summary>
            /// Sets the value
            /// </summary>
            public abstract void Set(String val);

            protected Settings m_settings;
            protected readonly String m_name;
        }

        /// <summary>
        /// The ItemT generic class
        /// </summary>
        public abstract class ItemT<T> : Item
        {
            /// <summary>
            /// The c-tor
            /// </summary>
            public ItemT(Settings settings, String name, T def_val, bool reloadable)
                : base(settings, name)
            {
                m_param    = new Param<T>(def_val, reloadable);
                m_settings.Subscribe(refresh);
            }

            /// <summary>
            /// The d-tor
            /// </summary>
            ~ItemT()
            {
                if (m_settings != null)
                    m_settings.Unsubscribe(refresh);
            }

            /// <summary>
            /// Converts to string
            /// </summary>
            public override String ToString()
            {
                if (m_param.NotLoaded)
                    load();

                return m_param.ToString();
            }

            /// <summary>
            /// The Text property
            /// </summary>
            public String Text
            {
                get { return ToString(); }
            }

            /// <summary>
            /// The Loaded property
            /// </summary>
            public bool Loaded
            {
                get
                {
                    return m_param.Loaded;
                }
            }

            /// <summary>
            /// The Value property
            /// </summary>
            public T Value
            {
                get
                {
                    if( m_param.NotLoaded )
                        load();

                    return m_param.Val;
                }
            }

            /// <summary>
            /// The Default property
            /// </summary>
            public T Default
            {
                get { return m_param.Default; }
            }

            /// <summary>
            /// Returns the param
            /// </summary>
            public Param<T> GetParam()
            {
                return m_param;
            }

            public override void Set(String val)
            {
                try
                {
                    T new_val = parse(val);

                    ModifyState state = Modify(m_settings.Name, Name, val);

                    if (state == ModifyState.Modified)
                        m_param.Val = new_val;
                }
                catch (Exception ex)
                {
                    sm_logger.ErrorFormat("Failed to set [{0}]{1}: {2}", m_settings.Name, m_name, ex.AllMessages());
                }
            }

            /// <summary>
            /// Defines the update handler
            /// </summary>
            public delegate void UpdateHandler(T val, Item item);

            /// <summary>
            /// Subscribes a handler
            /// </summary>
            public void Subscribe(UpdateHandler handler)
            {
                lock (this)
                {
                    update += handler;

                    if (m_param.NotLoaded)
                        load();

                    handler(m_param.Val, this);
                }
            }

            /// <summary>
            /// ChangesCounter
            /// </summary>
            public uint ChangesCounter
            {
                get { return m_changes_counter; }
            }

            /// <summary>
            /// Reloaded
            /// </summary>
            public bool Reloaded
            {
                get { return m_changes_counter > 1; }
            }

            /// <summary>
            /// Unsubscribes a handler
            /// </summary>
            public void Unsubscribe(UpdateHandler handler)
            {
                lock (this)
                {
                    update -= handler;
                }
            }

            /// <summary>
            /// Loads
            /// </summary>
            protected void load()
            {
                refresh(m_settings.values);
            }

            /// <summary>
            /// Converts a string to a T type
            /// </summary>
            protected abstract T parse(String text);

            /// <summary>
            /// Converts a T type to a string
            /// </summary>
            protected abstract String toString(T val);

            /// <summary>
            /// Refreshes
            /// </summary>
            protected void refresh(NameValueCollection values)
            {
                try
                {
                    sm_logger.DebugFormat("Parsing '{0}'...", m_name);
                    m_param.Val = parse(values[m_name]);
                    sm_logger.DebugFormat("'{0}' = {1}", m_name, m_param.ToString());
                }
                catch(Exception ex)
                {
                    String default_text = toString(m_param.Default);
                    sm_logger.ErrorFormat("Failed to load [{0}]{1}: {2}\nSet to the default value '{3}'", m_settings.Name, m_name, ex.AllMessages(), default_text);
                    m_param.Val = m_param.Default;
                }

                if (sm_write_to_log && (sm_first_time || m_param.Changed))
                    sm_log_text += String.Format("        {0,-40} = {1}\n", Name, Text);

                if(m_param.Reloadable == false)
                {
                    lock(this)
                    {
                        if(m_settings != null)
                        {
                            m_settings.Unsubscribe(refresh);
                            m_settings = null;
                        }
                    }
                }

                if (m_param.Changed == false)
                {
                    if (m_changes_counter == 0)
                        m_changes_counter++;

                    return;
                }

                m_changes_counter++;

                sm_logger.InfoFormat("The value of [{0}]{1} was modified", m_settings.Name, m_name);

                lock (this)
                {
                    if(update != null)
                        update(m_param.Val, this);
                }
            }

            /// <summary>
            /// Holds the param
            /// </summary>
            protected readonly Param<T> m_param;
            private uint                m_changes_counter = 0;

            private event UpdateHandler update;

        } // end of class ItemT

        /// <summary>
        ///The StringItem class
        /// </summary>
        public class StringItem : ItemT<String>
        {
            /// <summary>
            ///The c-tor
            /// </summary>
            public StringItem(Settings settings, String name, String def_val, bool reloadable = true) : base(settings, name, def_val, reloadable) { }

            /// <summary>
            /// The Parser method
            /// </summary>
            protected override String parse(String text) { return text; }

            /// <summary>
            /// Converts to string
            /// </summary>
            protected override String toString(String val) { return val; }
        }

        /// <summary>
        ///The BoolItem class
        /// </summary>
        public class BoolItem : ItemT<bool>
        {
            /// <summary>
            ///The c-tor
            /// </summary>
            public BoolItem(Settings settings, String name, bool def_val, bool reloadable = true) : base(settings, name, def_val, reloadable) { }

            /// <summary>
            /// The Parser method
            /// </summary>
            protected override bool parse(String text) { return bool.Parse(text); }

            /// <summary>
            /// Converts to string
            /// </summary>
            protected override String toString(bool val) { return val.ToString(); }
        }

        /// <summary>
        ///The Int16Item class
        /// </summary>
        public class Int16Item : ItemT<Int16>
        {
            /// <summary>
            ///The c-tor
            /// </summary>
            public Int16Item(Settings settings, String name, Int16 def_val, bool reloadable = true) : base(settings, name, def_val, reloadable) { }

            /// <summary>
            /// The Parser method
            /// </summary>
            protected override Int16 parse(String text) { return Int16.Parse(text); }

            /// <summary>
            /// Converts to string
            /// </summary>
            protected override String toString(Int16 val) { return val.ToString(); }
        }

        /// <summary>
        ///The UInt16Item class
        /// </summary>
        public class UInt16Item : ItemT<UInt16>
        {
            /// <summary>
            ///The c-tor
            /// </summary>
            public UInt16Item(Settings settings, String name, UInt16 def_val, bool reloadable = true) : base(settings, name, def_val, reloadable) { }

            /// <summary>
            /// The Parser method
            /// </summary>
            protected override UInt16 parse(String text) { return UInt16.Parse(text); }

            /// <summary>
            /// Converts to string
            /// </summary>
            protected override String toString(UInt16 val) { return val.ToString(); }
        }

        /// <summary>
        ///The Int32Item class
        /// </summary>
        public class Int32Item : ItemT<Int32>
        {
            /// <summary>
            ///The c-tor
            /// </summary>
            public Int32Item(Settings settings, String name, Int32 def_val, bool reloadable = true) : base(settings, name, def_val, reloadable) { }

            /// <summary>
            /// The Parser method
            /// </summary>
            protected override Int32 parse(String text) { return Int32.Parse(text); }

            /// <summary>
            /// Converts to string
            /// </summary>
            protected override String toString(Int32 val) { return val.ToString(); }
        }

        /// <summary>
        ///The UInt32Item class
        /// </summary>
        public class UInt32Item : ItemT<UInt32>
        {
            /// <summary>
            ///The c-tor
            /// </summary>
            public UInt32Item(Settings settings, String name, UInt32 def_val, bool reloadable = true) : base(settings, name, def_val, reloadable) { }

            /// <summary>
            /// The Parser method
            /// </summary>
            protected override UInt32 parse(String text) { return UInt32.Parse(text); }

            /// <summary>
            /// Converts to string
            /// </summary>
            protected override String toString(UInt32 val) { return val.ToString(); }
        }

        /// <summary>
        ///The LogLevelItem class
        /// </summary>
        public class LogLevelItem : ItemT<TracerX.TraceLevel>
        {
            /// <summary>
            ///The c-tor
            /// </summary>
            public LogLevelItem(Settings settings, String name, TracerX.TraceLevel def_val = TracerX.TraceLevel.Info, bool reloadable = true) : base(settings, name, def_val, reloadable) { }

            /// <summary>
            /// The Parser method
            /// </summary>
            protected override TracerX.TraceLevel parse(String text) { return Logger.GetLevel(Logger.GetCorrectLevelName(text)); }

            /// <summary>
            /// Converts to string
            /// </summary>
            protected override String toString(TracerX.TraceLevel val) { return Logger.GetLevelName(val); }

            /// <summary>
            /// Converts to string
            /// </summary>
            public override String ToString()
            {
                return toString(m_param.Val);
            }
        }

        /// <summary>
        ///The Param generic class
        /// </summary>
        public class Param<T>
        {
            /// <summary>
            ///The c-tor
            /// </summary>
            public Param(T def_val, bool reloadable) { m_def_val = m_val = def_val; Reloadable = reloadable; Changed = false; }

            /// <summary>
            /// Extracts the Val from Param
            /// </summary>
            public static implicit operator T(Param<T> a) { return a.Val; }

            /// <summary>
            /// The Reloadable property
            /// </summary>
            public bool Reloadable { get; private set; }

            /// <summary>
            /// The Changed property
            /// </summary>
            public bool Changed { get; private set; }

            /// <summary>
            /// The Loaded property
            /// </summary>
            public bool Loaded { get { return m_first_time == false; } }

            /// <summary>
            /// The NotLoaded property
            /// </summary>
            public bool NotLoaded { get { return m_first_time; } }

            /// <summary>
            /// The Default property
            /// </summary>
            public T Default { get { return m_def_val; } }

            private readonly T m_def_val;
            private T m_val;
            private bool m_first_time = true;

            /// <summary>
            /// The Val property
            /// </summary>
            public T Val
            {
                get { return m_val; }
                set
                {
                    Changed = false;

                    if (m_first_time == false && Reloadable == false)
                        return;

                    if (value.ToString() != m_val.ToString())
                    {
                        m_val = value;

                        if (m_first_time == false)
                            Changed = true;
                    }

                    m_first_time = false;
                }
            }

            /// <summary>
            /// Forces setting the value
            /// </summary>
            public void ForceSet(T value)
            {
                m_val = value;
            }

            /// <summary>
            /// Sets the value to default
            /// </summary>
            public void SetToDefault()
            {
                m_val = m_def_val;
            }

            /// <summary>
            /// Returns the string
            /// </summary>
            public override String ToString()
            {
                return Val.ToString();
            }
        }	// End of inner class Param

        /// <summary>
        /// The Logger
        /// </summary>
        protected static Logger                 sm_logger;
        private   static bool                   sm_inhibit_load = false;
        private static uint                     sm_load_count = 0;
        private static bool                     sm_first_time = true;
        private static bool                     sm_write_to_log;
        private static String                   sm_log_text;

        /// <summary>
        /// The logSettings section
        /// </summary>
        protected static Settings               sm_logSettings = new Settings("logSettings");
        private static readonly LogLevelItem    sm_ConfigurationLogLevel = new LogLevelItem(sm_logSettings, "Configuration");

        /// <summary>
        /// The appSettings section
        /// </summary>
        protected static Settings               sm_appSettings = new Settings("appSettings");
        private static readonly UInt32Item      m_WaitForConfigFileReadyToReloadSeconds = new UInt32Item(sm_appSettings, "WaitForConfigFileReadyToReloadSeconds", 3);

        /// <summary>
        /// The "Touch Me" method
        /// </summary>
        public static void Initialize() { }

        public enum ModifyState { NotFound = -1, NotModified = 0, Modified = 1 };

        public static ModifyState Modify(string SettingsName, string KeyName, object KeyValue)
        {
            lock (sm_Load_lock)
            {
                XmlDocument doc = new XmlDocument();
                string fn = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;

                doc.Load(fn);
                ModifyState retval = ModifyState.NotFound;

                foreach (XmlElement elem in doc.DocumentElement)
                {
                    if (elem.Name == SettingsName)
                    {
                        foreach (XmlNode node in elem.ChildNodes)
                        {
                            XmlAttributeCollection attributes = node.Attributes;

                            if (attributes == null)
                                continue;

                            if (node.Attributes[0].Value == KeyName)
                            {
                                string oldVal = node.Attributes[1].Value,
                                       newVal = KeyValue.ToString();

                                if (oldVal == newVal)
                                {
                                    retval = ModifyState.NotModified;
                                }
                                else
                                {
                                    node.Attributes[1].Value = newVal;
                                    retval = ModifyState.Modified;
                                }

                                break;
                            }
                        }

                        break;
                    }
                }

                if (retval == ModifyState.Modified)
                {
                    doc.Save(fn);
                    sm_logger.InfoFormat("The value of [{0}]{1} was successfully changed", SettingsName, KeyName);
                }

                return retval;
            }
        }

        protected virtual void onChanged(FileSystemEventArgs e)
        {
            AppCfg.Load();
        }

        private FileWatcher sm_wacher;

        /// <summary>
        /// The protected AppCfg constructor
        /// </summary>
        protected AppCfg()
        {
            sm_wacher = new FileWatcher(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile,
                                        onChanged,
                                        m_WaitForConfigFileReadyToReloadSeconds.Value,
                                        sm_logger);
        }

        /// <summary>
        /// The static AppCfg constructor (called implicitly when the Initialize (the "Touch Me") method is called
        /// </summary>
        static AppCfg()
        {
            sm_logger = Logger.GetLogger("Configuration");
            sm_logger.BinaryFileTraceLevel = TracerX.TraceLevel.Info;
            uint BinaryFileLoggingMaxSizeMb = 32;
            UInt32Item LogSizeMB = new UInt32Item(sm_logSettings, "LogSizeMB", BinaryFileLoggingMaxSizeMb, false);

            try
            {
                BinaryFileLoggingMaxSizeMb = LogSizeMB.Value;
            }
            catch (System.Exception /*ex*/)
            {
            }

            LogHelper.BinaryFileLoggingMaxSizeMb = BinaryFileLoggingMaxSizeMb;

            try
            {
                sm_logger.BinaryFileTraceLevel = sm_ConfigurationLogLevel.Value;
            }
            catch (System.Exception /*ex*/)
            {
            }
        }

        public static Logger Logger
        {
            get { return sm_logger;  }
        }
    }
}
