﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Threading;
using System.Diagnostics;
using System.IO;
using TracerX;

namespace EriCommon
{
    /// <summary>
    /// The SystemInformation class deals with collection and reporting system information about the current process.
    /// </summary>
    public class SystemInformation
    {
        #region Public

        /// <summary>
        /// Returns the number of processors, to be used instead of Environment.ProcessorCount.
        /// </summary>
        public static UInt32 ProcessorCount
        {
            get
            {
                return sm_number_of_logical_processors;
            }
        }

        internal class Data
        {
            public static CSV sm_csv;
            public DateTime m_time;
            public TimeSpan m_process_elapsed_time;

            public TimeSpan m_PrivilegedProcessorTime;
            public TimeSpan m_UserProcessorTime;

//          public long m_ContextSwitches;

            public long m_PrivateMemorySize64;

//          public long m_NonpagedSystemMemorySize64;
//          public long m_PagedSystemMemorySize64;

//            public long m_PeakPagedMemorySize64;
            public long m_PagedMemorySize64;

//            public long m_PeakVirtualMemorySize64;
            public long m_VirtualMemorySize64;

//            public long m_PeakWorkingSet64;
            public long m_WorkingSet64;

            public int m_HandleCount;
            public int m_ThreadCount;

            public int m_UserObjects;
            public int m_GdiObjects;

            private PROCESS_MEMORY_COUNTERS64 m_PROCESS_MEMORY_COUNTERS64 = new PROCESS_MEMORY_COUNTERS64();
            private PROCESS_MEMORY_COUNTERS32 m_PROCESS_MEMORY_COUNTERS32 = new PROCESS_MEMORY_COUNTERS32();
            private IO_COUNTERS m_IO_COUNTERS = new IO_COUNTERS();
            private double m_machine_cpu_percent;

            internal static void OpenCSV(string fullpath_filename)
            {
                sm_csv = new CSV(
                    fullpath_filename,
                    // ------------------- COLUMNS ----------------------
                    new CSV.DateTimeColumn("Date & Time"),
                    new CSV.TimeSpanColumn("Elapsed from Start"),
                    //-------------------------------------------------
                    new CSV.DummyColumn("CPU USAGE >>>"),
                    new CSV.TimeSpanColumn("Delta Kernel CPU"),
                    new CSV.PercentColumn("Delta Kernel CPU"),
                    new CSV.TimeSpanColumn("Delta User CPU"),
                    new CSV.PercentColumn("Delta User CPU"),
                    new CSV.TimeSpanColumn("Delta CPU"),
                    new CSV.PercentColumn("Delta CPU"),
                    new CSV.TimeSpanColumn("Kernel CPU"),
                    new CSV.PercentColumn("Kernel CPU"),
                    new CSV.TimeSpanColumn("User CPU"),
                    new CSV.PercentColumn("User CPU"),
                    new CSV.TimeSpanColumn("CPU"),
                    new CSV.PercentColumn("CPU"),
                    new CSV.PercentColumn("Machine CPU"),
                    //-------------------------------------------------
                    new CSV.DummyColumn("MEMORY >>>"),
                    new CSV.SignedColumn("Delta Page Faults"),
                    new CSV.UnsignedColumn("Page Faults"),
                    new CSV.KilobyteColumn("Delta Commit Size"),
                    new CSV.KilobyteColumn("Commit Size"),
                    new CSV.KilobyteColumn("Delta Working Set"),
                    new CSV.KilobyteColumn("Working Set"),
                    //-------------------------------------------------
                    new CSV.DummyColumn("SYSTEM RESOURCES >>>"),
                    new CSV.UnsignedColumn("Handles"),
                    new CSV.UnsignedColumn("Threads"),
                    new CSV.UnsignedColumn("User Objects"),
                    new CSV.UnsignedColumn("GDI Objects"),
                    //-------------------------------------------------
                    new CSV.DummyColumn("I/O >>>"),
                    new CSV.UnsignedColumn("I/O Reads"),
                    new CSV.UnsignedColumn("I/O Read Bytes"),
                    new CSV.UnsignedColumn("I/O Writes"),
                    new CSV.UnsignedColumn("I/O Write Bytes"),
                    new CSV.UnsignedColumn("I/O Other"),
                    new CSV.UnsignedColumn("I/O Other Bytes")
                    );
            }

            internal void WriteCSV(Data prev)
            {
                if (prev == null)
                    prev = this;

                double period_milliseconds = m_time.Subtract(prev.m_time).TotalMilliseconds,
                       period_multiplyed_by_number_of_processors = period_milliseconds * (double)sm_number_of_logical_processors;

                sm_csv.AddLine(
                    null,                                                                                                   //Date & Time
                    m_process_elapsed_time,                                                                                 //Elapsed from Start
                    //-------------------------------------------------
                    null,                                                                                                   //CPU USAGE >>>
                    m_PrivilegedProcessorTime - prev.m_PrivilegedProcessorTime,                                             //Delta Kernel CPU
                    new CSV.Numbers((m_PrivilegedProcessorTime - prev.m_PrivilegedProcessorTime).TotalMilliseconds,
                                    period_multiplyed_by_number_of_processors),                                             //Delta Kernel CPU%
                    m_UserProcessorTime - prev.m_UserProcessorTime,                                                         //Delta User CPU
                    new CSV.Numbers((m_UserProcessorTime - prev.m_UserProcessorTime).TotalMilliseconds,
                                    period_multiplyed_by_number_of_processors),                                             //Delta User CPU%
                    ((m_PrivilegedProcessorTime + m_UserProcessorTime) -
                     (prev.m_PrivilegedProcessorTime + prev.m_UserProcessorTime)),                                          //Delta CPU
                    new CSV.Numbers(((m_PrivilegedProcessorTime + m_UserProcessorTime) -
                                     (prev.m_PrivilegedProcessorTime + prev.m_UserProcessorTime)).TotalMilliseconds,
                                    period_multiplyed_by_number_of_processors),                                             //Delta CPU%
                    m_PrivilegedProcessorTime,                                                                              //Kernel CPU
                    new CSV.Numbers(m_PrivilegedProcessorTime.TotalMilliseconds,
                                    m_process_elapsed_time.TotalMilliseconds),                                              //Kernel CPU%
                    m_UserProcessorTime,                                                                                    //User CPU
                    new CSV.Numbers(m_UserProcessorTime.TotalMilliseconds,
                                    m_process_elapsed_time.TotalMilliseconds),                                              //User CPU%
                    m_PrivilegedProcessorTime + m_UserProcessorTime,                                                        //CPU
                    new CSV.Numbers((m_PrivilegedProcessorTime.TotalMilliseconds + m_UserProcessorTime.TotalMilliseconds),
                                    m_process_elapsed_time.TotalMilliseconds),                                              //CPU%
                    new CSV.Numbers(m_machine_cpu_percent, 100.0),                                                          //Machine CPU%
                    //-------------------------------------------------
                    null,                                                                                                   //MEMORY >>>
                    m_PROCESS_MEMORY_COUNTERS64.PageFaultCount - prev.m_PROCESS_MEMORY_COUNTERS64.PageFaultCount,           //Delta Page Faults
                    m_PROCESS_MEMORY_COUNTERS64.PageFaultCount,                                                             //Page Faults
                    m_PrivateMemorySize64 - prev.m_PrivateMemorySize64,                                                     //Delta Commit Size
                    m_PrivateMemorySize64,                                                                                  //Commit Size
                    m_WorkingSet64 - prev.m_WorkingSet64,                                                                   //Delta Working Set
                    m_WorkingSet64,                                                                                         //Working Set
                    //-------------------------------------------------
                    null,                                                                                                   //SYSTEM RESOURCES >>>
                    m_HandleCount,                                                                                          //Handles
                    m_ThreadCount,                                                                                          //Threads
                    m_UserObjects,                                                                                          //USER Objects
                    m_GdiObjects,                                                                                           //GDI Objects,,
                    //-------------------------------------------------
                    null,                                                                                                   //I/O >>>
                    m_IO_COUNTERS.ReadOperationCount,                                                                       //I/O Reads
                    m_IO_COUNTERS.ReadTransferCount,                                                                        //I/O Read Bytes
                    m_IO_COUNTERS.WriteOperationCount,                                                                      //I/O Writes
                    m_IO_COUNTERS.WriteTransferCount,                                                                       //I/O Write Bytes
                    m_IO_COUNTERS.OtherOperationCount,                                                                      //I/O Other
                    m_IO_COUNTERS.OtherTransferCount                                                                        //I/O Other Bytes,
                    );
            }

            [DllImport("Kernel32")]
            static extern uint GetLastError();

            [DllImport("User32")]
            static extern int GetGuiResources(IntPtr hProcess, int uiFlags);

            [DllImport("psapi.dll", SetLastError = true, EntryPoint = "GetProcessMemoryInfo")]
            static extern bool GetProcessMemoryInfo32(IntPtr hProcess, ref PROCESS_MEMORY_COUNTERS32 counters, uint size);

            [DllImport("psapi.dll", SetLastError = true, EntryPoint = "GetProcessMemoryInfo")]
            static extern bool GetProcessMemoryInfo64(IntPtr hProcess, ref PROCESS_MEMORY_COUNTERS64 counters, uint size);

            [DllImport("kernel32.dll")]
            static extern bool GetProcessIoCounters(IntPtr ProcessHandle, ref IO_COUNTERS IoCounters);

            [StructLayout(LayoutKind.Sequential, Size = 40)]
            private struct PROCESS_MEMORY_COUNTERS32
            {
                public uint cb;
                public uint PageFaultCount;
                public uint PeakWorkingSetSize;
                public uint WorkingSetSize;
                public uint QuotaPeakPagedPoolUsage;
                public uint QuotaPagedPoolUsage;
                public uint QuotaPeakNonPagedPoolUsage;
                public uint QuotaNonPagedPoolUsage;
                public uint PagefileUsage;
                public uint PeakPagefileUsage;
            }

            [StructLayout(LayoutKind.Sequential, Size = 72)]
            private struct PROCESS_MEMORY_COUNTERS64
            {
                public uint cb;
                public uint PageFaultCount;
                public ulong PeakWorkingSetSize;
                public ulong WorkingSetSize;
                public ulong QuotaPeakPagedPoolUsage;
                public ulong QuotaPagedPoolUsage;
                public ulong QuotaPeakNonPagedPoolUsage;
                public ulong QuotaNonPagedPoolUsage;
                public ulong PagefileUsage;
                public ulong PeakPagefileUsage;
            }

            private struct IO_COUNTERS
            {
                public ulong ReadOperationCount;
                public ulong WriteOperationCount;
                public ulong OtherOperationCount;
                public ulong ReadTransferCount;
                public ulong WriteTransferCount;
                public ulong OtherTransferCount;
            }

            public void Update()
            {
                sm_process = Process.GetCurrentProcess();
                sm_process_handle = sm_process.Handle;

                //http://en.wikibooks.org/wiki/C_Sharp_Programming/The_.NET_Framework/Marshalling

                m_time = DateTime.Now;
                m_process_elapsed_time = new TimeSpan(m_time.Ticks - sm_process.StartTime.Ticks);

                m_PrivilegedProcessorTime = sm_process.PrivilegedProcessorTime;
                m_UserProcessorTime = sm_process.UserProcessorTime;

                //                 m_ContextSwitches = .sm_process.C;
                //                 m_PageFaults = ?;

                m_PrivateMemorySize64 = sm_process.PrivateMemorySize64;
                //                m_NonpagedSystemMemorySize64 = sm_process.NonpagedSystemMemorySize64;
                //                m_PagedSystemMemorySize64 = sm_process.PagedSystemMemorySize64;

                //               m_PeakPagedMemorySize64 = sm_process.PeakPagedMemorySize64;
                m_PagedMemorySize64 = sm_process.PagedMemorySize64;

                //                m_PeakVirtualMemorySize64 = sm_process.PeakVirtualMemorySize64;
                m_VirtualMemorySize64 = sm_process.VirtualMemorySize64;

                //                m_PeakWorkingSet64 = sm_process.PeakWorkingSet64;
                m_WorkingSet64 = sm_process.WorkingSet64;

                m_HandleCount = sm_process.HandleCount;
                m_ThreadCount = sm_process.Threads.Count;

                m_UserObjects = GetGuiResources(sm_process_handle, 1);
                m_GdiObjects = GetGuiResources(sm_process_handle, 0);

                fill_PROCESS_MEMORY_COUNTERS();

                GetProcessIoCounters(sm_process_handle, ref m_IO_COUNTERS);

                if (sm_logger_enabled)
                {
//                    using (sm_logger.InfoBlock("Getting machine CPU.", "Machine CPU got."))
                    {
                        m_machine_cpu_percent = GetCurrentCpuUsage();
                    }
                }
                else
                {
                    m_machine_cpu_percent = GetCurrentCpuUsage();
                }
            }

            private void fill_PROCESS_MEMORY_COUNTERS()
            {
                if (Environment.Is64BitProcess)
                {
                    m_PROCESS_MEMORY_COUNTERS64.cb = 72;
                    GetProcessMemoryInfo64(sm_process_handle, ref m_PROCESS_MEMORY_COUNTERS64, m_PROCESS_MEMORY_COUNTERS64.cb);
                }
                else
                {
                    m_PROCESS_MEMORY_COUNTERS32.cb = 40;
                    GetProcessMemoryInfo32(sm_process_handle, ref m_PROCESS_MEMORY_COUNTERS32, m_PROCESS_MEMORY_COUNTERS32.cb);
                    m_PROCESS_MEMORY_COUNTERS64.PageFaultCount              = m_PROCESS_MEMORY_COUNTERS32.PageFaultCount;
                    m_PROCESS_MEMORY_COUNTERS64.PeakWorkingSetSize          = m_PROCESS_MEMORY_COUNTERS32.PeakWorkingSetSize;
                    m_PROCESS_MEMORY_COUNTERS64.WorkingSetSize              = m_PROCESS_MEMORY_COUNTERS32.WorkingSetSize;
                    m_PROCESS_MEMORY_COUNTERS64.QuotaPeakPagedPoolUsage     = m_PROCESS_MEMORY_COUNTERS32.QuotaPeakPagedPoolUsage;
                    m_PROCESS_MEMORY_COUNTERS64.QuotaPagedPoolUsage         = m_PROCESS_MEMORY_COUNTERS32.QuotaPagedPoolUsage;
                    m_PROCESS_MEMORY_COUNTERS64.QuotaPeakNonPagedPoolUsage  = m_PROCESS_MEMORY_COUNTERS32.QuotaPeakNonPagedPoolUsage;
                    m_PROCESS_MEMORY_COUNTERS64.QuotaNonPagedPoolUsage      = m_PROCESS_MEMORY_COUNTERS32.QuotaNonPagedPoolUsage;
                    m_PROCESS_MEMORY_COUNTERS64.PagefileUsage               = m_PROCESS_MEMORY_COUNTERS32.PagefileUsage;
                    m_PROCESS_MEMORY_COUNTERS64.PeakPagefileUsage           = m_PROCESS_MEMORY_COUNTERS32.PeakPagefileUsage;
                }
            }
        }

        /// <summary>
        /// Returns the total CPU usage.
        /// </summary>
        public static double GetCurrentCpuUsage()
        {
            return m_cpuCounter.NextValue();
        }

        /// <summary>
        /// Sets the interval.
        /// Call this method  BEFORE start reporting!
        /// </summary>
        public static void SetInterval(UInt32 seconds_interval)
        {
            // Use this method BEFORE start reporting!
            Debug.Assert(sm_seconds_interval == 0);
            sm_user_set_seconds_interval = seconds_interval;
        }

        /// <summary>
        /// Turn reporting on-off
        /// </summary>
        /// <param name="onoff"></param>
        public static void SetReportingState(bool onoff)
        {
            sm_reporting_enabled = onoff;
        }

            /// <summary>
        /// Starts reporting the system information to a CSV file.
        /// </summary>
        public static void StartReporting(UInt32 seconds_interval = 0, bool reporting_enabled = true)
        {
            lock (lock_write_report)
            {
                if (Data.sm_csv == null)
                {
                    string fullpath_filename = FileHelper.RenameFile(" System Information", "CSV");
                    Data.OpenCSV(fullpath_filename);
                }
            }

            sm_reporting_enabled = reporting_enabled;

            if (sm_seconds_interval > 0)
                return;

            sm_seconds_interval = (seconds_interval != 0) ? seconds_interval : sm_user_set_seconds_interval;

            if (sm_seconds_interval == 0)
            {
#if DEBUG
                sm_seconds_interval = 10;       // every 10 seconds
#else
                sm_seconds_interval = 1 * 60;  // every minute
#endif
            }

            sm_ReportThread = ThreadHelper.Create("System Information", report, true, ThreadHelper.Mode.Background);
        }

        /// <summary>
        /// Stops the reporting thread
        /// </summary>
        public static void StopReporting()
        {
            if (sm_ReportThread != null && sm_ReportThread.IsAlive)
            {
                sm_stop_report_event.Set();

                if (sm_ReportThread.Join(5000) == false)
                {
                    sm_ReportThread.Abort();
                }
            }
        }

        #endregion

        #region Private

        private static void report()
        {
            Exception e;

            DateTime next = DateTime.Now;
            DateTime now;

            for (;;)
            {
                if (sm_logger_enabled)
                {
                    try
                    {
//                         using (sm_logger.InfoBlock("Writing a row.", "The row was written."))
                        {
                            e = SafeCall.Run(write_report);
                        }
                    }
                    finally
                    {
                        sm_logger_enabled = false;
                    }
                }
                else
                {
                    e = SafeCall.Run(write_report);
                }

                if (e != null)
                    return;

                next = next.AddSeconds(sm_seconds_interval);

                now = DateTime.Now;

                if (next > now)
                {
                    TimeSpan to = next - now;

                    if (sm_stop_report_event.WaitOne(to))
                    {
                        break;
                    }
                }
            }
        }

        static private ManualResetEvent sm_stop_report_event = new ManualResetEvent(false);
        static private Object lock_write_report = new Object();
        static private bool sm_reporting_enabled = true;

        private static void write_report()
        {
            if (sm_reporting_enabled == false)
            {
                return;
            }

            lock (lock_write_report)
            {
                Data data = new Data();
                data.Update();

                data.WriteCSV(sm_data);

                sm_data = data;
            }
        }

        private static Process sm_process;
        private static IntPtr sm_process_handle;
        private static UInt32 sm_number_of_logical_processors;

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool GetProcessAffinityMask(IntPtr hProcess, out UIntPtr lpProcessAffinityMask, out UIntPtr lpSystemAffinityMask);

        static SystemInformation()
        {
            sm_process = Process.GetCurrentProcess();
            sm_process_handle = sm_process.Handle;

            UIntPtr lpProcessAffinityMask,
                    lpSystemAffinityMask;

            bool ok = GetProcessAffinityMask(sm_process_handle, out lpProcessAffinityMask, out lpSystemAffinityMask);
            ulong affinity_mask = lpProcessAffinityMask.ToUInt64();
            sm_number_of_logical_processors = (uint)Math.Log(affinity_mask + 1, 2);
            Debug.Assert(sm_number_of_logical_processors > 0);
            if (sm_number_of_logical_processors == 0)
                sm_number_of_logical_processors = 1; // avoid DEVIDE-BY-ZERO
        }

        private static UInt32 sm_user_set_seconds_interval = 0;
        private static UInt32 sm_seconds_interval = 0;
//         private static Object sm_lock = new Object();
//         private static bool sm_busy = false;
//        private static Timer sm_ReportTimer;
        private static Thread sm_ReportThread;
        private static Data sm_data;
        private static Logger sm_logger = Logger.GetLogger(ReflectionHelper.GetClassName());

        /// <summary>
        /// Set "manually" this switch to true, if necessary.
        /// </summary>
        public static bool sm_logger_enabled = true;

        static PerformanceCounter create_cpuCounter()
        {
            PerformanceCounter cpuCounter = new PerformanceCounter();
            cpuCounter.CategoryName = "Processor";
            cpuCounter.CounterName = "% Processor Time";
            cpuCounter.InstanceName = "_Total";
            return cpuCounter;
        }

        static PerformanceCounter m_cpuCounter = create_cpuCounter();

        #endregion
    }
}

