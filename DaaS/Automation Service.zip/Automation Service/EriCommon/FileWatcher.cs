﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using TracerX;

namespace EriCommon
{
    /// <summary>
    /// The FileWatcher class
    /// </summary>
    public class FileWatcher
    {
        /// <summary>
        /// This delegate is called when the file is changed
        /// </summary>
        public delegate void OnChange(/*FileWatcher watcher,*/ FileSystemEventArgs e);

        /// <summary>
        /// The c-tor
        /// </summary>
        public FileWatcher(String filename, OnChange onChanged, UInt32 open_timeout_seconds, Logger logger, bool start = true)
        {
            m_path = filename;
            m_onChanged = onChanged;
            m_open_timeout_seconds = open_timeout_seconds;
            m_logger = logger;

            m_file_watcher = new FileSystemWatcher();

            m_is_folder = (File.GetAttributes(filename) & FileAttributes.Directory) == FileAttributes.Directory;

            if (m_is_folder)
            {
                m_file_watcher.Path = filename;
            }
            else
            {
                m_file_watcher.Path = Path.GetDirectoryName(filename);
                m_file_watcher.Filter = Path.GetFileName(filename);
            }

            m_file_watcher.NotifyFilter = NotifyFilters.LastWrite;

            m_file_watcher.Created += on_changed;
            m_file_watcher.Deleted += on_changed;
            m_file_watcher.Changed += on_changed;
            m_file_watcher.Renamed += on_changed;

            m_file_watcher.EnableRaisingEvents = start;
        }

        /// <summary>
        /// The d-tor
        /// </summary>
        ~FileWatcher()
        {
            Stop();
        }

        /// <summary>
        /// Stops raising event
        /// </summary>
        public void Stop()
        {
            lock(this)
            {
                m_file_watcher.EnableRaisingEvents = false;
            }
        }

        /// <summary>
        /// Starts raising event
        /// </summary>
        public void Start()
        {
            lock (this)
            {
                m_file_watcher.EnableRaisingEvents = true;
            }
        }

        /// <summary>
        /// The event source
        /// </summary>
        public object Sender
        {
            get { return m_source; }
        }

        /// <summary>
        /// The event arguments
        /// </summary>
        public FileSystemEventArgs EventArgs
        {
            get { return m_event_args; }
        }

        private void on_changed(object source, FileSystemEventArgs e)
        {
            lock (this)
            {
                try
                {
                    m_file_watcher.EnableRaisingEvents = false;

                    m_source = source;
                    m_event_args = e;

                    // NOTE: We get the event too early, while the file is still being written.
                    //		 We must wait for the file to be ready.

                    bool file_ready = m_is_folder;

                    DateTime start = DateTime.Now;

                    //UInt32 TIMEOUT_WAIT_FOR_CONFIG_FILE_READY_TO_RELOAD_SECONDS = m_WaitForConfigFileReadyToReloadSeconds.Value;

                    while (file_ready == false)
                    {
                        try
                        {
                            using (Stream stream = System.IO.File.Open(m_path, FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite))
                            {
                                if (stream != null)
                                {
                                    file_ready = true;
                                    break;
                                }
                            }
                        }
                        catch (IOException)
                        {
                            // file not ready yet

                            if (DateTime.Now > start.AddSeconds(m_open_timeout_seconds))
                            {
                                // don't wait any longer
                                if( m_logger != null)
                                    m_logger.Error(String.Format("Failed opening '{0}' file.\nReason : Timeout reached while trying to access the file", m_path));

                                break;
                            }

                            // keep waiting
                            Thread.Sleep(100);
                        }
                        catch (Exception ex)
                        {
                            // treat all other errors as fatal that can't be recovered
                            if( m_logger != null)
                                    m_logger.Error("Failed opening '{0}' file.\nReason: ", ex.AllMessages(8));
                            break;
                        }
                    }

                    if (file_ready == false)
                        return;

                    SafeCall.Run</*FileWatcher,*/ FileSystemEventArgs>(new SafeCall.DoIt</*FileWatcher,*/ FileSystemEventArgs>(m_onChanged), /*this,*/ e);
                }
                finally
                {
                    m_source = null;
                    m_event_args = null;
                    m_file_watcher.EnableRaisingEvents = true;
                }
            }
        }

        private readonly String     m_path;
        private readonly bool       m_is_folder;
        private readonly OnChange   m_onChanged;
        private readonly UInt32     m_open_timeout_seconds;
        private readonly Logger     m_logger;

        private object              m_source;
        private FileSystemEventArgs m_event_args;

        private FileSystemWatcher   m_file_watcher;
    }
}
