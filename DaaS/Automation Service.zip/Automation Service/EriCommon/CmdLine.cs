﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace EriCommon
{
    /// <summary>
    /// The CmdLine class
    /// </summary>
    public class CmdLine
    {
        #region Constructor
        /// <summary>
        /// The constructor
        /// </summary>
        public CmdLine(String cmd_line)
        {
            Set(cmd_line);
        }

        /// <summary>
        /// The constructor with array of params passed to the Program.Main or Service.OnStart methods
        /// </summary>
        public CmdLine(String[] cmd_line)
        {
            Set(cmd_line);
        }

        /// <summary>
        /// The process command line
        /// </summary>
        public static CmdLine GetProcessCommandLine()
        {
            return new CmdLine(System.Environment.CommandLine);
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        /// The Args property
        /// </summary>
        public String[] Args
        {
            get { return m_args; }
        }

        /// <summary>
        /// The Count property
        /// </summary>
        public uint Count
        {
            get { return (m_args == null) ? 0 : (uint)m_args.Length; }
        }

        #endregion Properties

        #region Retrieve Information

        /// <summary>
        /// Returns true if is empty
        /// </summary>
        public bool IsEmpty()
        {
            return m_args == null;
        }

        /// <summary>
        /// Returns an argument, by index
        /// </summary>
        public String GetArg(uint index, bool trim_value = true, bool remove_it = false)
        {
            String arg = m_args[index];

            _replace_double_string_marker(ref arg, true);

            if (trim_value)
                arg.Trim();

            if (remove_it)
                remove(index);

            return arg;
        }

        /// <summary>
        /// Gets a flag. Returns true if found.
        /// </summary>
        public bool GetFlag(String label, bool remove_it = false)
        {
            String _LABEL_1 = ARG_FLAG_1(label),
                   _LABEL_2 = ARG_FLAG_2(label);

            int index = -1;

            foreach (String arg in m_args)
            {
                index++;

                if (String.Compare(arg, _LABEL_1, StringComparison.OrdinalIgnoreCase) != 0 &&
                    String.Compare(arg, _LABEL_2, StringComparison.OrdinalIgnoreCase) != 0)
                {
                    continue;
                }

                if (remove_it)
                    remove((uint)index);

                return true;
            }

            return false;
        }

        /// <summary>
        /// Gets a value. Returns true if found.
        /// </summary>
        public bool GetValue(String label, out String value, bool trim_value = true, bool remove_it = false)
        {
            if (m_args == null)
            {
                value = null;
                return false;
            }

            String _LABEL_1 = ARG_LABEL_1(label),
                   _LABEL_2 = ARG_LABEL_2(label),
                   _LABEL_P = null;

            int index = -1;

            foreach (String arg in m_args)
            {
                index++;

                if (arg.IndexOf(_LABEL_1, StringComparison.OrdinalIgnoreCase) == 0)
                {
                    _LABEL_P = _LABEL_1;
                }
                else
                if (arg.IndexOf(_LABEL_2, StringComparison.OrdinalIgnoreCase) == 0)
                {
                    _LABEL_P = _LABEL_2;
                }
                else
                {
                    continue;
                }

                value = arg.Substring(_LABEL_P.Length);

                _replace_double_string_marker(ref value, true);

                if (trim_value)
                    value.Trim();

                if (remove_it)
                    remove((uint)index);

                return true;
            }

            value = null;
            return false;
        }

        /// <summary>
        /// ToString implementation
        /// </summary>
        public override String ToString()
        {
            String text = "";

            bool add_space = false;

            foreach (String s in m_args)
            {
                if (add_space)
                    text += "\x20";
                else
                    add_space = true;

                text += s;
            }

            return text;
        }

        #endregion Retrieve Information

        #region Modify

        /// <summary>
        /// Initializes from a string
        /// </summary>
        public void Set(String cmd_line)
        {
            m_args = null;

            if(cmd_line == null)
                return;

            cmd_line = cmd_line.Trim();

            uint max_c_idx = (uint)cmd_line.Length;

            if (max_c_idx == 0)
                return;

            m_args = new String[(cmd_line.Length+1) / 2];

            bool add_string_marker_terminator;
            uint c_idx = 0,
                 white_idx,
                 arg_idx = 0;

            for(;;)
            {
                _parse_one_parameter(cmd_line,
                                     c_idx,
                                     max_c_idx,
                                     out white_idx,
                                     out add_string_marker_terminator );

                String arg = cmd_line.Substring((int)c_idx, (int)(white_idx - c_idx));

        if( add_string_marker_terminator )
            arg += STRING_MARKER;

                m_args[arg_idx++] = arg;

                if(white_idx >= max_c_idx)
                    break;

                c_idx = white_idx + 1;

                // is not necessary to check for
                //                                  c_idx < max_c_idx
                // because the statement
                //                                  cmd_line = cmd_line.Trim();
                // removes also the trailing white spaces, therefore a valid token should end the command line anyway
                while (Char.IsWhiteSpace(cmd_line[(int)c_idx]))
                    c_idx++;
            }

            Debug.Assert(arg_idx > 0);

            if (m_args.Length > arg_idx)
                Array.Resize(ref m_args, (int)arg_idx);
        }

        /// <summary>
        /// Initializes from a string array
        /// </summary>
        public void Set(String[] cmd_line)
        {
            m_args = cmd_line;
        }

        /// <summary>
        /// Returns true if empty
        /// </summary>
        public void Empty()
        {
            m_args = null;
        }

        /// <summary>
        /// Adds an argument
        /// </summary>
        public void AddArg(String arg, bool treat_string_marker = true)
        {
            String to_add = arg;

            if (treat_string_marker)
                _replace_double_string_marker(ref to_add, false);

            append(to_add);
        }

        /// <summary>
        /// Adds a flag
        /// </summary>
        public void AddFlag(String label)
        {
            append(ARG_FLAG_1(label));
        }

        /// <summary>
        /// Removes a flag
        /// </summary>
        public bool RemoveFlag(String label)
        {
            return GetFlag(label, true);
        }

        /// <summary>
        /// Adds a value
        /// </summary>
        public void AddValue(String label, String value, bool treat_string_marker = true)
        {
            String to_add = value;

            if (treat_string_marker)
                _replace_double_string_marker(ref to_add, false);

            to_add = ARG_LABEL_1(label) + to_add;

            append(to_add);

        }

        /// <summary>
        /// Removes a value
        /// </summary>
        public bool RemoveValue(String label)
        {
            String value;
            return GetValue(label, out value, false, true);
        }

        /// <summary>
        /// Adds another CmdLine
        /// </summary>
        public void Add(CmdLine other)
        {
            if(other.m_args == null)
                return;

            if (m_args == null)
            {
                m_args = new String[other.m_args.Length];
                other.m_args.CopyTo(m_args, 0);

                return;
            }

            int target_index  = m_args.Length;
            int source_length = other.m_args.Length;

            Array.Resize(ref m_args, target_index + source_length);
            other.m_args.CopyTo(m_args, target_index);
        }

        /// <summary>
        /// Adds another CmdLine
        /// </summary>
        public void Add(String cmd_line)
        {
            Add(new CmdLine(cmd_line));
        }

        #endregion Modify

        #region Private Methods
        private static void _parse_one_parameter(string     cmd_line,
                                                 uint       begin_idx,
                                                 uint       max_idx,
                                                 out uint   idx,
                                                 out bool   add_string_marker_terminator)
        {
            idx = begin_idx;
            add_string_marker_terminator = false;

            for (; ; )
            {
                // Check string begin marker
                if (cmd_line[(int)idx] == STRING_MARKER &&
                    (idx == begin_idx ||
                     cmd_line[(int)(idx - 1)] == EQUAL_CHAR))
                {
                    _parse_into_string(cmd_line,
                                        max_idx,
                                        ref idx,
                                        ref add_string_marker_terminator);

                    break;	// for
                }

                idx++;

                // Check string / argument end
                if (idx >= max_idx ||
                    Char.IsWhiteSpace(cmd_line[(int)idx]))
                {
                    break;
                }
            }
        }

        private static void _parse_into_string(string   cmd_line,
                                               uint     max_idx,
                                               ref uint idx,
                                               ref bool add_string_marker_terminator)
        {
            for (; ; )
            {
                idx++;

                // Check string end
                if (idx >= max_idx)
                {
                    add_string_marker_terminator = true;
                    break;	// for
                }

                // Check string end marker
                if (cmd_line[(int)idx] == STRING_MARKER)
                {
                    idx++;

                    if (idx >= max_idx || cmd_line[(int)idx] != STRING_MARKER)
                    {
                        // not double string marker
                        break;	// for
                    }
                }
            }
        }

        private static void _replace_double_string_marker(ref String s, bool get_mode)
        {
            if (get_mode)
            {
                if (s.GetFirst() == STRING_MARKER)
                {
                    s = s.Substring(1, s.Length - 2);

                    s = s.Replace(double_string_marker,
                                   single_string_marker);
                }
            }
            else
            {
                if (s.IndexOfAny(space_or_tab) >= 0)
                {
                    if (s.IndexOf(STRING_MARKER) >= 0)
                        s = s.Replace(single_string_marker,
                                      double_string_marker);

                    s = STRING_MARKER + s + STRING_MARKER;
                }
            }
        }

        private void append(String to_add)
        {
            if (m_args == null)
                m_args = new String[1];
            else
                Array.Resize(ref m_args, m_args.Length + 1);

            m_args[m_args.Length - 1] = to_add;
        }

        private void remove(uint index)
        {
            if (m_args.Length == index + 1)
            {
                // this is the rightmost item
                if (index > 0)
                    Array.Resize(ref m_args, (int)index);
                else
                    m_args = null;

                return;
            }

            Array.Copy(m_args, index + 1, m_args, index, m_args.Length - index - 1);
            Array.Resize(ref m_args, m_args.Length - 1);
        }

        private static String ARG_FLAG_1(String label) { return '/' + label; }
        private static String ARG_FLAG_2(String label) { return '-' + label; }

        private static String ARG_LABEL_1(String label) { return '/' + label + EQUAL_CHAR; }
        private static String ARG_LABEL_2(String label) { return '-' + label + EQUAL_CHAR; }

        #endregion Private Methods

        #region Data Members
        private String[] m_args = null;

        private const char STRING_MARKER = '"';
        private const char EQUAL_CHAR = '=';
        private const String double_string_marker = "\"\"";
        private const String single_string_marker = "\"";
        static private char[] space_or_tab = { '\x20', '\t' };

        #endregion Data Members
    }
}
