﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.IO;
using System.Net.Security;
using System.Security;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using TracerX;

namespace EriCommon
{
    /// <summary>
    /// SslStreamEx replaces the System.Net.Security.SslStream class.
    /// It is supporting multiple asynchronous writes, that the System.Net.Security.SslStream avoids.
    /// </summary>
    public partial class SslStreamEx_OLD : Stream
    {
        private class ReadContext : IAsyncResult
        {
            private readonly SslStreamEx_OLD m_SslStreamEx;

            private byte[] m_original_buffer;
            private int m_original_offset;
            private int m_original_count;
            private AsyncCallback m_original_asyncCallback;
            private Object m_original_asyncState;

            private ManualResetEvent m_event = new ManualResetEvent(false);
            private Exception m_exception;
            private bool m_completed;
            private uint m_bytes_read;

            public ReadContext(SslStreamEx_OLD owner)
            {
                m_SslStreamEx = owner;
                reset();
            }

            public bool Decrypt()
            {
                // Do a synchronous read from the SslStream. This will implicitly call the InnerStread.Read method
                int decrypted_length = m_SslStreamEx.m_ssl_stream.Read(m_original_buffer,
                                                                       (int)(m_original_offset + m_bytes_read),
                                                                       (int)(m_original_count  - m_bytes_read));

                m_bytes_read += (uint)decrypted_length;

                return decrypted_length > 0;
            }

            public uint EncrypedSize
            {
                get { return GetEncrypedSize((uint)m_original_count - m_bytes_read); }
            }

            public static IAsyncResult BeginReadEx(SslStreamEx_OLD owner, byte[] buffer, int offset, int count, AsyncCallback asyncCallback, Object asyncState)
            {
                ReadContext read_context;

                if (owner.m_single_read_context == null)
                {
                    read_context = new ReadContext(owner);
                }
                else
                {
                    Debug.Assert(owner.m_current_read_context == null);
                    if (owner.m_current_read_context != null)
                        throw new NotSupportedException("An asynchronous read operation is already in progress.");

                    read_context = owner.m_single_read_context;
                }

                return read_context.BeginRead(buffer, offset, count, asyncCallback, asyncState);
            }

            private IAsyncResult BeginRead(byte[] buffer, int offset, int count, AsyncCallback asyncCallback, Object asyncState)
            {
                m_completed = false;

                m_original_buffer = buffer;
                m_original_offset = offset;
                m_original_count = count;
                m_original_asyncCallback = asyncCallback;
                m_original_asyncState = asyncState;

                if (m_SslStreamEx.m_pending_reads != null)
                {
                    m_SslStreamEx.m_pending_reads.Enqueue(this);
                    invoke_next(m_SslStreamEx);
                }
                else
                {
                    m_SslStreamEx.m_current_read_context = this;
                    invoke_me();
                }

                return this;
            }

            private static void invoke_next(SslStreamEx_OLD ssl_stream_ex)
            {
                Debug.Assert(ssl_stream_ex.m_pending_reads != null);

                if (ssl_stream_ex.m_current_read_context != null)
                    return;

                if (ssl_stream_ex.m_pending_reads.Count == 0)
                    return;

                ssl_stream_ex.m_current_read_context = ssl_stream_ex.m_pending_reads.Dequeue();

                ssl_stream_ex.m_current_read_context.invoke_me();
            }

            private void invoke_me()
            {
                Debug.Assert(m_SslStreamEx.m_current_read_context == this);
                m_next_read.BeginInvoke(m_SslStreamEx, on_read_completion, this);
            }

            private static void next_read(SslStreamEx_OLD ssl_stream_ex)
            {
                try
                {
                    ssl_stream_ex.m_current_read_context.m_exception = ssl_stream_ex.m_inner_stream.ReadEx();
                }
                catch (System.Exception ex)
                {
                    if(ssl_stream_ex.m_current_read_context.m_exception == null)
                        ssl_stream_ex.m_current_read_context.m_exception = ex;
                }
            }

            private void on_read_completion(IAsyncResult ar)
            {
                ReadContext ctx = (ReadContext)ar.AsyncState;
                ctx.m_completed = true;

                m_event.Set();

                if (ctx.m_original_asyncCallback != null)
                    ctx.m_original_asyncCallback(this);
            }

            delegate void NextRead(SslStreamEx_OLD ssl_stream_ex);

            private static NextRead m_next_read = new NextRead(next_read);

            public static int EndReadEx(SslStreamEx_OLD owner, IAsyncResult asyncResult)
            {
                ReadContext read_context = (ReadContext)asyncResult;

                Debug.Assert(owner == read_context.Owner);
                if (owner != read_context.Owner)
                    throw new ArgumentException("asyncResult was not created by this SslStreamEx instance.");

                return read_context.EndRead(asyncResult);
            }

            private int EndRead(IAsyncResult asyncResult)
            {
                bool done = false;

                try
                {
                    Debug.Assert(m_completed);

                    m_original_asyncState = null;

                    if (m_completed == false)
                        throw new InvalidOperationException("The asynchronous read is not yet m_completed.");

                    done = true;

                    if (m_exception != null)
                        throw m_exception;

                    return (int)m_bytes_read;
                }
                finally
                {
                    if (done)
                    {
                        reset();

                        lock (m_SslStreamEx.m_read_lock)
                        {
                            if (m_SslStreamEx.m_current_read_context == this)
                            {
                                m_SslStreamEx.m_current_read_context = null;

                                if (m_SslStreamEx.m_pending_reads != null)
                                    ReadContext.invoke_next(m_SslStreamEx);
                            }
                        }
                    }
                }
            }

            private void reset()
            {
                m_original_buffer = null;
                m_original_offset = 0;
                m_original_count = 0;
                m_original_asyncCallback = null;
                m_original_asyncState = null;

                m_event.Reset();

                m_bytes_read = 0;
                m_exception = null;
            }

            public SslStreamEx_OLD Owner
            {
                get { return m_SslStreamEx; }
            }

            #region IAsyncResult Members

            public object AsyncState
            {
                get { return m_original_asyncState; }
            }

            public System.Threading.WaitHandle AsyncWaitHandle
            {
                get { return m_event;/*throw new NotImplementedException();*/ }
            }

            public bool CompletedSynchronously
            {
                get { return false; }
            }

            public bool IsCompleted
            {
                get { return m_completed; }
            }

            #endregion
        } // end class ReadContext
    }
}
