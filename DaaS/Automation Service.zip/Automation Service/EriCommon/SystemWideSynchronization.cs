﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Security;

namespace EriCommon
{
    /// <summary>
    /// The SystemWideSynchronization helper class.
    /// </summary>
    public static class SystemWideSynchronization
    {
        /// <summary>
        /// Defines the MAX_PATH
        /// </summary>
        public const int MAX_PATH = 260;
        /// <summary>
        /// The GetName helper returns a corrected system wide synchronization name.
        /// </summary>
        public static string GetName(string name)
        {
            Debug.Assert(name != null);
            Debug.Assert(name.Length > 0 && name.Length <= MAX_PATH);

            string prefix = "";
            int idx = name.IndexOf("Global\\");

            if (idx == 0)
            {
                idx = 6;
            }
            else
            {
                idx = name.IndexOf("Local\\");
                if( idx == 0 )
                {
                    idx = 6;
                }
                else
                {
                    idx = name.IndexOf("Session\\");
                    if (idx == 0)
                    {
                        idx = 8;
                    }
                    else
                    {
                        idx = 0;
                    }
                }
            }

            if (idx > 0)
            {
                prefix = name.Substring(0, idx);
                name = name.Substring(idx);
            }

            name = prefix + name.Replace('\\', '/');
            if (name.Length > MAX_PATH)
                name = name.Substring(0, MAX_PATH);

            return name;
        }
    }

    /// <summary>
    /// The NamedAutoResetEvent class.
    /// </summary>
    public class NamedAutoResetEvent : EventWaitHandle
    {
        /// <summary>
        /// The NamedAutoResetEvent class constructor.
        /// </summary>
        [SecuritySafeCritical]
        public NamedAutoResetEvent(string name, bool initialState = false) :
            base(initialState, EventResetMode.AutoReset, SystemWideSynchronization.GetName(name))
        {
            Debug.Assert(name != null && name.Length > 0);
        }

        /// <summary>
        /// The Signal method.
        /// </summary>
        public void Signal()
        {
            Set();
        }
    }

    /// <summary>
    /// The NamedManualResetEvent class.
    /// </summary>
    public class NamedManualResetEvent : EventWaitHandle
    {
        /// <summary>
        /// The NamedAutoResetEvent class constructor.
        /// </summary>
        [SecuritySafeCritical]
        public NamedManualResetEvent(string name, bool initialState = false)
            : base(initialState, EventResetMode.ManualReset, SystemWideSynchronization.GetName(name))
        {
            Debug.Assert(name != null && name.Length > 0);
        }
    }

    /// <summary>
    /// The _singleAccessLock base class.
    /// </summary>
    public class _singleAccessLock : IDisposable
    {
        /// <summary>
        /// The _singleAccessLock class constructor.
        /// </summary>
        protected _singleAccessLock(EventWaitHandle handle)
        {
            m_handle  = handle;
            m_granted = m_handle.WaitOne();
        }

        /// <summary>
        /// The _singleAccessLock class constructor with timeout.
        /// </summary>
        protected _singleAccessLock(EventWaitHandle handle, Int32 milliseconds)
        {
            m_handle  = handle;
            m_granted = m_handle.WaitOne(milliseconds);
        }

        /// <summary>
        /// Returns the granted state
        /// </summary>
        public bool Granted
        {
            get { return m_granted; }
        }

        /// <summary>
        /// Unlocks the ReaderWriterLockSlim object.
        /// </summary>
        public void Dispose()
        {
            if (m_handle == null)
                return;

            if (m_granted)
                m_handle.Set();

            m_handle = null;
        }

        /// <summary>
        /// The Unlocker dtor.
        /// </summary>
        ~_singleAccessLock()
        {
            Debug.Assert(m_handle == null); // not used in a 'using' block
        }

        private EventWaitHandle m_handle;
        private readonly bool   m_granted;
    }

    /// <summary>
    /// The NamedSingleAccessLock class.
    /// </summary>
    public class NamedSingleAccessLock : _singleAccessLock
    {
        /// <summary>
        /// The NamedSingleAccessLock class constructor.
        /// </summary>
        public NamedSingleAccessLock(NamedAutoResetEvent handle) : base(handle) { }

        /// <summary>
        /// The NamedSingleAccessLock class constructor with timeout.
        /// </summary>
        public NamedSingleAccessLock(NamedAutoResetEvent handle, Int32 milliseconds) : base(handle, milliseconds) { }
    }

    /// <summary>
    /// The SingleAccessLock class.
    /// </summary>
    public class SingleAccessLock : _singleAccessLock
    {
        /// <summary>
        /// The SingleAccessLock class constructor.
        /// </summary>
        public SingleAccessLock(AutoResetEvent handle) : base(handle) { }

        /// <summary>
        /// The SingleAccessLock class constructor with timeout.
        /// </summary>
        public SingleAccessLock(AutoResetEvent handle, Int32 milliseconds) : base(handle, milliseconds) { }
    }

}
