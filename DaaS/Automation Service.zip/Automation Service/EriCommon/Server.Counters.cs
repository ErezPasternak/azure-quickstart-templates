﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;
using System.Runtime.Serialization;

using TracerX;

namespace EriCommon
{
    public partial class Server
    {
        /// <summary>
        /// The Counters class
        /// </summary>
        public class Counters
        {
            /// <summary>
            /// Returns true if the counters was changed after the last call to GetStatisticsText
            /// </summary>
            public bool Changed
            {
                get { return m_changed; }
            }

            /// <summary>
            /// Returns the number of submitted service requests, called when the service was requested
            /// </summary>
            public ulong Submit()
            {
                lock (this)
                {
                    m_changed = true;
                    m_submitted++;
                    return m_submitted;
                }
            }

            /// <summary>
            /// Called when the service was completed
            /// </summary>
            public void Resume(bool succeeded, double elapsed_seconds)
            {
                lock (this)
                {
                    m_changed = true;
                    if (succeeded) m_succeeded++;
                    else m_failed++;
                }

                if (m_max_elapsed_seconds < elapsed_seconds)
                    m_max_elapsed_seconds = elapsed_seconds;

                m_total_elapsed_seconds += elapsed_seconds;
            }

            /// <summary>
            /// Gets the statistics test line (NEW LINE appended)
            /// </summary>
            public String GetStatisticsText(String name, String format)
            {
                if (m_submitted == 0)
                    return null;

                lock (this)
                {
                    m_changed = false;

                    ulong done = m_succeeded + m_failed;
                    String text = String.Format("  {0,-10} = {1,7}  |  {2,-10} = {3,7}  |  {4,-10} = {5,7}  |  {6,-11} = {7,7:F3}  |  {8,-11} = {9,7:F3}\n",
                                                 "Accepted", m_submitted,
                                                 "Passed", m_succeeded,
                                                 "Failed", m_failed,
                                                 "Avg.Seconds", done > 0 ? m_total_elapsed_seconds / done : 0,
                                                 "Max.Seconds", m_max_elapsed_seconds);

                    return string.Format(format, name, text);
                }
            }

            private bool m_changed = false;
            private ulong m_submitted = 0;
            private ulong m_succeeded = 0;
            private ulong m_failed = 0;
            private double m_max_elapsed_seconds = 0;
            private double m_total_elapsed_seconds = 0;
        }
    }
}
