﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;

namespace EriCommon
{
    /// <summary>
    /// The CSV class creates and writes CSV files.
    /// </summary>
    public class CSV
    {
        #region Test & Demo

        /// <summary>
        /// A Demo method
        /// </summary>
        public static void Demo()
        {
            CSV csv = new CSV(@"E:\PM\Features\WC\BLAZE\Runtime\bin_GW\Logs\CSV_DEMO",
                               new CSV.DateTimeColumn("Date & Time"),    //0
                               new CSV.TimeSpanColumn("TimeSpan #1"),    //1
                               new CSV.TimeSpanColumn("TimeSpan #2"),    //2
                               new CSV.StringColumn("Text Sample"),      //3
                               new CSV.SignedColumn("Signed Sample"),    //4
                               new CSV.RealColumn("Real Sample")         //5
                               );

            // Line #2
            csv.AddLine(null, // current date
                         new TimeSpan(),
                         new TimeSpan(),
                         "a,\"better & different\",c",
                         1234567,
                         18.98765 / 0.1234567);

            Thread.Sleep(1234);
            TimeSpan ts = DateTime.Now - csv.GetColVal<DateTime>(0).GetValue();

            // Line #3
            csv.GetColVal<DateTime>(0).Empty = false;
            csv.GetColVal<TimeSpan>(1).Value = ts;
            csv.GetColVal<TimeSpan>(2).Value = ts + new TimeSpan(99, 0, 0, 0, 0);
            csv.GetColVal<string>(3).Value = "a,\"better & different\",c";
            csv.GetColVal<long>(4).Value = 1234567;
            csv.GetColVal<double>(5).Value = 18.98765 / 0.1234567;

            csv.AddLine();
        }

        #endregion

        #region Public

        /// <summary>
        /// The CSV.ITextExtractor interface.
        /// </summary>
        public abstract class ITextExtractor
        {
            internal string ExtractText(Object obj, LineCtx line_ctx, char comma_separator)
            {
                string text = extract_text(obj, line_ctx);
                text = CorrectText(text, comma_separator, needs_quotes());
                return text;
            }

            internal abstract string extract_text(Object obj, LineCtx line_ctx);

            internal virtual bool needs_quotes()
            {
                return false;
            }
        }

        /// <summary>
        /// The Dummy column extractor. The dummy column is anyway empty, therefore the value passed to AddLine for this column must be null.
        /// </summary>
        public class DummyExtractor : ITextExtractor
        {
            internal override string extract_text(Object obj, LineCtx line_ctx)
            {
                Debug.Assert(obj == null);   // maybe you are in a shift??? nothing to do with obj!!!
                return "";
            }

            internal DummyExtractor() { }
        }

        /// <summary>
        /// Returns the default dummy column extractor instance (singleton)
        /// </summary>
        public static ITextExtractor ExtractDummy
        {
            get { return sm_instance_DummyExtractor; }
        }

        /// <summary>
        /// The String column extractor, returns anyway the string value, therefore the value passed to AddLine for this column must be a string.
        /// </summary>
        public class StringExtractor : ITextExtractor
        {
            internal override string extract_text(Object obj, LineCtx line_ctx)
            {
                string s = (string)obj;
                s = s.Replace('\n', '\x20');
                return s;
            }

            internal StringExtractor() { }
        }

        /// <summary>
        /// Returns the default string extractor instance (singleton)
        /// </summary>
        public static ITextExtractor ExtractString
        {
            get { return sm_instance_StringExtractor; }
        }

        /// <summary>
        /// The DateTime column extractor. The value passed to AddLine for this column must be a DateTime or null.
        /// If the passed value is null or its Ticks property is ZERO, then the DateTime.Now will be used.
        /// </summary>
        public class DateTimeExtractor : ITextExtractor
        {
            internal override string extract_text(Object obj, LineCtx line_ctx)
            {
                if (obj == null)
                    return extract_text(DateTime.Now, null);

                DateTime dt = (DateTime)obj;

                if (dt.Ticks == 0)
                    return "";

                return dt.ToString("yyyy.MM.dd HH:mm:ss.fff");
            }

            internal DateTimeExtractor() { }
        }

        /// <summary>
        /// Returns the default DateTime extractor instance (singleton)
        /// </summary>
        public static ITextExtractor ExtractDateTime
        {
            get { return sm_instance_DateTimeExtractor; }
        }

        /// <summary>
        /// The TimeSpan column extractor. The value passed to AddLine for this column must be a TimeSpan or null.
        /// If the passed value is null, then the column will remain empty.
        /// If its Ticks property is ZERO and the 'm_suppress_ZERO' is true, then the column will remain empty.
        /// Milliseconds are/are not added, accordingly to the value of 'm_including_milliseconds'.
        /// </summary>
        public class TimeSpanExtractor : ITextExtractor
        {
            /// <summary>
            /// The TimeSpan column extractor. The value passed to AddLine for this column must be a TimeSpan.
            /// </summary>
            public TimeSpanExtractor(bool suppress_ZERO, bool including_milliseconds = false)
            {
                m_suppress_ZERO = suppress_ZERO;
                m_including_milliseconds = including_milliseconds;
            }

            internal override string extract_text(Object obj, LineCtx line_ctx)
            {
                if (obj == null)
                    return "";

                TimeSpan ts = (TimeSpan)obj;

                if (m_suppress_ZERO && ts.Ticks == 0)
                    return "";

                if(m_including_milliseconds)
                {
                    if (ts.Days > 0)
                        return ts.ToString(@"d\ \+\ hh\:mm\:ss\.fff");

                    return ts.ToString(@"\ h\:mm\:ss\.fff");
                }

                if (ts.Days > 0)
                    return ts.ToString(@"d\ \+\ hh\:mm\:ss");

                return ts.ToString(@"\ h\:mm\:ss");
            }

            internal override bool needs_quotes()
            {
                return true;
            }

            private readonly bool m_suppress_ZERO;
            private readonly bool m_including_milliseconds;
        }

        /// <summary>
        /// Returns the default TimeSpan extractor instance (singleton) that
        ///     * does not suppress ZERO.
        ///     * does not extract milliseconds.
        /// </summary>
        public static ITextExtractor ExtractTimeSpan
        {
            get { return sm_instance_TimeSpanExtractor; }
        }

        /// <summary>
        /// Returns the default TimeSpan extractor instance (singleton) that
        ///     * suppresses ZERO.
        ///     * does not extract milliseconds.
        /// </summary>
        public static ITextExtractor ExtractTimeSpan_SuppressZero
        {
            get { return sm_instance_TimeSpanExtractor_SuppressZero; }
        }

        /// <summary>
        /// Returns the default TimeSpan extractor instance (singleton) that
        ///     * does not suppress ZERO.
        ///     * extracts also milliseconds.
        /// </summary>
        public static ITextExtractor ExtractTimeSpan_ms
        {
            get { return sm_instance_TimeSpanExtractor_ms; }
        }

        /// <summary>
        /// Returns the default TimeSpan extractor instance (singleton) that
        ///     * suppresses ZERO.
        ///     * extracts also milliseconds.
        /// </summary>
        public static ITextExtractor ExtractTimeSpan_SuppressZero_ms
        {
            get { return sm_instance_TimeSpanExtractor_SuppressZero_ms; }
        }

        /// <summary>
        /// The Signed integer column extractor. The value passed to AddLine for this column must be a long number.
        /// If the value is ZERO and the 'm_suppress_ZERO' is true, then the column will remain empty.
        /// </summary>
        public class SignedExtractor : ITextExtractor
        {
            /// <summary>
            /// CSV.SignedExtractor ctor.
            /// </summary>
            public SignedExtractor(bool suppress_ZERO)
            {
                m_suppress_ZERO = suppress_ZERO;
            }

            internal override string extract_text(Object obj, LineCtx line_ctx)
            {
                long n = (long)obj;
                return (m_suppress_ZERO && n == 0) ? "" : string.Format("{0:N0}", n);
            }

            internal override bool needs_quotes()
            {
                return true;
            }

            private readonly bool m_suppress_ZERO;
        }

        /// <summary>
        /// Returns the default signed integer extractor instance (singleton) that does not suppress ZERO.
        /// </summary>
        public static ITextExtractor ExtractSigned
        {
            get { return sm_instance_SignedExtractor; }
        }

        /// <summary>
        /// Returns the default signed integer extractor instance (singleton) that suppresses ZERO.
        /// </summary>
        public static ITextExtractor ExtractSigned_SuppressZero
        {
            get { return sm_instance_SignedExtractor_SuppressZero; }
        }

        /// <summary>
        /// The Unsigned integer column extractor. The value passed to AddLine for this column must be an unsigned long number.
        /// If the value is ZERO and the 'm_suppress_ZERO' is true, then the column will remain empty.
        /// </summary>
        public class UnsignedExtractor : ITextExtractor
        {
            /// <summary>
            /// CSV.UnsignedExtractor ctor.
            /// </summary>
            public UnsignedExtractor(bool suppress_ZERO)
            {
                m_suppress_ZERO = suppress_ZERO;
            }

            internal override string extract_text(Object obj, LineCtx line_ctx)
            {
                ulong n = (ulong)obj;
                return (m_suppress_ZERO && n == 0) ? "" : string.Format("{0:N0}", n);
            }

            internal override bool needs_quotes()
            {
                return true;
            }

            private readonly bool m_suppress_ZERO;
        }

        /// <summary>
        /// Returns the default unsigned integer extractor instance (singleton) that does not suppress ZERO.
        /// </summary>
        public static ITextExtractor ExtractUnsigned
        {
            get { return sm_instance_UnsignedExtractor; }
        }

        /// <summary>
        /// Returns the default unsigned integer extractor instance (singleton) that suppresses ZERO.
        /// </summary>
        public static ITextExtractor ExtractUnsigned_SuppressZero
        {
            get { return sm_instance_UnsignedExtractor_SuppressZero; }
        }

        /// <summary>
        /// A structure holding two double numbers
        /// </summary>
        public struct Numbers
        {
            /// <summary>
            /// CSV.Numbers ctor
            /// 'n_1' is the DIVIDED number
            /// 'n_2' is the DIVISOR number
            /// </summary>
            public Numbers(double n_1, double n_2) { m_1 = n_1; m_2 = n_2; }

            /// <summary>
            /// m_1 is the DIVIDED number
            /// </summary>
            public double m_1;
            /// <summary>
            /// m_2 is the DIVISOR number
            /// </summary>
            public double m_2;
        }

        /// <summary>
        /// The PercentExtractor class, used to extract both percents and ratio.
        /// </summary>
        public class PercentExtractor : ITextExtractor
        {
            /// <summary>
            /// CSV.PercentExtractor ctor
            /// </summary>
            public PercentExtractor(bool as_ratio = false)
            {
                m_as_ratio = as_ratio;
            }

            internal override string extract_text(Object obj, LineCtx line_ctx)
            {
                Numbers n = (Numbers)obj;

                if (n.m_2 == 0)
                    return "";

                double val = (n.m_1 * 100.0) / n.m_2;

                if (m_as_ratio)
                {
                    val = 100.0 - val;
                }

                return string.Format("{0:F3}%", val);
            }

            private readonly bool m_as_ratio;
        }

        /// <summary>
        /// Returns the default percent extractor instance (singleton).
        /// </summary>
        public static ITextExtractor ExtractPercent
        {
            get { return sm_instance_PercentExtractor; }
        }

        /// <summary>
        /// Returns the default ratio extractor instance (singleton).
        /// </summary>
        public static ITextExtractor ExtractRatio
        {
            get { return sm_instance_RatioExtractor; }
        }

        /// <summary>
        /// The RealExtractor class, used to extract text for double values.
        /// IT DOES NOT WORK WELL: right size zeros are not displayed by EXCEL, therefore the alignment is damaged.
        /// </summary>
        public class RealExtractor : ITextExtractor
        {
            /// <summary>
            /// CSV.RealExtractor ctor
            /// </summary>
            public RealExtractor(bool suppress_ZERO, int decimal_digits = 2)
            {
                m_suppress_ZERO = suppress_ZERO;

                if(decimal_digits < 0)
                    m_format = "{0}";
                else if(sm_formats.Length > decimal_digits)
                    m_format = sm_formats[decimal_digits];
                else
                    m_format = String.Format( "{{0:F{0}}}", decimal_digits);
            }

            internal override string extract_text(Object obj, LineCtx line_ctx)
            {
                double n = (double)obj;
                return (m_suppress_ZERO && n == 0.0) ? "" : string.Format(m_format, n);
            }

            internal override bool needs_quotes()
            {
                return true;
            }

            private static String[] sm_formats = { "{0:F0}", "{0:F1}", "{0:F2}", "{0:F3}" };
            private readonly String m_format;
            private readonly bool m_suppress_ZERO;
        }

        /// <summary>
        /// Returns the default double extractor instance (singleton) that does not suppress ZERO.
        /// IT DOES NOT WORK WELL: right size zeros are not displayed by EXCEL, therefore the alignment is damaged.
        /// </summary>
        public static ITextExtractor ExtractReal
        {
            get { return sm_instance_RealExtractor; }
        }

        /// <summary>
        /// Returns the default double extractor instance (singleton) that suppresses ZERO.
        /// IT DOES NOT WORK WELL: right size zeros are not displayed by EXCEL, therefore the alignment is damaged.
        /// </summary>
        public static ITextExtractor ExtractReal_SuppressZero
        {
            get { return sm_instance_RealExtractor_SuppressZero; }
        }

        /// <summary>
        /// The CSV.ColDef class describes a CSV column.
        /// </summary>
        public abstract class ColDef
        {
            /// <summary>
            /// The CSV.ColDef ctor.
            /// </summary>
            public ColDef(string title, ITextExtractor text_extractor, bool can_be_empty)
            {
                m_title = title;
                m_can_be_empty = can_be_empty;
                m_text_extractor = text_extractor;
                Empty = true;
                Null = true;
            }

            /// <summary>
            /// The column title.
            /// </summary>
            public string Title
            {
                get { return m_title; }
            }

            /// <summary>
            /// The text of the object.
            /// </summary>

            internal abstract string ExtractText(LineCtx line_ctx, char comma_separator);
            internal string ExtractText(object obj, LineCtx line_ctx, char comma_separator)
            {
                set_value(obj);
                return ExtractText(line_ctx, comma_separator);
            }

            /// <summary>
            /// 'set_value' method "converts" the generic "object" to the right value type.
            /// </summary>
            protected abstract void set_value(object obj);
            /// <summary>
            /// The Empty property is set to false if the value of the column was set.
            /// After calling the 'AddLine' method, this property is unset.
            /// If a column is not Empty (was set) it cannot be set again (assertion).
            /// A column that is not marked as 'm_can_be_empty' must be set before calling the 'AddLine' method.
            /// An empty column value will leave the cell empty.
            /// </summary>
            public bool Empty
            {
                get;
                set;
            }

            /// <summary>
            /// The Null property.
            /// </summary>
            public bool Null
            {
                get;
                set;
            }

            internal readonly string m_title;
            internal readonly ITextExtractor m_text_extractor;
            internal readonly bool           m_can_be_empty;
        }

        /// <summary>
        /// The CSV.Column class describes a CSV column.
        /// The 'T' type
        /// </summary>
        public abstract class Column<T> : ColDef
        {
            /// <summary>
            /// Returns an empty T
            /// </summary>
            public enum TreatNullAs
            {
                /// <summary>
                /// Leave it empty
                /// </summary>
                Empty,
                /// <summary>
                /// Default or
                /// </summary>
                Default,
                /// <summary>
                /// Current
                /// </summary>
                Current = Default,
                /// <summary>
                /// Null
                /// </summary>
                Null,
            }

            /// <summary>
            /// The TreatNullAs property.
            /// </summary>
            public readonly TreatNullAs m_treat_null_as;

            /// <summary>
            /// The CSV.Column ctor.
            /// </summary>
            public Column(string title, ITextExtractor text_extractor, bool can_be_empty, TreatNullAs treat_null_as)
                : base(title, text_extractor, can_be_empty)
            {
                m_treat_null_as = treat_null_as;
            }

            /// <summary>
            /// Returns the T value.
            /// </summary>
            public T GetValue()
            {
                return m_value;
            }

            /// <summary>
            /// The Value property, used to set the value and unset the Empty property.
            /// </summary>
            public T Value
            {
                set
                {
                    Debug.Assert(Empty == true);   // this cell was already set
                    Empty = false;
                    Null = false;
                    m_value = value;
                }
            }

            internal override string ExtractText(LineCtx line_ctx, char comma_separator)
            {
                Debug.Assert(Empty == false || m_can_be_empty);
                try     { return (Null) ? "<null>" : (Empty) ? "" : m_text_extractor.ExtractText(get_value(), line_ctx, comma_separator); }
                finally { Null = true; Empty = true; }
            }

            /// <summary>
            /// Returns an empty T
            /// </summary>
            protected abstract T get_empty_value();
            /// <summary>
            ///returns the default T
            /// </summary>
            protected abstract T get_default_value();

            /// <summary>
            /// 'set_null_value' method simply casts the null object to the T type.
            /// The Empty property is implicitly unset.
            /// </summary>
            protected void set_null_value()
            {
                switch (m_treat_null_as)
                {
                    case TreatNullAs.Empty:   Value = get_empty_value();    //new DateTime();
                                              break;

                    case TreatNullAs.Default: Value = get_default_value(); //DateTime.Now;
                                              break;
                    case TreatNullAs.Null:    Debug.Assert(Empty == true);   // this cell was already set
                                              Empty = false;
                                              Null = true;
                                              break;
                }
            }

            /// <summary>
            /// 'set_value' method simply casts the object 'obj' to the T type.
            /// The Empty property is implicitly unset.
            /// </summary>
            protected override void set_value(object obj)
            {
                if (obj == null)
                    set_null_value();
                else
                    Value = (T)obj;
            }

            /// <summary>
            /// 'get_value' method returns the value, setting the Empty property too.
            /// </summary>
            protected T get_value()
            {
                Debug.Assert(Empty == false);  // this cell was not set
                return m_value;
            }

            /// <summary>
            /// The T value
            /// </summary>
            protected T m_value;
        }

        /// <summary>
        /// The CSV.DummyColumn class describes a CSV column.
        /// </summary>
        public class DummyColumn : Column<object>
        {
            /// <summary>
            /// The CSV.DummyColumn ctor.
            /// </summary>
            public DummyColumn(string title, bool can_be_empty = true)
                : base(title, ExtractDummy, can_be_empty, TreatNullAs.Empty)
            {
            }

            /// <summary>
            /// Returns an empty T
            /// </summary>
            protected override object get_empty_value() { return null; }

            /// <summary>
            ///returns the default T
            /// </summary>
            protected override object get_default_value() { return null; }
        }

        /// <summary>
        /// The CSV.DateTimeColumn class describes a CSV column.
        /// </summary>
        public class DateTimeColumn : Column<DateTime>
        {
            /// <summary>
            /// The CSV.DateTimeColumn ctor.
            /// </summary>
            public DateTimeColumn(string title, bool can_be_empty = false, TreatNullAs treat_null_as = TreatNullAs.Current)
                : base(title, ExtractDateTime, can_be_empty, treat_null_as)
            {
            }

            /// <summary>
            /// The CSV.DateTimeColumn ctor.
            /// </summary>
            public DateTimeColumn(string title, TreatNullAs treat_null_as, bool can_be_empty = false)
                : base(title, ExtractDateTime, can_be_empty, treat_null_as)
            {
            }

            /// <summary>
            /// Returns an empty T
            /// </summary>
            protected override DateTime get_empty_value() { return new DateTime(); }

            /// <summary>
            ///returns the default T
            /// </summary>
            protected override DateTime get_default_value() { return DateTime.Now; }
        }

        /// <summary>
        /// The CSV.TimeSpanColumn class describes a CSV column.
        /// </summary>
        public class TimeSpanColumn : Column<TimeSpan>
        {
            /// <summary>
            /// The CSV.TimeSpanColumn ctor.
            /// </summary>
            public TimeSpanColumn(string title, bool suppress_ZERO = true, bool can_be_empty = false)
                : base(title,
                       (suppress_ZERO) ? ExtractTimeSpan_SuppressZero : ExtractTimeSpan,
                       can_be_empty,
                       TreatNullAs.Empty)
            {
            }

            /// <summary>
            /// Returns an empty T
            /// </summary>
            protected override TimeSpan get_empty_value() { return new TimeSpan(); }

            /// <summary>
            ///returns the default T
            /// </summary>
            protected override TimeSpan get_default_value() { return new TimeSpan(); }
        }

        /// <summary>
        /// The CSV.StringColumn class describes a CSV column.
        /// </summary>
        public class StringColumn : Column<string>
        {
            /// <summary>
            /// The CSV.StringColumn ctor.
            /// </summary>
            public StringColumn(string title, bool can_be_empty = false, TreatNullAs treat_null_as = TreatNullAs.Empty)
                : base(title, ExtractString, can_be_empty, treat_null_as)
            {
            }

            /// <summary>
            /// The CSV.StringColumn ctor.
            /// </summary>
            public StringColumn(string title, TreatNullAs treat_null_as, bool can_be_empty = false)
                : base(title, ExtractString, can_be_empty, treat_null_as)
            {
            }

            /// <summary>
            /// Returns an empty T
            /// </summary>
            protected override string get_empty_value() { return ""; }

            /// <summary>
            ///returns the default T
            /// </summary>
            protected override string get_default_value() { return ""; }
        }

        /// <summary>
        /// The CSV.SignedColumn class describes a CSV column.
        /// </summary>
        public class SignedColumn : Column<long>
        {
            /// <summary>
            /// The CSV.SignedColumn ctor.
            /// </summary>
            public SignedColumn(string title, bool suppress_ZERO = true, bool can_be_empty = false)
                : base(title,
                       (suppress_ZERO) ? ExtractSigned_SuppressZero : ExtractSigned,
                       can_be_empty,
                       TreatNullAs.Empty)
            {
            }

            /// <summary>
            /// Returns an empty T
            /// </summary>
            protected override long get_empty_value() { return 0; }

            /// <summary>
            ///returns the default T
            /// </summary>
            protected override long get_default_value() { return 0; }

            /// <summary>
            /// 'set_value' method.
            /// This method deals with all kinds of integer numbers (signed and unsigned).
            /// An OverflowException will be thrown in overflow case.
            /// </summary>
            protected override void set_value(object obj)
            {
                if (obj == null)
                    set_null_value();
                else if( obj is long )
                    Value = (long)obj;
                else if (obj is int)
                    Value = (int)obj;
                else if (obj is short)
                    Value = (short)obj;
                else
                {
                    // deal with possible unsigned integers

                    ulong n = ulong.MaxValue;

                    if (obj is ulong)
                        n = (ulong)obj;
                    else if (obj is uint)
                        n = (uint)obj;
                    else if (obj is ushort)
                        n = (ushort)obj;
                    else if (obj is byte)
                        n = (byte)obj;

                    if (n <= long.MaxValue)
                        Value = (long)n;
                    else
                        throw new OverflowException(string.Format("Cannot convert {0} to long", n));
                }
            }
        }

        /// <summary>
        /// The CSV.UnsignedColumn class describes a CSV column.
        /// </summary>
        public class UnsignedColumn : Column<ulong>
        {
            /// <summary>
            /// The CSV.UnsignedColumn ctor.
            /// </summary>
            public UnsignedColumn(string title, bool suppress_ZERO = true, bool can_be_empty = false)
                : base(title,
                       (suppress_ZERO) ? ExtractUnsigned_SuppressZero : ExtractUnsigned,
                       can_be_empty,
                       TreatNullAs.Empty)
            {
            }

            /// <summary>
            /// Returns an empty T
            /// </summary>
            protected override ulong get_empty_value() { return 0; }

            /// <summary>
            ///returns the default T
            /// </summary>
            protected override ulong get_default_value() { return 0; }

            /// <summary>
            /// 'set_value' method.
            /// This method deals with all kinds of integer numbers (signed and unsigned).
            /// An OverflowException will be thrown if a negative number is passed as value.
            /// </summary>
            protected override void set_value(object obj)
            {
                if (obj == null)
                    set_null_value();
                else if (obj is ulong)
                    Value = (ulong)obj;
                else if (obj is uint)
                    Value = (uint)obj;
                else if (obj is ushort)
                    Value = (ushort)obj;
                else if (obj is byte)
                    Value = (byte)obj;
                else
                {
                    // deal with possible signed integers
                    long n = long.MinValue;

                    if (obj is long)
                        n = (long)obj;
                    else if (obj is int)
                        n = (int)obj;
                    else if (obj is short)
                        n = (short)obj;

                    if (n >= 0)
                        Value = (ulong)n;
                    else
                        throw new OverflowException(string.Format("Cannot convert {0} to ulong", n));
                }
            }
        }

        /// <summary>
        /// The CSV.KilobyteColumn class describes a CSV column.
        /// </summary>
        public class KilobyteColumn : SignedColumn
        {
            /// <summary>
            /// The CSV.KilobyteColumn ctor.
            /// </summary>
            public KilobyteColumn(string title, bool suppress_ZERO = true, bool can_be_empty = false)
                : base(title,
                       suppress_ZERO,
                       can_be_empty)
            {
            }

            /// <summary>
            /// 'set_value' method.
            /// Divides the value by 1024.
            /// </summary>
            protected override void set_value(object obj)
            {
                base.set_value(obj);
                if(!Null)
                    m_value /= 1024;
            }
        }

        /// <summary>
        /// The CSV.MegabyteColumn class describes a CSV column.
        /// </summary>
        public class MegabyteColumn : SignedColumn
        {
            /// <summary>
            /// The CSV.MegabyteColumn ctor.
            /// </summary>
            public MegabyteColumn(string title, bool suppress_ZERO = true, bool can_be_empty = false)
                : base(title,
                       suppress_ZERO,
                       can_be_empty)
            {
            }

            /// <summary>
            /// 'set_value' method.
            /// Divides the value by 1024 * 1024.
            /// </summary>
            protected override void set_value(object obj)
            {
                base.set_value(obj);
                if (!Null)
                    m_value /= 1024 * 1024;
            }
        }

        /// <summary>
        /// The CSV.RealColumn class describes a CSV column.
        /// </summary>
        public class RealColumn : Column<double>
        {
            /// <summary>
            /// The CSV.RealColumn ctor.
            /// </summary>
            public RealColumn(string title, bool suppress_ZERO = true, bool can_be_empty = false)
                : base(title,
                       (suppress_ZERO) ? ExtractReal_SuppressZero : ExtractReal,
                       can_be_empty,
                       TreatNullAs.Empty)
            {
            }

            /// <summary>
            /// The CSV.RealColumn ctor.
            /// </summary>
            public RealColumn(string title, RealExtractor extractor, bool can_be_empty = false)
                : base(title,
                       extractor,
                       can_be_empty,
                       TreatNullAs.Empty)
            {
            }

            /// <summary>
            /// Returns an empty T
            /// </summary>
            protected override double get_empty_value() { return 0.0; }

            /// <summary>
            ///returns the default T
            /// </summary>
            protected override double get_default_value() { return 0.0; }

            /// <summary>
            /// 'set_value' method.
            /// This method deals with all kinds of integer numbers (signed and unsigned).
            /// An OverflowException will be thrown if a negative number is passed as value.
            /// </summary>
            protected override void set_value(object obj)
            {
                if (obj == null)
                    set_null_value();
                else if (obj is double)
                    Value = (double)obj;
                else if (obj is float)
                    Value = (float)obj;
                else if (obj is int)
                    Value = (int)obj;
                else if (obj is uint)
                    Value = (uint)obj;
                else if (obj is short)
                    Value = (short)obj;
                else if (obj is ushort)
                    Value = (ushort)obj;
                else if (obj is byte)
                    Value = (byte)obj;
                else if (obj is long)
                {
                    long v_1 = (long)obj;
                    double n = v_1;
                    long v_2 = (long)n;

                    if(v_1 == v_2)
                        Value = n;
                    else
                        throw new OverflowException(string.Format("Cannot convert {0} to double", v_1));
                }
                else if (obj is ulong)
                {
                    ulong v_1 = (ulong)obj;
                    double n = v_1;
                    ulong v_2 = (ulong)n;

                    if (v_1 == v_2)
                        Value = n;
                    else
                        throw new OverflowException(string.Format("Cannot convert {0} to double", v_1));
                }
                else
                    Value = (double)obj;
            }
        }

        /// <summary>
        /// The CSV.PercentColumn class describes a CSV column.
        /// </summary>
        public class PercentColumn : Column<Numbers>
        {
            /// <summary>
            /// The CSV.PercentColumn ctor.
            /// </summary>
            public PercentColumn(string title, bool can_be_empty = false)
                : base(AddPercentChar(title),
                       ExtractPercent,
                       can_be_empty,
                       TreatNullAs.Empty)
            {
            }

            /// <summary>
            /// Returns an empty T
            /// </summary>
            protected override Numbers get_empty_value() { return new Numbers(0, 1); }

            /// <summary>
            ///returns the default T
            /// </summary>
            protected override Numbers get_default_value() { return new Numbers(0, 1); }

            /// <summary>
            /// .
            /// </summary>
            public static string AddPercentChar(string title)
            {
                const char percent_char = '%';

                if (title[title.Length - 1] != percent_char)
                    title += percent_char;

                return title;
            }
        }

        /// <summary>
        /// The CSV.RatioColumn class describes a CSV column.
        /// </summary>
        public class RatioColumn : Column<Numbers>
        {
            /// <summary>
            /// The CSV.RatioColumn ctor.
            /// </summary>
            public RatioColumn(string title, bool can_be_empty = false)
                : base(title,
                       ExtractPercent,
                       can_be_empty,
                       TreatNullAs.Empty)
            {
            }

            /// <summary>
            /// Returns an empty T
            /// </summary>
            protected override Numbers get_empty_value() { return new Numbers(0, 1); }

            /// <summary>
            ///returns the default T
            /// </summary>
            protected override Numbers get_default_value() { return new Numbers(0, 1); }
        }

        /// <summary>
        /// The CSV class constructor.
        /// </summary>
        public CSV(string filename,
                   params ColDef[] col_defs)
        {
            m_col_defs = col_defs;

            if (Path.GetExtension(filename).ToUpper() != sm_extension)
                filename += sm_extension;

            var EncoderFallback = new EncoderReplacementFallback("?");
            var utf8WithFallback = Encoding.GetEncoding("UTF-8", EncoderFallback, new DecoderExceptionFallback());

            m_writer = new StreamWriter(filename, false, utf8WithFallback);
            m_writer.AutoFlush = true;

            m_line = new Line(this);

            foreach (ColDef col_def in m_col_defs)
                m_line.Add(CorrectText(col_def.Title, m_comma_separator) );
        }

        /// <summary>
        /// The CSV class destructor.
        /// </summary>
        ~CSV()
        {
            Dispose();
        }

        /// <summary>
        /// The Dispose method.
        /// </summary>
        public void Dispose()
        {
            lock (this)
            {
                if (m_writer != null)
                {
                    try { m_writer.Dispose(); }
                    catch (Exception) { }
                    m_writer = null;
                }
            }
        }

        /// <summary>
        /// Returns the .CSV filename extension.
        /// </summary>
        public static string GetFileExtension()
        {
            return sm_extension;
        }

        /// <summary>
        /// Indexer operator, returning the ColDef base
        /// </summary>
        public ColDef this[UInt32 index]
        {
            get {  return m_col_defs[ index ]; }
        }

        /// <summary>
        /// Gets the type T qualified column by index.
        /// </summary>
        public Column<T> GetColVal<T>(UInt32 index)
        {
            return (Column<T>)(m_col_defs[ index ]);
        }

        /// <summary>
        /// The most usefull AddLine method.
        /// See example in the class SystemInformation.
        /// </summary>
        public void AddLine(params object[] values)
        {
            lock (this)
            {
                if (m_writer == null)
                    return;

                Debug.Assert(values.Length == m_col_defs.Length);

                int column_index = 0,
                    n_columns    = m_col_defs.Length;

                foreach (object obj in values)
                {
                    if(column_index >= n_columns)
                        break;

                    ColDef col_def = m_col_defs[column_index++];
                    m_line.Add(col_def.ExtractText(obj, m_line.m_ctx, m_comma_separator));
                }

                m_line.Flush();
            }
        }

        /// <summary>
        /// AddLine method, to be used after all relevant columns were filled in.
        /// See Demo method.
        /// </summary>
        public void AddLine()
        {
            lock (this)
            {
                if (m_writer == null)
                    return;

                foreach (ColDef col_def in m_col_defs)
                {
                    m_line.Add(col_def.ExtractText(m_line.m_ctx, m_comma_separator));
                }

                m_line.Flush();
            }
        }

        #endregion

        #region Private

        private static string CorrectText(string text, char comma_separator, bool use_quotas = false)
        {
            if (use_quotas == false &&
                text.IndexOf(comma_separator) >= 0)
            {
                use_quotas = true;
            }

            if (text.IndexOf('"') >= 0)
            {
                use_quotas = true;
                text = text.Replace("\"", "\"\"");
            }

            if (text.IndexOf('\n') >= 0)
            {
                text = text.Replace('\n', '\x20');
            }

            if (use_quotas)
                text = "\"" + text + "\"";

            return text;
        }

        internal class LineCtx
        {
            internal LineCtx() { }

            public uint LineNumber
            {
                get { return m_line_index + 1; }
            }

            public uint ColumnNumber
            {
                get { return m_column_index + 1; }
            }

            public DateTime LastWritten
            {
                get { return m_last_line_written; }
            }

            internal void NextLine()
            {
                m_last_line_written = DateTime.Now;
                m_line_index++;
                m_column_index = 0;
            }

            internal uint m_line_index = 0;
            internal uint m_column_index = 0;
            internal DateTime m_last_line_written;
        }

        private class Line
        {
            public Line(CSV csv)
            {
                m_csv = csv;
            }

            public void Flush()
            {
                if (m_ctx.m_column_index == 0)
                    return;

                flush();
            }

            public void Add(string text)
            {
                m_csv.m_writer.Write(text);
                m_ctx.m_column_index++;

                if (m_ctx.m_column_index == m_csv.m_col_defs.Length)
                {
                    flush();
                }
                else
                {
                    m_csv.m_writer.Write( m_csv.m_comma_separator );
                }
            }

            private void reset()
            {
            }

            private void flush()
            {
                m_csv.m_writer.WriteLine();
                m_csv.m_writer.Flush();
                m_ctx.NextLine();
            }

            private CSV     m_csv;
            public  LineCtx m_ctx = new LineCtx();
        }

        private const string    sm_extension = ".CSV";

        private StreamWriter    m_writer;
        private char            m_comma_separator = ',';
        private ColDef[]        m_col_defs;
        private Line            m_line;

        private static DummyExtractor    sm_instance_DummyExtractor                     = new DummyExtractor();
        private static StringExtractor   sm_instance_StringExtractor                    = new StringExtractor();
        private static DateTimeExtractor sm_instance_DateTimeExtractor                  = new DateTimeExtractor();
        private static TimeSpanExtractor sm_instance_TimeSpanExtractor                  = new TimeSpanExtractor(false);
        private static TimeSpanExtractor sm_instance_TimeSpanExtractor_SuppressZero     = new TimeSpanExtractor(true);
        private static TimeSpanExtractor sm_instance_TimeSpanExtractor_ms               = new TimeSpanExtractor(false,true);
        private static TimeSpanExtractor sm_instance_TimeSpanExtractor_SuppressZero_ms  = new TimeSpanExtractor(true,true);
        private static SignedExtractor   sm_instance_SignedExtractor                    = new SignedExtractor(false);
        private static SignedExtractor   sm_instance_SignedExtractor_SuppressZero       = new SignedExtractor(true);
        private static UnsignedExtractor sm_instance_UnsignedExtractor                  = new UnsignedExtractor(false);
        private static UnsignedExtractor sm_instance_UnsignedExtractor_SuppressZero     = new UnsignedExtractor(true);
        private static RealExtractor     sm_instance_RealExtractor                      = new RealExtractor(false);
        private static RealExtractor     sm_instance_RealExtractor_SuppressZero         = new RealExtractor(true);
        private static PercentExtractor  sm_instance_PercentExtractor                   = new PercentExtractor(false);
        private static PercentExtractor  sm_instance_RatioExtractor                     = new PercentExtractor(true);

        #endregion

    }
}

