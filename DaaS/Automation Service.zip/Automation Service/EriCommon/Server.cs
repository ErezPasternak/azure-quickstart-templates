﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;
using System.Runtime.Serialization;

using TracerX;

namespace EriCommon
{
    public partial class Server
    {
        #region Construction

        /// <summary>
        /// The CreateParams class
        /// </summary>
        public class CreateParams
        {
            private const bool  USE_LOGGER = true;
            /// <summary>
            /// The UseLogger property
            /// </summary>
            public bool UseLogger = USE_LOGGER;

            private const bool  USE_CSV = true;
            /// <summary>
            /// The UseCsv property
            /// </summary>
            public bool UseCsv = USE_CSV;

            private const uint  STATISTICS_FREQUENCY_SECONDS = 60;
            private uint        statistics_frequency_seconds = STATISTICS_FREQUENCY_SECONDS;

            /// <summary>
            /// Gets/sets the StatisticsFrequencySeconds property, in range 10 .. 3600 seconds
            /// </summary>
            public uint StatisticsFrequencySeconds
            {
                get
                {
                    return statistics_frequency_seconds;
                }

                set
                {
                    if (value < 10) value = 10;
                    if (value > 3600) value = 3600;

                    statistics_frequency_seconds = value;
                }
            }

            private const uint  FIELD_NAME_LENGTH = 15;
            private uint        field_name_length = FIELD_NAME_LENGTH;

            /// <summary>
            /// Gets/sets the FieldNameLength property, in range 10 .. 64 characters
            /// </summary>
            public uint FieldNameLength
            {
                get
                {
                    return field_name_length;
                }

                set
                {
                    if (value < 10) value = 10;
                    if (value > 64) value = 64;

                    field_name_length = value;
                }
            }

            private const uint  SERVICE_NAME_LENGTH = 24;
            private uint        service_name_length = SERVICE_NAME_LENGTH;

            /// <summary>
            /// Gets/sets the ServiceNameLength property, in range 10 .. 64 characters
            /// </summary>
            public uint ServiceNameLength
            {
                get
                {
                    return service_name_length;
                }

                set
                {
                    if (value < 10) value = 10;
                    if (value > 64) value = 64;

                    service_name_length = value;
                }
            }
        }

        private static readonly CreateParams st_default_create_params = new CreateParams();

        /// <summary>
        /// Constructor
        /// </summary>
        public Server(String name, bool is_server_side, CreateParams create_params = null)
        {
            Debug.Assert(! String.IsNullOrWhiteSpace(name));

            Features = new Features();

            if(create_params == null)
                create_params = st_default_create_params;

            Name = name;
            m_is_server_side = is_server_side;

            if (create_params.UseCsv)
                create_CSV();

            if (create_params.UseLogger)
            {
                Logger = Logger.GetLogger(Name);

                UInt32 freq_ms = create_params.StatisticsFrequencySeconds * 1000;
                m_timer = TimersThread.Default.AddTimer(Name + " Statistics Timer",
                                                         log_statistics,
                                                         this,
                                                         freq_ms,
                                                         freq_ms,
                                                         TimersThread.BusyMode.LOG_AND_SKIP);
            }

            m_field_format = new NameFormat(create_params.FieldNameLength, true);
            m_service_name_format = new NameFormat(create_params.ServiceNameLength, false);

//             if (m_is_server_side == false)
//                 m_multi_step_request_registry = new MultiStepRequestRegistry(this, 10);
        }

        /// <summary>
        /// Destructor
        /// </summary>
        ~Server()
        {
            if (m_csv != null)
            {
                m_csv.Dispose();
            }
        }
        #endregion Construction

        #region Properties

        /// <summary>
        /// The server name
        /// </summary>
        public String Name
        {
            get;
            private set;
        }

        /// <summary>
        /// The logger
        /// </summary>
        public Logger Logger
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets/sets the field name length
        /// </summary>
        public uint FieldNameLength
        {
            get { return m_field_format.Length; }
            set { m_field_format.Length = value; }
        }

        /// <summary>
        /// Gets/sets the service name length
        /// </summary>
        public uint ServiceNameLength
        {
            get { return m_service_name_format.Length; }
            set { m_service_name_format.Length = value; }
        }

        /// <summary>
        /// The list of features (registered services)
        /// </summary>
        public Features Features
        {
            get;
            private set;
        }

        /// <summary>
        /// Sends to the Logger the list of registered services
        /// </summary>
        public void LogFeatures()
        {
            if (Logger == null)
                return;

            Logger.Info("Features:\n", Features.ToString());
        }

        #endregion Properties

        #region Public methods

        /// <summary>
        /// Returns true if it is the SERVER side
        /// </summary>
        public bool IsServerSide()
        {
            return m_is_server_side;
        }

        /// <summary>
        /// Returns true if it is the CLIENT side
        /// </summary>
        public bool IsClientSide()
        {
            return !m_is_server_side;
        }

        /// <summary>
        /// Creates a sub-logger
        /// </summary>
        public Logger CreateLogger(String suffix)
        {
            return (Logger != null) ? Logger.GetLogger(Logger.Name + TracerX.Logger.TreeSeparator + suffix) :
                                        null;
        }

        /// <summary>
        /// Formats a line containing the field name and value (new line appended).
        /// </summary>
        public String GetFieldText(String field_name, Object val, bool table_format = true)
        {
            Debug.Assert(field_name.Length <= FieldNameLength);
            Debug.Assert(!String.IsNullOrWhiteSpace(field_name));

            return (table_format) ? String.Format(m_field_format.ToString(), field_name, val.ToString().ShiftLinesRight(FieldNameLength + 2, false)) :
                                    String.Format("{0}: {1}\n", field_name, val.ToString());
        }

        /// <summary>
        /// Converts the message ID the a string. When overridden, an enum value name can be returned.
        /// </summary>
        public virtual String GetMessageIdText(int message_id)
        {
            return message_id.ToString();
        }

//         public MultiStepRequest GetRequest(Guid guid)
//         {
//             return m_multi_step_request_registry.Lookup(guid);
//         }

        #endregion Public methods

        #region Private methods

        private static void log_statistics(Object me)
        {
            ((Server)me).log_statistics();
        }

        private void log_statistics()
        {
            lock (m_services_list)
            {
                if (!m_counters.Changed)
                    return;

                String text = "Statistics:\n";

                foreach (Service service in m_services_list)
                {
                    String line = service.GetStatisticsText();

                    if (String.IsNullOrWhiteSpace(line) == false)
                        text += line;
                }

                text += m_counters.GetStatisticsText("GRAND TOTAL", m_service_name_format.ToString());

                Logger.Info(text);
            }
        }

//         void add(MultiStepRequest request, MultiStepResponse response)
//         {
//             m_multi_step_request_registry.Add(request, response);
//         }

        #endregion Private methods

//        private MultiStepRequestRegistry m_multi_step_request_registry;
        private readonly Timer m_timer;
        private readonly bool m_is_server_side;
        private Counters m_counters = new Counters();

        NameFormat m_field_format;
        NameFormat m_service_name_format;

        private List<Service> m_services_list = new List<Service>();
        private SortedList<String, Service> m_services_sorted = new SortedList<String, Service>();

        private CSV m_csv;
    }
}
