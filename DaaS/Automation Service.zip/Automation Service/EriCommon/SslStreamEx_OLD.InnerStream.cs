﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net.Security;
using System.Security;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using TracerX;

namespace EriCommon
{
    /// <summary>
    /// SslStreamEx replaces the System.Net.Security.SslStream class.
    /// It is supporting multiple asynchronous writes, that the System.Net.Security.SslStream avoids.
    /// </summary>
    public partial class SslStreamEx_OLD : Stream
    {
        private class InnerStream : Stream
        {
            private SslStreamEx_OLD m_SslStreamEx;
            private Stream m_outer_stream;
            private byte[] m_write_buffer = null;
            private uint m_write_index = 0;
            public byte[] m_raw_data = null;
            private byte[] m_hs_read_buffer = null;
            private int m_hs_read_buffer_offset;

            public InnerStream(SslStreamEx_OLD owner, Stream outer_stream)
            {
                m_SslStreamEx = owner;
                m_outer_stream = outer_stream;
            }

            public override bool CanRead
            {
                get { return m_outer_stream.CanRead; }
            }

            public override bool CanSeek
            {
                get { return false; }
            }

            public override bool CanWrite
            {
                get { return m_outer_stream.CanWrite; }
            }

            public override void Flush()
            {
                m_outer_stream.Flush();
            }

            public override long Length
            {
                get { return m_outer_stream.Length; }
            }

            public override long Position
            {
                get
                {
                    return m_outer_stream.Position;
                }
                set
                {
                    m_outer_stream.Position = value;
                }
            }

            private void copy_raw_data(byte[] source_buffer, int source_offset, Int32 bytes_read)
            {
                int raw_data_orig_length = m_raw_data.Length;
                Array.Resize(ref m_raw_data, m_raw_data.Length + bytes_read);
                Array.Copy(source_buffer, source_offset, m_raw_data, raw_data_orig_length, bytes_read);
            }

            public override int Read(byte[] buffer, int offset, int count)
            {
                Debug.Assert(buffer != null);
                Debug.Assert(offset >= 0);
                Debug.Assert(count > 0);
                Debug.Assert(buffer.Length >= offset + count);

                if (m_SslStreamEx.m_current_read_context == null)
                {
                    Int32 bytes_read = m_outer_stream.Read(buffer, offset, count);

                    if (m_raw_data != null && bytes_read > 0)
                    {
                        copy_raw_data(buffer, offset, bytes_read);
                    }

                    return bytes_read;
                }

                int available_length = (int)(m_read_length - m_read_index),
                    read_length      = available_length;

                if (read_length > 0) // There is already data available in the the READ buffer
                {
                    if (read_length > count)
                        read_length = count;

                    Unsafe.MemCpy(m_read_buffer,
                                  m_read_index,
                                  buffer,
                                  (uint)offset,
                                  (uint)read_length);

                    m_read_index += (uint)read_length;

                    return read_length;
                }

                if (m_read_from_outer_stream == false && offset == 0)  // Do not read from the OUTER stream
                    return 0;

                return read_from_outer_stream(buffer, offset, count);   // synchronous READ from the OUTER stream
            }

            public override long Seek(long offset, SeekOrigin origin)
            {
                return m_outer_stream.Seek(offset, origin);
            }

            public override void SetLength(long value)
            {
                m_outer_stream.SetLength(value);
            }

            public override void Write(byte[] buffer, int offset, int count)
            {
                Debug.Assert(buffer != null);
                Debug.Assert(offset >= 0);
                Debug.Assert(count > 0);
                Debug.Assert(buffer.Length >= offset + count);

                if (m_write_buffer != null)
                {
                    Debug.Assert(m_write_index + count <= m_write_buffer.Length);

                    // Append to the memory buffer
                    Unsafe.MemCpy(buffer,
                                  (uint)offset,
                                  m_write_buffer,
                                  m_write_index,
                                  (uint)count);

                    m_write_index += (uint)count;

                    return;
                }

                m_outer_stream.Write(buffer, offset, count);
            }

            public IAsyncResult BeginWriteEx(byte[] buffer, int offset, int count, AsyncCallback asyncCallback, Object asyncState)
            {
                Debug.Assert(buffer != null);
                Debug.Assert(m_write_buffer == null);
                Debug.Assert(m_write_index == 0);

                uint encrypted_size = GetEncrypedSize((uint)count);
                byte[] memory_buffer = m_SslStreamEx.m_owner.GetWriteBuffer(encrypted_size, ref asyncState);
                Debug.Assert(encrypted_size <= memory_buffer.Length);

                m_write_buffer = memory_buffer;

                m_SslStreamEx.m_ssl_stream.Write(buffer, offset, count);
                m_SslStreamEx.m_owner.OnReadyToWriteOnOuterStream(asyncState);

                IAsyncResult result = m_outer_stream.BeginWrite(m_write_buffer, 0, (int)m_write_index, asyncCallback, asyncState);

                m_write_buffer = null;
                m_write_index = 0;

                return result;
            }

            private const uint m_read_buffer_allocation_chunk_size = 1024 * 16;
            private byte[] m_read_buffer = new byte[ m_read_buffer_allocation_chunk_size ];
            private uint m_read_index = 0;
            private uint m_read_length = 0;
            private bool m_read_from_outer_stream = true;

            public Exception ReadEx()
            {
                Debug.Assert(m_SslStreamEx.m_current_read_context != null);

                ReadContext ctx = m_SslStreamEx.m_current_read_context;

                m_read_from_outer_stream = false;

                // First try to read pending data
                if (ctx.Decrypt())
                {
                    m_read_from_outer_stream = true;
                    return null;
                }

                m_read_from_outer_stream = true;

                uint encrypted_size = ctx.EncrypedSize,
                     available_size = m_read_length - m_read_index;

                uint bytes_to_read = encrypted_size - available_size;

                if (bytes_to_read > 0)
                {
                    // make room
                    uint required_buffer_size = m_read_length + bytes_to_read;

                    if (m_read_buffer.Length < required_buffer_size)
                        Array.Resize<byte>(ref m_read_buffer, (int)required_buffer_size);

                    //Do a synchronous read from the OUTER stream
                    try
                    {
                        Debug.Assert(m_read_buffer.Length >= m_read_length + bytes_to_read);

                        int bytes_read = read_from_outer_stream(m_read_buffer, (int)m_read_length, (int)bytes_to_read);

                        if (bytes_read == 0)
                        {
                            return null;
                            //throw new IOException("EOF reached in the outer stream.");
                        }

                        m_read_length += (uint)bytes_read;
                    }
                    catch (System.Exception ex)
                    {
                        return ex;
                    }
                }

                try
                {
                    // Decrypt all the data already read from the OUTER stream
                    do
                    {
                        if (ctx.Decrypt() == false)
                            break;
                    }
                    while (m_read_length > m_read_index);
                }
                catch (System.Exception ex)
                {
                    return ex;
                }

                Debug.Assert(m_read_length >= m_read_index);

                if (m_read_index > 0)
                {
                    uint remaining = m_read_length - m_read_index;

                    if (remaining > 0)
                        // Shift left the remaining data, if any
                        System.Buffer.BlockCopy(m_read_buffer,
                                                (int)m_read_index,
                                                m_read_buffer,
                                                0,
                                                (int)remaining);

                    m_read_length = remaining;
                    m_read_index = 0;
                }

                return null;
            }

            public override IAsyncResult BeginRead(byte[] buffer, int offset, int count, AsyncCallback asyncCallback, Object asyncState)
            {
                if (m_raw_data != null)
                {
                    m_hs_read_buffer = buffer;
                    m_hs_read_buffer_offset = offset;
                }

                return m_outer_stream.BeginRead(buffer, offset, count, asyncCallback, asyncState);
            }

            public override int EndRead(IAsyncResult asyncResult)
            {

                Int32 bytes_read = m_outer_stream.EndRead(asyncResult);

                if (m_raw_data != null && bytes_read > 0)
                {
                    copy_raw_data(m_hs_read_buffer, m_hs_read_buffer_offset, bytes_read);
                    m_hs_read_buffer = null;
                }

                return bytes_read;
            }

            public override IAsyncResult BeginWrite(byte[] buffer, int offset, int count, AsyncCallback asyncCallback, Object asyncState)
            {
                return m_outer_stream.BeginWrite(buffer, offset, count, asyncCallback, asyncState);
            }

            public override void EndWrite(IAsyncResult asyncResult)
            {
                m_outer_stream.EndWrite(asyncResult);
            }

            public override int ReadTimeout
            {
                get { return m_outer_stream.ReadTimeout; }
                set { m_outer_stream.ReadTimeout = value; }
            }

            public override int WriteTimeout
            {
                get { return m_outer_stream.WriteTimeout; }
                set { m_outer_stream.WriteTimeout = value; }
            }

            int read_from_outer_stream(byte[] buffer, int offset, int count)
            {
                IAsyncResult result = m_outer_stream.BeginRead(buffer, offset, count, null, null);
                result.AsyncWaitHandle.WaitOne();
                int bytes_read = m_outer_stream.EndRead(result);
                result.AsyncWaitHandle.Close();

                return bytes_read;
            }
        }
    }
}
