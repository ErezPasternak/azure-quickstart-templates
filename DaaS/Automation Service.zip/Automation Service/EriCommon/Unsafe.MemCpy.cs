﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using TracerX;

namespace EriCommon
{
    /// <summary>
    /// The Unsafe class provide unsafe, low-level static methods.
    /// </summary>
    public unsafe partial class Unsafe
    {
        #region MemCpy

        /// <summary>
        /// The MemCpy of byte arrays.
        /// </summary>
        public static void MemCpy(byte[] source, uint source_offset, byte[] target, uint target_offset, uint count)
        {
//#if UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE
            if(count < MINIMUM_SIZE / sizeof(byte))
            {
                Array.Copy(source, (int)source_offset, target, (int)target_offset, (int)count);
                return;
            }
//#endif //UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE
            MemCpyFunc func = get_MemCpyFunc(source, source_offset, target, target_offset, count);
            if( func == MemCpyFunc.None )
                return;

            if (func == MemCpyFunc.ArrayCopy)
            {
                Array.Copy(source, (int)source_offset, target, (int)target_offset, (int)count);
                return;
            }

            fixed (byte* pSrc = source, pDst = target)
            {
                byte* ps = pSrc; ps += source_offset; byte* pd = pDst; pd += target_offset;
                switch (func)
                {
                    case MemCpyFunc.KernelCopy: CopyMemory((IntPtr)pd, (IntPtr)ps, (IntPtr)(count * sizeof(byte))); break;
                    case MemCpyFunc.KernelMove: MoveMemory((IntPtr)pd, (IntPtr)ps, (IntPtr)(count * sizeof(byte))); break;
                }
            }
        }

        /// <summary>
        /// The MemCpy of short arrays.
        /// </summary>
        public static void MemCpy(short[] source, uint source_offset, short[] target, uint target_offset, uint count)
        {
//#if UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE
            if (count < MINIMUM_SIZE / sizeof(short))
            {
                Array.Copy(source, (int)source_offset, target, (int)target_offset, (int)count);
                return;
            }
//#endif //UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE

            MemCpyFunc func = get_MemCpyFunc(source, source_offset, target, target_offset, count);
            if( func == MemCpyFunc.None )
                return;

            if (func == MemCpyFunc.ArrayCopy)
            {
                Array.Copy(source, (int)source_offset, target, (int)target_offset, (int)count);
                return;
            }

            fixed (short* pSrc = source, pDst = target)
            {
                short* ps = pSrc; ps += source_offset; short* pd = pDst; pd += target_offset;
                switch (func)
                {
                    case MemCpyFunc.KernelCopy: CopyMemory((IntPtr)pd, (IntPtr)ps, (IntPtr)(count * sizeof(short))); break;
                    case MemCpyFunc.KernelMove: MoveMemory((IntPtr)pd, (IntPtr)ps, (IntPtr)(count * sizeof(short))); break;
                }
            }

        }

        /// <summary>
        /// The MemCpy of ushort arrays.
        /// </summary>
        public static void MemCpy(ushort[] source, uint source_offset, ushort[] target, uint target_offset, uint count)
        {
//#if UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE
            if (count < MINIMUM_SIZE / sizeof(ushort))
            {
                Array.Copy(source, (int)source_offset, target, (int)target_offset, (int)count);
                return;
            }
//#endif //UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE

            MemCpyFunc func = get_MemCpyFunc(source, source_offset, target, target_offset, count);
            if( func == MemCpyFunc.None )
                return;

            if (func == MemCpyFunc.ArrayCopy)
            {
                Array.Copy(source, (int)source_offset, target, (int)target_offset, (int)count);
                return;
            }

            fixed (ushort* pSrc = source, pDst = target)
            {
                ushort* ps = pSrc; ps += source_offset; ushort* pd = pDst; pd += target_offset;
                switch (func)
                {
                    case MemCpyFunc.KernelCopy: CopyMemory((IntPtr)pd, (IntPtr)ps, (IntPtr)(count * sizeof(ushort))); break;
                    case MemCpyFunc.KernelMove: MoveMemory((IntPtr)pd, (IntPtr)ps, (IntPtr)(count * sizeof(ushort))); break;
                }
            }
        }

        /// <summary>
        /// The MemCpy of int arrays.
        /// </summary>
        public static void MemCpy(int[] source, uint source_offset, int[] target, uint target_offset, uint count)
        {
//#if UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE
            if (count < MINIMUM_SIZE / sizeof(int))
            {
                Array.Copy(source, (int)source_offset, target, (int)target_offset, (int)count);
                return;
            }
//#endif //UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE

            MemCpyFunc func = get_MemCpyFunc(source, source_offset, target, target_offset, count);
            if( func == MemCpyFunc.None )
                return;

            if (func == MemCpyFunc.ArrayCopy)
            {
                Array.Copy(source, (int)source_offset, target, (int)target_offset, (int)count);
                return;
            }

            fixed (int* pSrc = source, pDst = target)
            {
                int* ps = pSrc; ps += source_offset; int* pd = pDst; pd += target_offset;
                switch (func)
                {
                    case MemCpyFunc.KernelCopy: CopyMemory((IntPtr)pd, (IntPtr)ps, (IntPtr)(count * sizeof(int))); break;
                    case MemCpyFunc.KernelMove: MoveMemory((IntPtr)pd, (IntPtr)ps, (IntPtr)(count * sizeof(int))); break;
                }
            }
        }

        /// <summary>
        /// The MemCpy of uint arrays.
        /// </summary>
        public static void MemCpy(uint[] source, uint source_offset, uint[] target, uint target_offset, uint count)
        {
//#if UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE
            if (count < MINIMUM_SIZE / sizeof(uint))
            {
                Array.Copy(source, (int)source_offset, target, (int)target_offset, (int)count);
                return;
            }
//#endif //UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE

            MemCpyFunc func = get_MemCpyFunc(source, source_offset, target, target_offset, count);
            if( func == MemCpyFunc.None )
                return;

            if (func == MemCpyFunc.ArrayCopy)
            {
                Array.Copy(source, (int)source_offset, target, (int)target_offset, (int)count);
                return;
            }

            fixed (uint* pSrc = source, pDst = target)
            {
                uint* ps = pSrc; ps += source_offset; uint* pd = pDst; pd += target_offset;
                switch (func)
                {
                    case MemCpyFunc.KernelCopy: CopyMemory((IntPtr)pd, (IntPtr)ps, (IntPtr)(count * sizeof(uint))); break;
                    case MemCpyFunc.KernelMove: MoveMemory((IntPtr)pd, (IntPtr)ps, (IntPtr)(count * sizeof(uint))); break;
                }
            }
        }

        /// <summary>
        /// The MemCpy of long arrays.
        /// </summary>
        public static void MemCpy(long[] source, uint source_offset, long[] target, uint target_offset, uint count)
        {
//#if UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE
            if (count < MINIMUM_SIZE / sizeof(long))
            {
                Array.Copy(source, (int)source_offset, target, (int)target_offset, (int)count);
                return;
            }
//#endif //UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE

            MemCpyFunc func = get_MemCpyFunc(source, source_offset, target, target_offset, count);
            if( func == MemCpyFunc.None )
                return;

            if (func == MemCpyFunc.ArrayCopy)
            {
                Array.Copy(source, (int)source_offset, target, (int)target_offset, (int)count);
                return;
            }

            fixed (long* pSrc = source, pDst = target)
            {
                long* ps = pSrc; ps += source_offset; long* pd = pDst; pd += target_offset;
                switch (func)
                {
                    case MemCpyFunc.KernelCopy: CopyMemory((IntPtr)pd, (IntPtr)ps, (IntPtr)(count * sizeof(long))); break;
                    case MemCpyFunc.KernelMove: MoveMemory((IntPtr)pd, (IntPtr)ps, (IntPtr)(count * sizeof(long))); break;
                }
            }
        }

        /// <summary>
        /// The MemCpy of ulong arrays.
        /// </summary>
        public static void MemCpy(ulong[] source, uint source_offset, ulong[] target, uint target_offset, uint count)
        {
//#if UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE
            if (count < MINIMUM_SIZE / sizeof(ulong))
            {
                Array.Copy(source, (int)source_offset, target, (int)target_offset, (int)count);
                return;
            }
//#endif //UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE

            MemCpyFunc func = get_MemCpyFunc(source, source_offset, target, target_offset, count);
            if( func == MemCpyFunc.None )
                return;

            if (func == MemCpyFunc.ArrayCopy)
            {
                Array.Copy(source, (int)source_offset, target, (int)target_offset, (int)count);
                return;
            }

            fixed (ulong* pSrc = source, pDst = target)
            {
                ulong* ps = pSrc; ps += source_offset; ulong* pd = pDst; pd += target_offset;
                switch (func)
                {
                    case MemCpyFunc.KernelCopy: CopyMemory((IntPtr)pd, (IntPtr)ps, (IntPtr)(count * sizeof(ulong))); break;
                    case MemCpyFunc.KernelMove: MoveMemory((IntPtr)pd, (IntPtr)ps, (IntPtr)(count * sizeof(ulong))); break;
                }
            }
        }

        /// <summary>
        /// The MemCpy of float arrays.
        /// </summary>
        public static void MemCpy(float[] source, uint source_offset, float[] target, uint target_offset, uint count)
        {
//#if UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE
            if (count < MINIMUM_SIZE / sizeof(float))
            {
                Array.Copy(source, (int)source_offset, target, (int)target_offset, (int)count);
                return;
            }
//#endif //UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE

            MemCpyFunc func = get_MemCpyFunc(source, source_offset, target, target_offset, count);
            if( func == MemCpyFunc.None )
                return;

            if (func == MemCpyFunc.ArrayCopy)
            {
                Array.Copy(source, (int)source_offset, target, (int)target_offset, (int)count);
                return;
            }

            fixed (float* pSrc = source, pDst = target)
            {
                float* ps = pSrc; ps += source_offset; float* pd = pDst; pd += target_offset;
                switch (func)
                {
                    case MemCpyFunc.KernelCopy: CopyMemory((IntPtr)pd, (IntPtr)ps, (IntPtr)(count * sizeof(float))); break;
                    case MemCpyFunc.KernelMove: MoveMemory((IntPtr)pd, (IntPtr)ps, (IntPtr)(count * sizeof(float))); break;
                }
            }
        }

        /// <summary>
        /// The MemCpy of double arrays.
        /// </summary>
        public static void MemCpy(double[] source, uint source_offset, double[] target, uint target_offset, uint count)
        {
//#if UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE
            if (count < MINIMUM_SIZE / sizeof(double))
            {
                Array.Copy(source, (int)source_offset, target, (int)target_offset, (int)count);
                return;
            }
//#endif //UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE

            MemCpyFunc func = get_MemCpyFunc(source, source_offset, target, target_offset, count);
            if( func == MemCpyFunc.None )
                return;

            if (func == MemCpyFunc.ArrayCopy)
            {
                Array.Copy(source, (int)source_offset, target, (int)target_offset, (int)count);
                return;
            }

            fixed (double* pSrc = source, pDst = target)
            {
                double* ps = pSrc; ps += source_offset; double* pd = pDst; pd += target_offset;
                switch (func)
                {
                    case MemCpyFunc.KernelCopy: CopyMemory((IntPtr)pd, (IntPtr)ps, (IntPtr)(count * sizeof(double))); break;
                    case MemCpyFunc.KernelMove: MoveMemory((IntPtr)pd, (IntPtr)ps, (IntPtr)(count * sizeof(double))); break;
                }
            }
        }

        /// <summary>
        /// The MemCpy of char arrays.
        /// </summary>
        public static void MemCpy(char[] source, uint source_offset, char[] target, uint target_offset, uint count)
        {
//#if UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE
            if (count < MINIMUM_SIZE / sizeof(byte))
            {
                Array.Copy(source, (int)source_offset, target, (int)target_offset, (int)count);
                return;
            }
//#endif //UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE

            MemCpyFunc func = get_MemCpyFunc(source, source_offset, target, target_offset, count);
            if( func == MemCpyFunc.None )
                return;

            if (func == MemCpyFunc.ArrayCopy)
            {
                Array.Copy(source, (int)source_offset, target, (int)target_offset, (int)count);
                return;
            }

            fixed (char* pSrc = source, pDst = target)
            {
                char* ps = pSrc; ps += source_offset; char* pd = pDst; pd += target_offset;
                switch (func)
                {
                    case MemCpyFunc.KernelCopy: CopyMemory((IntPtr)pd, (IntPtr)ps, (IntPtr)(count * sizeof(char))); break;
                    case MemCpyFunc.KernelMove: MoveMemory((IntPtr)pd, (IntPtr)ps, (IntPtr)(count * sizeof(char))); break;
                }
            }
        }

        /// <summary>
        /// The TestMemCpy tests the MemCpy methods.
        /// </summary>
        public static void TestMemCpy(uint size)
        {
            long[]  source = new long[size],
                    target = new long[size];

            uint count = size;

            for (uint idx = 0; idx < count; idx++)
            {
                source[idx] = (long)idx;
                target[idx] = (long)(idx + 50);
            }

            MemCpy(source, 0, target, 0, count);

            for (uint idx = 0; idx < count; idx++)
            {
                Debug.Assert(source[idx] == target[idx]);
            }
        }

        /// <summary>
        /// The CompareMemCpyPerformance compares the performance of System.Buffer.BlockCopy and Ericommon.Unsafe.MemCpy methods.
        /// </summary>
        public static void CompareMemCpyPerformance(uint size, uint times)
        {
            int non_zero_offset = 64;
            size += (uint)non_zero_offset;

            byte[] source = new byte[size],
                   target = new byte[size];

            for (uint idx = 0; idx < size; idx++)
            {
                source[idx] = (byte)idx;
                target[idx] = (byte)(idx + 50);
            }

            Logger.Root.Info(String.Format("CompareMemCpyPerformance: size={0}, times={1}", size * sizeof(byte), times));

            size -= (uint)non_zero_offset;

            compare_MemCpyPerformance(source, non_zero_offset,  source, non_zero_offset, size, times);
            compare_MemCpyPerformance(source, 0,                source, non_zero_offset, size, times);
            compare_MemCpyPerformance(source, non_zero_offset,  source, 0,               size, times);
            compare_MemCpyPerformance(source, non_zero_offset,  target, 0,               size, times);
        }

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern void MoveMemory(IntPtr Destination, IntPtr Source, IntPtr Length);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern void CopyMemory(IntPtr Destination, IntPtr Source, IntPtr Length);

        enum MemCpyFunc { None, KernelCopy, KernelMove, ArrayCopy };

        private static MemCpyFunc get_MemCpyFunc<T>(T[] source, uint source_offset, T[] target, uint target_offset, uint count)
        {
            if (count == 0)
                return MemCpyFunc.None;

            if (source == target)
            {
                if( source_offset == target_offset)
                    return MemCpyFunc.None;

                return (source_offset < target_offset) ? MemCpyFunc.ArrayCopy : MemCpyFunc.KernelMove;
            }

            if (source == null)
                throw new AccessViolationException("The source is null");

            if (target == null)
                throw new AccessViolationException("The target is null");

            uint source_length = (uint)source.Length,
                 target_length = (uint)target.Length;

            if (source_length < source_offset + count)
                throw new AccessViolationException(String.Format("The source length ({0}) is less than the source offset ({1}) + count ({2})", source_length, source_offset, count));

            if (target_length < target_offset + count)
                throw new AccessViolationException(String.Format("The target length ({0}) is less than the target offset ({1}) + count ({2})", target_length, target_offset, count));

            return MemCpyFunc.KernelCopy;
        }

        private static void compare_MemCpyPerformance(byte[] source, int source_offset,
                                                      byte[] target, int target_offset,
                                                      uint size,     uint times)
        {
            int copy_length = (int)((int)size - ((source_offset > target_offset) ? source_offset : target_offset));

            if (source == target)
            {
                if (source_offset == target_offset)
                    Logger.Root.Info("CompareMemCpyPerformance: SAME BUFFERS AND OFFSETS");
                else if (source_offset < target_offset)
                    Logger.Root.Info("CompareMemCpyPerformance: SAME BUFFERS, NON OVERLAPPED");
                else //if( source_offset > target_offset )
                    Logger.Root.Info("CompareMemCpyPerformance: SAME BUFFERS, OVERLAPPED");
            }
            else
            {
                Logger.Root.Info("CompareMemCpyPerformance: DIFFERENT BUFFERS");
            }

            DateTime start_ArrayCopy = DateTime.Now;
            for (uint count = 0; count < times; count++)
                Array.Copy(source, source_offset, target, target_offset, copy_length);
            TimeSpan span_ArrayCopy = DateTime.Now - start_ArrayCopy;

            Logger.Root.Info("CompareMemCpyPerformance: ArrayCopy: ", span_ArrayCopy);

            DateTime start_BlockCopy = DateTime.Now;
            for (uint count = 0; count < times; count++)
                System.Buffer.BlockCopy(source, source_offset, target, target_offset, (int)copy_length * sizeof(byte));
            TimeSpan span_BlockCopy = DateTime.Now - start_BlockCopy;

            Logger.Root.Info("CompareMemCpyPerformance: BlockCopy: ", span_BlockCopy);

            DateTime start_MemCpy = DateTime.Now;
            for (uint count = 0; count < times; count++)
                MemCpy(source, (uint)source_offset, target, (uint)target_offset, (uint)copy_length);
            TimeSpan span_MemCpy = DateTime.Now - start_MemCpy;

            Logger.Root.Info("CompareMemCpyPerformance: MemCpy   : ", span_MemCpy);
        }

//#if UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE
        const uint MINIMUM_SIZE = 1024;
//#endif //UNSAFE_ARRAY_COPY_USES_MINIMUM_SIZE
        #endregion MemCpy
    }
}
