﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using TracerX;

namespace EriCommon
{
    /// <summary>
    /// The TimersThread class creates and manages a dispatch thread for timers.
    /// </summary>
    public class TimersThread : IDisposable
    {
        /// <summary>
        /// The TimersThread ctor.
        /// </summary>
        public TimersThread(string name, bool safe)
        {
            m_processing_thread = new ProcessingQueueThread(name, safe);
        }

        /// <summary>
        /// Returns the name.
        /// </summary>
        public string Name
        {
            get { return m_processing_thread.Name; }
        }

        /// <summary>
        /// Returns the default instance. If is not yet created, creates it too.
        /// </summary>
        public static TimersThread Default
        {
            get
            {
                lock(sm_logger)
                {
                    if (sm_default == null)
                    {
                        sm_default = new TimersThread("Default Timers Thread", false);
                        sm_logger.Debug(string.Format("The \"{0}\" has been created", sm_default.Name));
                    }

                    return sm_default;
                }
            }
        }

        /// <summary>
        /// Stops the default timers thread
        /// </summary>
        public static void StopDefault()
        {
            lock (sm_logger)
            {
                if (sm_default != null)
                {
                    sm_default.Stop();
                    sm_default = null;
                }
            }
        }

        /// <summary>
        /// Stops the processing queue thread
        /// </summary>
        public void Stop()
        {
            if (m_processing_thread != null)
            {
                m_processing_thread.Stop();
            }
        }

        /// <summary>
        /// Defines what to do when the timer callback is processing.
        /// </summary>
        public enum BusyMode
        {
            /// <summary>
            /// Queues the timer event.
            /// </summary>
            QUEUE,
            /// <summary>
            /// Skips the timer event.
            /// </summary>
            SKIP,
            /// <summary>
            /// Logs a warning and queues the timer event.
            /// </summary>
            LOG_AND_QUEUE,
            /// <summary>
            /// Logs a warning and skips the timer event.
            /// </summary>
            LOG_AND_SKIP,
        }

        /// <summary>
        /// Adds a new timer.
        /// </summary>
        public Timer AddTimer(string name, TimerCallback callback, Object state, Int64 dueTime, Int64 period, BusyMode busy_mode)
        {
            if( m_processing_thread.Disposed)
                return null;

            TimerCtx ctx = new TimerCtx(this, name, callback, state, busy_mode, period);
            ctx.Timer = new Timer(timer_callback, ctx, dueTime, period);
            return ctx.Timer;
        }

//         /// <summary>
//         /// Adds a new timer.
//         /// </summary>
//         public Timer AddTimer(string name, TimerCallback callback, Object state, Int64 dueTime, Int64 period, BusyMode busy_mode)
//         {
//             if( m_processing_thread.Disposed)
//                 return null;
//
//             TimerCtx ctx = new TimerCtx(this, name, callback, state, busy_mode, period);
//             ctx.Timer = new Timer(timer_callback, ctx, dueTime, period);
//             return ctx.Timer;
//         }

//         /// <summary>
//         /// Adds a new timer.
//         /// </summary>
//         public Timer AddTimer(string name, TimerCallback callback, Object state, Int64 dueTime, Int64 period, BusyMode busy_mode)
//         {
//             if( m_processing_thread.Disposed)
//                 return null;
//
//             TimerCtx ctx = new TimerCtx(this, name, callback, state, busy_mode, period);
//             ctx.Timer = new Timer(timer_callback, ctx, dueTime, period);
//             return ctx.Timer;
//         }

        /// <summary>
        /// Adds a new timer.
        /// </summary>
        public Timer AddTimer(string name, TimerCallback callback, Object state, TimeSpan dueTime, TimeSpan period, BusyMode busy_mode)
        {
            if( m_processing_thread.Disposed)
                return null;

            TimerCtx ctx = new TimerCtx(this, name, callback, state, busy_mode, (Int64)period.TotalMilliseconds);
            ctx.Timer = new Timer(timer_callback, ctx, dueTime, period);
            return ctx.Timer;
        }

        /// <summary>
        /// Disposes the instance.
        /// </summary>
        public void Dispose()
        {
            m_processing_thread.Dispose();
        }

        private class TimerCtx : ProcessingItem
        {
            public TimerCtx(TimersThread owner, string name, TimerCallback callback, Object state, BusyMode busy_mode, Int64 period)
            {
                m_name = name;
                m_owner = owner;
                m_callback = callback;
                m_state = state;
                m_busy_mode = busy_mode;
                m_period = period;
            }

            public override void Proceed()
            {
                lock (this)
                {
                    m_busy_processing_started = DateTime.Now;
                    m_processed_count++;

                    try
                    {
                        m_callback(m_state);
                    }
                    catch (System.Exception ex)
                    {
                        SafeCall.ExceptionHandler(ex, string.Format("Under a callback to \"{0}/{1}\" timer", m_owner.Name, Name));
                    }
                    finally
                    {
                        m_busy_count--;
                        Debug.Assert(m_busy_count >= 0);
                        m_busy_processing_done = DateTime.Now;
                        TimeSpan elapsed = m_busy_processing_done - m_busy_processing_started;
                        if (m_max_elapsed < elapsed)
                            m_max_elapsed = elapsed;

                        m_total_elapsed += elapsed;
                    }
                }
            }

            public string Name
            {
                get { return m_name; }
            }

            public Timer Timer
            {
                get { return m_timer; }
                set { m_timer = value; }
            }

            public override void Dispose()
            {
                m_timer.Change(0, 0);
                m_timer.Dispose();
            }

            readonly string m_name;
            readonly TimersThread m_owner;
            readonly TimerCallback m_callback;
            readonly Object m_state;
            Timer m_timer = null;

            public readonly BusyMode m_busy_mode;
            public readonly Int64 m_period;
            public UInt32 m_processed_count = 0;
            public UInt32 m_busy_count = 0;
            public UInt32 m_busy_events = 0;
            public DateTime m_busy_last_added,
                            m_busy_processing_started,
                            m_busy_processing_done;
            public TimeSpan m_max_elapsed,
                            m_total_elapsed;
        }

        private void timer_callback(Object state)
        {
            TimerCtx ctx = (TimerCtx)state;

            lock (ctx)
            {
                if (m_processing_thread.Disposed)
                {
                    ctx.Dispose();
                    return;
                }

                Debug.Assert(ctx.m_busy_count >= 0);

                if(ctx.m_busy_count > 0)
                {
                    switch (ctx.m_busy_mode)
                    {
                        case BusyMode.SKIP:
                            ctx.m_busy_events++;
                            return;

                        case BusyMode.LOG_AND_SKIP:
                            ctx.m_busy_events++;
#if !DEBUG
                            if (ctx.m_busy_count == 1)  // only first time
#endif
                            log_busy( ctx );

                            return;

                        case BusyMode.LOG_AND_QUEUE:
                            ctx.m_busy_events++;
#if !DEBUG
                            if (ctx.m_busy_count == 1)  // only first time
#endif
                            log_busy( ctx );

                            break;
                    }
                }

                ctx.m_busy_count++;
                ctx.m_busy_last_added = DateTime.Now;

                m_processing_thread.AddItem(ctx);
            }
        }

        private static void log_busy( TimerCtx ctx )
        {
            string text = string.Format("Timer handler \"{0}\" is busy! Event {1}queued\n" +
                                        "Pending count: {2}\n" +
                                        "Occurs. count: {3}\n" +
                                        "Last added   : {4}\n" +
                                        "Last started : {5}\n" +
                                        "Last done    : {6}\n" +
                                        "Processed cnt: {7}\n" +
                                        "Max. elapsed : {8}\n" +
                                        "Avg. pr. time: {9} seconds\n" +
                                        "Interval     : {10} seconds\n" +
                                        "Machine CPU  : {11}%",
                                        ctx.Name,
                                        ctx.m_busy_mode == BusyMode.LOG_AND_SKIP ? "not " : "",
                                        ctx.m_busy_count,
                                        ctx.m_busy_events,
                                        ctx.m_busy_last_added,
                                        ctx.m_busy_processing_started,
                                        ctx.m_busy_processing_done,
                                        ctx.m_processed_count,
                                        ctx.m_max_elapsed,
                                        ctx.m_total_elapsed.TotalSeconds / ctx.m_processed_count,
                                        (double)ctx.m_period / 1000.0,
                                        SystemInformation.GetCurrentCpuUsage());

            sm_logger.Warn(text);
        }

        ProcessingQueueThread m_processing_thread;

        private static Logger sm_logger = Logger.GetLogger(ReflectionHelper.GetClassName());
        private static TimersThread sm_default = null;
    }
}
