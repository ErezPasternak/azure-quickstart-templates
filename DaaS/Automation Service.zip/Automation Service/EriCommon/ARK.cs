﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace EriCommon
{
    /// <summary>
    /// The ARK class (Application Recognition Key) is designated to be used by distributed applications
    /// in order to recognize each other.
    /// </summary>
    public class ARK
    {
        #region Public

        /// <summary>
        /// The ARK ctor used to generate the key.
        /// </summary>
        public ARK()
        {
            Random generator = new Random();
            uint version = VERSION,
                 before = (uint)generator.Next((int)Sizes.MIN_BEFORE, (int)Sizes.MAX_LENGTH),
                 length = (uint)generator.Next((int)Sizes.MIN_LENGTH, (int)Sizes.MAX_LENGTH),
                 after = (uint)generator.Next((int)Sizes.MIN_AFTER, (int)Sizes.MAX_LENGTH);

            System.IO.MemoryStream stream = new System.IO.MemoryStream();

            byte[] before_buffer = new byte[before];
            generator.NextBytes(before_buffer);
            write(stream, before_buffer);

            byte[] data_a = new byte[length];
            generator.NextBytes(data_a);
            write(stream, data_a);

            byte[] data_b = new byte[length];
            generator.NextBytes(data_b);
            write(stream, data_b);

            byte[] data_c = new byte[length];
            for (uint idx = 0; idx < length; idx++)
                data_c[idx] = (byte)(data_a[idx] ^ data_b[idx]);
            write(stream, data_c);

            byte[] after_buffer = new byte[after];
            generator.NextBytes(after_buffer);
            write(stream, after_buffer);

            uint data_hash_code = get_hash_code(stream);

            long header_offset = stream.Length;
            version ^= data_hash_code;      write(stream, BitConverter.GetBytes(version));
            before  ^= data_hash_code;      write(stream, BitConverter.GetBytes(before));
            length  ^= data_hash_code;      write(stream, BitConverter.GetBytes(length));
            after   ^= data_hash_code;      write(stream, BitConverter.GetBytes(after));
            long header_end = stream.Length;
            Debug.Assert(header_end - header_offset == (sizeof(uint) * 4));

            m_buffer = new byte[stream.Length];
            stream.Position = 0;
            read(stream, m_buffer);
            m_text = StringHelper.BytesToHexString(m_buffer);
        }

        /// <summary>
        /// The ARK ctor used to validate the key.
        /// </summary>
        public ARK(string text)
        {
            m_text = text;
            m_buffer = StringHelper.HexStringToBytes(m_text);
            int header_length = (sizeof(uint)*4),
                header_offset = m_buffer.Length - header_length;

            System.IO.MemoryStream data_stream = new System.IO.MemoryStream(m_buffer, 0, header_offset);
            data_stream.Position = 0;

            uint data_hash_code = get_hash_code(data_stream);

            System.IO.MemoryStream header_stream = new System.IO.MemoryStream(m_buffer, header_offset, header_length);
            byte[] int_buffer = new byte[sizeof(int)];

            uint version, before, length, after;

            read(header_stream, int_buffer, out version, data_hash_code);
            if (version != VERSION)
                throw new ArgumentOutOfRangeException("ARK", version, "version must be 1.");

            read(header_stream, int_buffer, out before, data_hash_code);
            if (before < (uint)Sizes.MIN_BEFORE || before > (uint)Sizes.MAX_LENGTH)
                throw new ArgumentOutOfRangeException("ARK", before, String.Format("B must be in range {0} to {1}.", Sizes.MIN_BEFORE, Sizes.MAX_LENGTH));

            read(header_stream, int_buffer, out length, data_hash_code);
            if (length < (uint)Sizes.MIN_LENGTH || length > (uint)Sizes.MAX_LENGTH)
                throw new ArgumentOutOfRangeException("ARK", length, String.Format("L must be in range {0} to {1}.", Sizes.MIN_LENGTH, Sizes.MAX_LENGTH));

            read(header_stream, int_buffer, out after, data_hash_code);
            if (after < (uint)Sizes.MIN_AFTER || after > (uint)Sizes.MAX_LENGTH)
                throw new ArgumentOutOfRangeException("ARK", after, String.Format("L must be in range {0} to {1}.", Sizes.MIN_AFTER, Sizes.MAX_LENGTH));

            uint total_data_length = before + (3*length) + after;
            if (total_data_length != header_offset)
                throw new ArgumentOutOfRangeException("ARK", total_data_length, String.Format("T must be in range {0} to {1}.", 0, header_offset));

            byte[] before_buffer = new byte[before];
            read(data_stream, before_buffer);

            byte[] data_a = new byte[length];
            read(data_stream, data_a);

            byte[] data_b = new byte[length];
            read(data_stream, data_b);

            byte[] data_c = new byte[length];
            read(data_stream, data_c);
            for (uint idx = 0; idx < length; idx++)
            {
                if (data_c[idx] != (byte)(data_a[idx] ^ data_b[idx]))
                    throw new ArgumentOutOfRangeException("ARK", data_c[idx], String.Format("D must be in range {0} to {1}.", data_a[idx], data_b[idx]));
            }
        }

        /// <summary>
        /// Validates an ARK key text.
        /// </summary>
        public static bool IsValid(string text)
        {
            try
            {
                new ARK(text);
            }
            catch (System.Exception )
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Gets the key text.
        /// </summary>
        public string Text
        {
            get { return m_text; }
        }

        /// <summary>
        /// Gets the key binary.
        /// </summary>
        public byte[] Bytes
        {
            get { return m_buffer; }
        }

        #endregion

        #region Private

        private static void write(System.IO.MemoryStream stream, byte[] buffer)
        {
            stream.Write(buffer, 0, buffer.Length);
        }

        private static void read(System.IO.MemoryStream stream, byte[] buffer)
        {
            int bytes_read = stream.Read(buffer, 0, buffer.Length);
            if( bytes_read != buffer.Length )
               throw new ArgumentOutOfRangeException("ARK", bytes_read, "bytes_read...");
        }

        private static void read(System.IO.MemoryStream stream, byte[] buffer, out uint val)
        {
            stream.Read(buffer, 0, buffer.Length);
            val = BitConverter.ToUInt32(buffer, 0);
        }

        private static void read(System.IO.MemoryStream stream, byte[] buffer, out uint val, uint data_hash_code)
        {
            read(stream, buffer, out val);
            val ^= data_hash_code;
        }

        private static uint get_hash_code(System.IO.MemoryStream stream)
        {
            byte[] buffer = new byte[stream.Length];
            Int64 position = stream.Position;
            stream.Position = 0;
            read(stream, buffer);
            stream.Position = position;
            uint hash_code = 0xF1E2D3C5;

            for (int idx = 0, max_idx = buffer.Length; idx < max_idx; idx++)
                hash_code ^= ((uint)buffer[idx]) << (8 * (idx % 4));

            return hash_code;
        }

        private byte[] m_buffer;
        private string m_text;

        private enum Sizes
        {
            MIN_BEFORE = 1,
            MIN_LENGTH = 8,
            MIN_AFTER = 1,
            MAX_LENGTH = 64
        };

        const uint VERSION = 1;

        #endregion
    }
}
