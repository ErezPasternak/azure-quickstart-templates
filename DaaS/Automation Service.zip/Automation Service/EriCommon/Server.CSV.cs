﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;
using System.Runtime.Serialization;

using TracerX;

namespace EriCommon
{
    /// <summary>
    /// The Server class
    /// </summary>
    public partial class Server
    {
        private void create_CSV()
        {
            Debug.Assert(m_csv == null);
            string fullpath_filename = FileHelper.RenameFile(" " + Name, "CSV");

            m_csv = new CSV(
                    fullpath_filename,
                // ------------------- COLUMNS ----------------------
                    new CSV.DateTimeColumn("Date & Time"),
                    new CSV.StringColumn("Tenant"),
                    new CSV.StringColumn("RID"),
                    new CSV.StringColumn("Service"),
                    new CSV.StringColumn("Status"),
                    new CSV.StringColumn("Msg"),
                    new CSV.UnsignedColumn("Iteration"),
                    new CSV.RealColumn("Elapsed Seconds", new CSV.RealExtractor(true,3)),
                    new CSV.StringColumn("Request Details"),
                    new CSV.StringColumn("Response Details")
                    );
        }

        static private String single_line_details(String details)
        {
            details = details.Trim().Replace("\n", ", ");
            return details.GetSingleSpaced();
        }

        private void report_CSV(Service service, Request request, Response response, double elapsed_seconds)
        {
            if (m_csv != null)
            {
                Debug.Assert(request != null);
                Debug.Assert(response != null);

                m_csv.AddLine(
                        null,                                                                                                   //Date & Time
                        (request.TenantID != null && request.TenantID != Request.DEFAULT_TENANT_NAME) ? request.TenantID : "",  //Tenant
                        request.RID,                                                                                            //RID
                        service.Name,                                                                                           //Service
                        /*(response == null) ? "CALL FAILED" :*/ response.STATUS.ToString(),                                        //Status
                        /*(response == null) ? request.CallError :*/ (response.Message == null) ? "" : response.Message.Text,       //Msg
                        request.GetIterationCounter(),                                                                          //Iteration
                        elapsed_seconds,                                                                                        //Elapsed
                        single_line_details(request.GetCsvDetails(service)),                                                  //Request Details
                        (response == null) ? "" : single_line_details(response.GetCsvDetails(service))                        //Response Details
                        );
            }
        }
    }
}
