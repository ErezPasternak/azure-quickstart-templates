﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections;
using System.Diagnostics;

namespace EriCommon
{
    /// <summary>
    /// The DirectoryCache class
    /// </summary>
    public class DirectoryCache
    {
        private class FileInfo
        {
            public byte[] m_file;
            public DateTime m_last_write_time_utc;
        }

        private Hashtable m_table;
        private readonly String	m_path;
        private Int64 m_size;

        /// <summary>
        /// The c-tor
        /// </summary>
        public DirectoryCache(String path)
        {
            if (Directory.Exists(path) == false)
                throw new ArgumentException("Path doesn't exist.");

            m_size = 0;
            m_path  = path;
            m_table = new Hashtable(StringComparer.OrdinalIgnoreCase);	// Will return null (and not throw an exception) if key not exist

            BuildCache();
        }

        private String this[String key]
        {
            get { return (String)m_table[key]; }
            //set { m_table[key] = value; }
        }

        /// <summary>
        /// Loads the files in the folder
        /// </summary>
        public void BuildCache()
        {
            Debug.Assert(String.IsNullOrWhiteSpace(m_path) == false);

            lock (this)
            {
                m_table.Clear();
                m_size = 0;

                string[] directories = Directory.GetDirectories(m_path, "*", SearchOption.AllDirectories);
                foreach (string dir in directories)
                    m_table[dir] = null;

                string[] files = Directory.GetFiles(m_path, "*", SearchOption.AllDirectories);
                foreach (string file in files)
                {
                    DirectoryCache.FileInfo fi = new DirectoryCache.FileInfo();

                    using (FileStream fs = File.Open(file, FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        m_size += fs.Length;
                        fi.m_file = new byte[fs.Length];
                        fs.Read(fi.m_file, 0, fi.m_file.Length);
                    }

                    System.IO.FileInfo sifi = new System.IO.FileInfo(file);
                    fi.m_last_write_time_utc = sifi.LastWriteTimeUtc;

                    m_table[file] = fi;
                }
            }
        }

        /// <summary>
        /// returns true if the specified file is in the cash
        /// </summary>
        public bool FileExists(String file)
        {
            return m_table.ContainsKey(file);
        }
    }
}
