﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace EriCommon
{
    /// <summary>
    /// The ThreadHelper static class contains static functions dealing with threads.
    /// </summary>
    public static class ThreadHelper
    {
        #region Public
        /// <summary>
        /// Sets the current thread's name to "Main Thread".
        /// This method should be called once, in the Main Thread.
        /// Actually it is called from SafeCall.ServiceProgramMain() method
        /// </summary>
        public static void SetMainThreadName()
        {
            set_name(Thread.CurrentThread, "Main Thread");
        }

        /// <summary>
        /// Defines the thread working mode
        /// </summary>
        public enum Mode
        {
            /// <summary>
            /// A background thread terminates when the program main exits
            /// </summary>
            Background,
            /// <summary>
            /// If there are running foreground threads, the program continues running even if the program main has been exited
            /// </summary>
            Foreground
        };

        /// <summary>
        /// Creates a named thread and starts it
        /// </summary>
        public static Thread Create(string name, ParameterizedThreadStart start, Object param, bool safe, Mode mode)
        {
            return create(name, start, 0, param, safe, mode);
        }

        /// <summary>
        /// Creates a named thread and starts it
        /// </summary>
        public static Thread Create(string name, ThreadStart start, bool safe, Mode mode)
        {
            return create(name, start, 0, null, safe, mode);
        }

        #endregion

        #region Private
        /// <summary>
        /// Creates a named thread and starts it
        /// </summary>
        private class StartParam
        {
            public ParameterizedThreadStart m_ParameterizedThreadStart;
            public Object m_param;
            public ThreadStart m_ThreadStart;

            public StartParam(ParameterizedThreadStart start, Object param)
            {
                m_ParameterizedThreadStart = start;
                m_param = param;
            }

            public StartParam(ThreadStart start)
            {
                m_ThreadStart = start;
            }

        }

        private static void thread_start_safe(Object obj)
        {
            SafeCall.Run(thread_main, obj);
        }

        private static void thread_start(Object obj)
        {
            thread_main(obj);
        }

        private static void thread_main(Object obj)
        {
            StartParam sp = (StartParam)obj;

            if (sp.m_ParameterizedThreadStart != null)
                sp.m_ParameterizedThreadStart(sp.m_param);
            else
                sp.m_ThreadStart();
        }

        private static Thread create(string name, Object start_delegate, int max_stack_size, Object param, bool safe, Mode mode)
        {
            StartParam sp;

            if (start_delegate is ParameterizedThreadStart)
            {
                sp = new StartParam((ParameterizedThreadStart)start_delegate, param);
            }
            else
            {
                sp = new StartParam((ThreadStart)start_delegate);
            }

        Thread t = safe ? new Thread(thread_start_safe, max_stack_size) :
                        new Thread(thread_start,      max_stack_size);

            if (mode == Mode.Background)
            {
                t.IsBackground = true;
            }

            set_name( t, name );

            t.Start(sp);

            return t;
        }

        private static void set_name(Thread t, string name)
        {
            Debug.Assert(name != null && name != "");
            Debug.Assert(t.Name == null);
            t.Name = name;
        }

        #endregion
    }
}
