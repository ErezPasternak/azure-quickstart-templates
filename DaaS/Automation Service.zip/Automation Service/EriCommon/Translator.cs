﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Globalization;

using TracerX;

namespace EriCommon
{
    /// <summary>
    /// The Translator static class
    /// </summary>
    public static class Translator
    {
        /// <summary>
        /// The IDict interface, representing one language
        /// </summary>
        public interface IDict
        {
            /// <summary>
            /// The language ID
            /// </summary>
            String LanguageId
            {
                get;
            }

            /// <summary>
            /// Translates the ID + parameters to a user-friendly text
            /// </summary>
            String Get(String format_id, params Object[] parameters);
            /// <summary>
            /// Translates the ID + parameters to a user-friendly text
            /// </summary>
            String TryGet(String format_id, String default_text, params Object[] parameters);
        }

        const String __Missing__ = "__Missing__.";

        /// <summary>
        /// The Dict class, implementing IDict
        /// </summary>
        class Dict : IDict
        {
            /// <summary>
            /// The c-tor
            /// </summary>
            public Dict(String language_id)
            {
                LanguageId = language_id;
                _missing_dictionary_name = _languages_folder + @"\" + __Missing__ + LanguageId + ".txt";
            }

            /// <summary>
            /// Compares the keys of two dictionaries
            /// </summary>
            public void Compare(Dict other)
            {
                foreach (String key in _dictionary.Keys)
                {
                    if (other._dictionary.ContainsKey(key) == false)
                        _logger.WarnFormat("Key '{0}' is missing in '{1}' dictionary.", key, other.LanguageId);
                }
            }

            static readonly char[] ID_SEPARATORS = new char[] { '\x20', '\t' };

            public void LoadMissing()
            {
                if (File.Exists(_missing_dictionary_name))
                {
                    int before_count = _dictionary.Count;
                    Load(_missing_dictionary_name, false);
                    int after_count = _dictionary.Count;

                    if (after_count > before_count)
                    {
                        _logger.WarnFormat("{0} missing formats loaded into {1} dictionary.", after_count - before_count, LanguageId);
                    }
                    else
                    {
                        File.Delete(_missing_dictionary_name);
                    }
                }
            }

            /// <summary>
            /// Loads the file
            /// </summary>
            public void Load(String filename, bool under_reload)
            {
                String temp_missing_dictionary_name = "";

                StreamWriter sw = null;

                if (filename == _missing_dictionary_name)
                {
                    temp_missing_dictionary_name = _missing_dictionary_name + ".TMP";

                    if (File.Exists(temp_missing_dictionary_name))
                        File.Delete(temp_missing_dictionary_name);

                    sw = new StreamWriter(temp_missing_dictionary_name);
                }

                String file = Path.GetFileName(filename);

                if (under_reload)
                    _logger.InfoFormat("Reloading dictionary file '{0}'...", file);
                else
                    _logger.InfoFormat("Loading dictionary file '{0}'...", file);

                uint changes = 0;
                int before_count = _dictionary.Count;

                using (StreamReader sr = new StreamReader(filename))
                {
                    UInt32 line_num = 0;
                    while (sr.EndOfStream == false)
                    {
                        line_num++;
                        String line = sr.ReadLine();
                        line = line.Trim();

                        if(line.Length == 0)
                            continue;

                        int idx = line.IndexOfAny(ID_SEPARATORS);

                        if(idx <= 0)
                            continue;

                        String key = line.Substring(0, idx);
                        line = line.Substring(idx+1);
                        line = line.Trim();

                        if (line.Length == 0)
                            continue;

                        String found;

                        if (_dictionary.TryGetValue(key, out found))
                        {
                            if (found == line)
                            {
                                if (under_reload == false && sw == null)
                                    _logger.WarnFormat("Duplicate key '{0}'.\n" +
                                                      " Value   : {1}\n" +
                                                      " Location: {2}({3})",
                                                      key,
                                                      found,
                                                      file, line_num);

                                continue;
                            }
                            else
                            {
                                if (under_reload)
                                {
                                    changes++;

                                    _dictionary.Remove(key);
                                }
                                else
                                {
                                    if (sw == null)
                                        _logger.WarnFormat("Key '{0}' already exists.\n" +
                                                           " Current Value: {1}\n" +
                                                           "    This Value: {2}\n" +
                                                           "      Location: {3}({4})",
                                                           key,
                                                           found,
                                                           line,
                                                           file, line_num);

                                    continue;
                                }
                            }
                        }

                        if (sw != null)
                        {
                            write_line(sw, key, line);
                        }

                        _dictionary.Add(key, line);
                    }
                }

                if (sw == null)
                {
                    if (under_reload)
                        _logger.InfoFormat("'{0}' dictionary file was reloaded. {1} changes found.", file, changes);
                    else
                        _logger.InfoFormat("'{0}' dictionary file was loaded. {1} formats found.", file, _dictionary.Count - before_count);

                    if (under_reload == false && _refreshDictionaryWhenChanged.Value)
                        _file_watcher = new FileWatcher(filename, on_changed, 10, _logger);//this, filename);
                }
                else
                {
                    sw.Flush();
                    sw.Close();

                    File.Delete(filename);
                    File.Move(temp_missing_dictionary_name, filename);
                }
            }

            private void write_line(StreamWriter sw, String key, String line)
            {
                sw.WriteLine(String.Format("{0,-50}       {1}", key, line));
            }

            private static void on_changed(FileSystemEventArgs e)
            {
                load(_dictionaries, e.FullPath, true);
            }

            /// <summary>
            /// The language ID
            /// </summary>
            public String LanguageId
            {
                get;
                private set;
            }

            /// <summary>
            /// Returns the translated string.
            /// </summary>
            public String Get(String format_id, params Object[] parameters)
            {
                return TryGet(format_id, format_id, parameters);
            }

            /// <summary>
            /// Returns the translated string.
            /// </summary>
            public String TryGet(String format_id, String text, params Object[] parameters)
            {
                String value;

                if (_dictionary.TryGetValue(format_id, out value) == false)
                {
                    if (_defaultDictionary == null   ||
                        _defaultDictionary == this   ||
                        _defaultDictionary._dictionary.TryGetValue(format_id, out value) == false)
                    {
                        lock (_missings_dictionary)
                        {
                            _missings_dictionary.TryGetValue(format_id, out value);
                        }

                        if(value == null)
                        {
                            value = text;

                            if (parameters != null)
                            {
                                String parameters_list = "";
                                int idx = 0;

                                foreach (Object param in parameters)
                                {
                                    if (parameters_list != "")
                                        parameters_list += ", ";

                                    parameters_list += String.Format("p{0}={{{1}}}", idx, idx);
                                    idx++;
                                }

                                if(idx > 0)
                                    value = String.Format("{0} ({1})", value, parameters_list);
                            }

                            store_missing_format(format_id, value);
                        }
                    }
                }

                try
                {
                    return String.Format(value, parameters);
                }
                catch (System.Exception /*ex*/)
                {
                    bool call_safecall = false;

                    lock (_throwing_exception)
                    {
                        if (_throwing_exception.Contains(value) == false)
                        {
                            _throwing_exception.Add(value);
                            call_safecall = true;
                        }
                    }

                    if (call_safecall)
                        _logger.ErrorFormat("Failed to translate '{0}', using '{1}' format and {2} parameters.", format_id, value, (parameters == null) ? 0 : parameters.Length);

                    return value;
                }
            }

            private void store_missing_format(String format_id, String text)
            {
                lock (_missings_dictionary)
                {
                    text = text.Replace("\t", @"\t");
                    text = text.Replace("\n", @"\n");
                    text = text.Replace("\r", "");

                    _missings_dictionary.Add(format_id, text);

                    FileStream fs = new FileStream(_missing_dictionary_name,
                                                   FileMode.OpenOrCreate,
                                                   FileAccess.Write,
                                                   FileShare.None);

                    fs.Seek(0, SeekOrigin.End);

                    using (StreamWriter sw = new StreamWriter(fs))
                    {
                        write_line(sw, format_id, text);
                    }

                    fs.Close();
                }
            }

            private Dictionary<String, String>  _dictionary                 = new Dictionary<String, String>();
            private Dictionary<String, String>  _missings_dictionary        = new Dictionary<String, String>();
            private String                      _missing_dictionary_name;
            private HashSet<String>             _throwing_exception         = new HashSet<String>();
            private FileWatcher                 _file_watcher;
        }

        /// <summary>
        /// The known languages
        /// </summary>
        public static String[] Languages
        {
            get { return _dictionaries.Keys.ToArray(); }
        }

        /// <summary>
        /// The default language dictionary
        /// </summary>
        public static IDict DefaultDict
        {
            get { return _defaultDictionary; }
        }

        /// <summary>
        /// The Logger
        /// </summary>
        public static Logger Logger
        {
            get { return _logger; }
        }

        /// <summary>
        /// US_ENGLISH language id
        /// </summary>
        public const String US_ENGLISH = "EN-US";

        //http://www.metamodpro.com/browser-language-codes
        //http://www.w3schools.com/tags/ref_language_codes.asp
        //http://www.mcanerin.com/EN/articles/meta-language.asp
        /// <summary>
        /// Initializes the static data
        /// </summary>
        public static void Initialize()
        {
            if (_initialized)
            {
                Debug.Assert(false);
                return;
            }

            _initialized = true;

            _defaultLanguage.Subscribe(SetDefaultLanguage);
            _languageBindings.Subscribe(SetLanguageBindings);
        }

        private static void SetDefaultLanguage(String default_language_id, AppCfg.Item item)
        {
            if (_defaultLanguage.Reloaded)
                _logger.InfoFormat("{0} configuration setting has been changed.", _defaultLanguage.Name);

            if (String.IsNullOrWhiteSpace(default_language_id))
                default_language_id = US_ENGLISH;

            if (_dictionaries.TryGetValue(default_language_id, out _defaultDictionary) == false)
            {
                if (default_language_id != US_ENGLISH)
                {
                    SetDefaultLanguage(US_ENGLISH, null);
                    return;
                }
                else
                {
                    foreach (Dict dict in _dictionaries.Values)
                    {
                        _defaultDictionary = dict;
                        break;
                    }

                    if (_defaultDictionary == null)
                    {
                        Dict dict = new Dict(default_language_id);
                        _dictionaries.Add(default_language_id, dict);
                        _defaultDictionary = dict;
                    }
                }
            }
        }

        private static readonly String[] binding_separator = new String[] { "->" };

        private static void SetLanguageBindings(String bindings_list, AppCfg.Item item)
        {
            if (_languageBindings.Reloaded)
                _logger.InfoFormat("{0} configuration setting has been changed.", _languageBindings.Name);

            bindings_list = bindings_list.Replace("\x20", "");
            bindings_list = bindings_list.Replace("\t", "");

            String[] bindings = bindings_list.Split(';', ',');

            Dictionary<String, String> languageToLanguage = new Dictionary<String, String>();

            foreach (String binding in bindings)
            {
                String[] langs = binding.Split(binding_separator, StringSplitOptions.RemoveEmptyEntries);

                if (langs.Length == 0)
                    continue;

                if (langs.Length != 2)
                {
                    _logger.WarnFormat("Invalid binding '{0}'.", binding);
                    continue;
                }

                AddLanguageBinding(languageToLanguage, langs[0], langs[1]);
            }

            _languageToLanguage = languageToLanguage;
        }

        /// <summary>
        /// Adds a language binding
        /// </summary>
        public static bool AddLanguageBinding(Dictionary<String, String> languageToLanguage, String from_language_id, String to_language_id)
        {
            _logger.InfoFormat("Binding '{0}' to '{1}'...", from_language_id, to_language_id);

            String[] from;
            if (!validate_culture(ref from_language_id, out from))
                return false;

            String[] to;
            if (!validate_culture(ref to_language_id, out to))
                return false;

            String value;

            if (languageToLanguage.TryGetValue(from_language_id, out value))
            {
                if (value == to_language_id)
                {
                    _logger.WarnFormat("Language '{0}' is already bound to '{1}'.",
                                      from_language_id,
                                      to_language_id);
                }
                else
                {
                    _logger.WarnFormat("Cannot bind language '{0}' to {1}. It is already bound to '{2}'.",
                                      from_language_id,
                                      to_language_id,
                                      value);
                }

                return false;
            }

            Dict found;
            if (_dictionaries.TryGetValue(to_language_id, out found) == false)
            {
                _logger.WarnFormat("Dictionary for language '{0}' not found.",
                                  to_language_id);

                return false;
            }

            languageToLanguage.Add(from_language_id, to_language_id);

            if(from[0] == from[1] && to[0] == to[1])
                _logger.InfoFormat("'{0}' is bound to '{1}'.", from[0], to[0]);
            else
                _logger.InfoFormat("'{0}' is bound to '{1}' ({2} -> {3}).", from[0], to[0], from[1], to[1]);

            return true;
        }

        /// <summary>
        /// Returns the dictionary specified by language_id.
        /// If not found, the default dictionary is returned.
        /// NOTE that the default dictionary will be null if no language dictionary was found
        /// </summary>
        public static IDict GetDict(String language_id)
        {
            Dict found;

            if (String.IsNullOrWhiteSpace(language_id))
                return DefaultDict;

            language_id = language_id.ToUpper();

            if (_dictionaries.TryGetValue(language_id, out found) == false)
            {
                String to_language_id;

                if (_languageToLanguage.TryGetValue(language_id, out to_language_id))
                    return GetDict(to_language_id);
                else
                    if (_smartLanguageBinding.Value)
                        return get_similar_dict(language_id);

                found = _defaultDictionary;
            }

            return found;
        }

        private static Dict get_similar_dict(String language_id)
        {
            char separator = '-';
            String[] ids = language_id.Split(separator);

            if (ids.Length < 2)
                return _defaultDictionary;

            String id_prefix = ids[0] + separator;

            foreach (Dict dict in _dictionaries.Values)
            {
                if (dict.LanguageId.IndexOf(id_prefix) == 0)
                    return dict;
            }

            return _defaultDictionary;
        }

        private static bool validate_culture(ref String id, out String[] text)
        {
            id = id.ToUpper();
            text = new String[2];

            try
            {
                text[0] = System.Globalization.CultureInfo.GetCultureInfo(id).EnglishName;
                text[1] = System.Globalization.CultureInfo.GetCultureInfo(id).DisplayName;
            }
            catch(Exception ex)
            {
                if (ex.GetType() == typeof(System.Globalization.CultureNotFoundException))
                {
                    _logger.ErrorFormat("Culture is not supported. {0} is an invalid culture identifier.", id);
                }
                else
                {
                    _logger.Error(ex);
                }

                return false;
            }

            return true;
        }

        private static bool                         _initialized = false;
        private static AppCfg.LogLevelItem          _logLevel = new AppCfg.LogLevelItem(AppCfg.LogSettings, "Translator");
        private static AppCfg.Settings              _settings = new AppCfg.Settings("translatorSettings");
        private static AppCfg.StringItem            _defaultLanguage = new AppCfg.StringItem(_settings, "DefaultLanguage", US_ENGLISH);
        private static AppCfg.StringItem            _languageBindings = new AppCfg.StringItem(_settings, "LanguageBindings", "");
        private static AppCfg.BoolItem              _smartLanguageBinding = new AppCfg.BoolItem(_settings, "SmartLanguageBinding", true);
        private static AppCfg.BoolItem              _compareDictionaries = new AppCfg.BoolItem(_settings, "CompareDictionaries", true);
        private static AppCfg.BoolItem              _refreshDictionaryWhenChanged = new AppCfg.BoolItem(_settings, "RefreshDictionaryWhenChanged", true, false);

        private static Logger                       _logger = Logger.GetLogger( "Language Translator" );
        private static Dict                         _defaultDictionary;
        private static Dictionary<String, Dict>     _dictionaries         = new Dictionary<String, Dict>();
        private static Dictionary<String, String>   _languageToLanguage   = new Dictionary<String, String>();
        private static String                       _languages_folder;
        private static FileWatcher                  _folder_watcher;

        private static Dictionary<String, Dict> load()
        {
            _logger.Info("Loading dictionaries...");

            Dictionary<String, Dict> dictionaries = new Dictionary<String, Dict>();

            if( Directory.Exists(_languages_folder) == false)
                return dictionaries;

            String[] files = null;

            try
            {
                files = Directory.GetFiles(_languages_folder, "Dictionary.*.txt", SearchOption.TopDirectoryOnly);
            }
            catch (System.Exception ex)
            {
                _logger.ErrorEx("Initializing the Translator", ex, false);
                return dictionaries;
            }

            foreach (String filename in files)
                load(dictionaries, filename, false);

            _logger.InfoFormat("{0} dictionaries loaded.", dictionaries.Count);

            return dictionaries;
        }

        private static void load(Dictionary<String, Dict> dictionaries, String filename, bool under_reload)
        {
            String notxt = filename.Substring(0, filename.Length - 4);
            String extension = Path.GetExtension(notxt);
            extension = extension.Substring(1);

            if (String.IsNullOrWhiteSpace(extension))
                return;

            extension = extension.ToUpper();

            Dict dict;

            if (dictionaries.TryGetValue(extension, out dict) == false)
            {
                dict = new Dict(extension);
                dictionaries.Add(extension, dict);
            }

            dict.Load(filename, under_reload);
        }

        private static void on_folder_changed(FileSystemEventArgs e)
        {
            if (e.Name.IndexOf(__Missing__) == 0)
                return;

            _dictionaries = load();
        }

        static void updateLogLevel(TracerX.TraceLevel level, AppCfg.Item item)
        {
            _logger.BinaryFileTraceLevel = level;
        }

        static void compare(Dict dict)
        {
            foreach (Dict other in _dictionaries.Values)
                dict.Compare(other);
        }

        static Translator()
        {
            _logLevel.Subscribe(updateLogLevel);

            _languages_folder = Path.GetDirectoryName(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile) + @"\Languages";

            _dictionaries = load();

            if (_compareDictionaries.Value && _dictionaries.Count > 1)
            {
                _logger.Info("Comparing dictionaries...");

                foreach (Dict dict in _dictionaries.Values)
                    compare(dict);

                _logger.Info("Dictionaries comparison done.");
            }

            foreach (Dict dict in _dictionaries.Values)
                dict.LoadMissing();

            if (_refreshDictionaryWhenChanged.Value)
            {
                if( Directory.Exists(_languages_folder) )
                    _folder_watcher = new FileWatcher(_languages_folder, on_folder_changed, 10, _logger);
            }
        }
    }

    /// <summary>
    /// The UnivText class
    /// </summary>
    public class UnivText
    {
        /// <summary>
        /// ERICOMMON_ prefix
        /// </summary>
        public const String ERICOMMON_ = "ERICOMMON_";

        /// <summary>
        /// Standard ERICOMMON_ text
        /// </summary>
        public static UnivText EricommonText(Translator.IDict dict, String id, params Object[] parameters)
        {
            return new UnivText(dict, ERICOMMON_ + id, parameters);
        }

        /// <summary>
        /// Standard Exception text
        /// </summary>
        public static UnivText ExceptionText(Translator.IDict dict, Exception ex)
        {
            return EricommonText(dict, "Exception_encountered", ex.AllMessages());
        }

        /// <summary>
        /// Invalid characters in ID
        /// </summary>
        public static readonly char[] INVALID_ID_CHARS = new char[] { '\x20', '\t', '\n', '\r' };

        /// <summary>
        /// The common c-tor
        /// </summary>
        public UnivText(Translator.IDict dict, String id, params Object[] parameters)
        {
            _dict = dict;
            Debug.Assert(String.IsNullOrWhiteSpace(id) == false);
            Debug.Assert(id.LastIndexOfAny(INVALID_ID_CHARS) < 0);
            _id = (String.IsNullOrWhiteSpace(id)) ? "?????" : id;

            _parameters = parameters;
            _mode = Mode.Translate;
        }

        /// <summary>
        /// The special c-tor
        /// </summary>
        public UnivText(Translator.IDict dict, Mode mode, String id, params Object[] parameters)
        {
            _dict = dict;
            _mode = mode;

            Debug.Assert(String.IsNullOrWhiteSpace(id) == false);
            Debug.Assert(mode != Mode.Translate || id.LastIndexOfAny(INVALID_ID_CHARS) < 0);
            _id = (String.IsNullOrWhiteSpace(id)) ? "?????" : id;

            _parameters = parameters;
        }

        /// <summary>
        /// The special c-tor
        /// </summary>
        public UnivText(String text)
        {
            _dict = null;
            _mode = UnivText.Mode.DoNotTranslate;

            _id = (text == null) ? "" : text;
            _parameters = null;
        }

        /// <summary>
        /// Translation modes
        /// </summary>
        public enum Mode
        {
            /// <summary>
            /// The _id is a placeholder
            /// </summary>
            Translate,

            /// <summary>
            /// The _id can be a placeholder
            /// </summary>
            TryToTranslate,

            /// <summary>
            /// The _id is the text itself
            /// </summary>
            DoNotTranslate,
        }

        /// <summary>
        /// Returns the default dictionary
        /// </summary>
        public Translator.IDict Dict
        {
            get { return (_dict == null) ? Translator.DefaultDict : _dict; }
        }

        /// <summary>
        /// Translates using the default dictionary
        /// </summary>
        public override String ToString()
        {
            return ToString(Dict);
        }

        /// <summary>
        /// Appends another UnivText
        /// </summary>
        public UnivText Add(UnivText next, String add_before_next = "\n")
        {
            Debug.Assert(next != null);
            UnivText last = get_last(next._id);

            if (last == null)
                return this;

            last._next = next;
            last._add_before_next = add_before_next;

            return this;
        }

        UnivText get_last(String _id)
        {
            UnivText last = this;

            while (last._next != null)
            {
                if (last._next._id == _id)
                {
                    Debug.Assert(true);
                    Translator.Logger.ErrorFormat("Circular UnivText: id={0}", _id);
                    return null;
                }

                last = last._next;
            }

            return last;
        }

        /// <summary>
        /// Appends another UnivText
        /// </summary>
        public UnivText Add(String id, String add_before_next = "\n")
        {
            Debug.Assert(id != null);
            UnivText last = get_last(id);

            if (last == null)
                return this;

            last._next = new UnivText(_dict, id);
            last._add_before_next = add_before_next;

            return this;
        }

        /// <summary>
        /// Translates using the specified dictionary
        /// </summary>
        public String ToString(Translator.IDict dict)
        {
            String text = translate(dict);
            if (_next != null)
            {
                if (String.IsNullOrEmpty(_add_before_next) == false)
                    text += _add_before_next;

                text += _next.ToString(dict);
            }

            return text;
        }

        private String translate(Translator.IDict dict)
        {
            if (_mode == Mode.DoNotTranslate)
                return _id;

            String key = _id;

            if (_mode == Mode.TryToTranslate)
            {
                char underscore = '_';

                key = key.Replace('\t', underscore);
                key = key.Replace('\n', underscore);
                key = key.Replace('\r', underscore);
                key = key.Replace(' ',  underscore);
            }

            String text;

            if (dict != null)
            {
                text = dict.TryGet(key, _id, _parameters);

                if (_mode != Mode.TryToTranslate || text != key)
                    return text;
            }

            text = _id;

            if (_parameters != null)
                foreach (String param in _parameters)
                    text += String.Format(" [{0}]", param);

            return text;
        }

        private Translator.IDict    _dict;
        private Mode                _mode;
        private String              _id;
        private Object[]            _parameters;
        private UnivText            _next;
        private String              _add_before_next;
    }

}
