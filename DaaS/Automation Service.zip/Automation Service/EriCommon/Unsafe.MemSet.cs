﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using TracerX;

namespace EriCommon
{
    /// <summary>
    /// The Unsafe class provide unsafe, low-level static methods.
    /// </summary>
    public unsafe partial class Unsafe
    {
        #region MemSet
        /// <summary>
        /// The MemSet method fills a byte array with a specific value.
        /// </summary>
        public static void MemSet(byte[] arr, byte fill)
        {
            if (check_MemSet_args(arr) == false)
                return;

            fixed (byte* pArr = arr)
            {
                byte* ps = pArr;
                FillMemory((IntPtr)ps, (IntPtr)(arr.Length * sizeof(byte)), fill);
            }
        }

        #endregion

        #region ZeroMem

        /// <summary>
        /// The ZeroMem of byte arrays.
        /// </summary>
        public static void ZeroMem(byte[] arr)
        {
            if (check_MemSet_args(arr) == false)
                return;

            fixed (byte* pArr = arr)
            {
                byte* ps = pArr;
                ZeroMemory((IntPtr)ps, (IntPtr)(arr.Length * sizeof(byte)));
            }
        }

        /// <summary>
        /// The ZeroMem of short arrays.
        /// </summary>
        public static void ZeroMem(short[] arr)
        {
            if (check_MemSet_args(arr) == false)
                return;

            fixed (short* pArr = arr)
            {
                short* ps = pArr;
                ZeroMemory((IntPtr)ps, (IntPtr)(arr.Length * sizeof(short)));
            }
        }

        /// <summary>
        /// The ZeroMem of ushort arrays.
        /// </summary>
        public static void ZeroMem(ushort[] arr)
        {
            if (check_MemSet_args(arr) == false)
                return;

            fixed (ushort* pArr = arr)
            {
                ushort* ps = pArr;
                ZeroMemory((IntPtr)ps, (IntPtr)(arr.Length * sizeof(ushort)));
            }
        }

        /// <summary>
        /// The ZeroMem of int arrays.
        /// </summary>
        public static void ZeroMem(int[] arr)
        {
            if (check_MemSet_args(arr) == false)
                return;

            fixed (int* pArr = arr)
            {
                int* ps = pArr;
                ZeroMemory((IntPtr)ps, (IntPtr)(arr.Length * sizeof(int)));
            }
        }

        /// <summary>
        /// The ZeroMem of uint arrays.
        /// </summary>
        public static void ZeroMem(uint[] arr)
        {
            if (check_MemSet_args(arr) == false)
                return;

            fixed (uint* pArr = arr)
            {
                uint* ps = pArr;
                ZeroMemory((IntPtr)ps, (IntPtr)(arr.Length * sizeof(uint)));
            }
        }

        /// <summary>
        /// The ZeroMem of long arrays.
        /// </summary>
        public static void ZeroMem(long[] arr)
        {
            if (check_MemSet_args(arr) == false)
                return;

            fixed (long* pArr = arr)
            {
                long* ps = pArr;
                ZeroMemory((IntPtr)ps, (IntPtr)(arr.Length * sizeof(long)));
            }
        }

        /// <summary>
        /// The ZeroMem of ulong arrays.
        /// </summary>
        public static void ZeroMem(ulong[] arr)
        {
            if (check_MemSet_args(arr) == false)
                return;

            fixed (ulong* pArr = arr)
            {
                ulong* ps = pArr;
                ZeroMemory((IntPtr)ps, (IntPtr)(arr.Length * sizeof(ulong)));
            }
        }

        /// <summary>
        /// The ZeroMem of float arrays.
        /// </summary>
        public static void ZeroMem(float[] arr)
        {
            if (check_MemSet_args(arr) == false)
                return;

            fixed (float* pArr = arr)
            {
                float* ps = pArr;
                ZeroMemory((IntPtr)ps, (IntPtr)(arr.Length * sizeof(float)));
            }
        }

        /// <summary>
        /// The ZeroMem of double arrays.
        /// </summary>
        public static void ZeroMem(double[] arr)
        {
            if (check_MemSet_args(arr) == false)
                return;

            fixed (double* pArr = arr)
            {
                double* ps = pArr;
                ZeroMemory((IntPtr)ps, (IntPtr)(arr.Length * sizeof(double)));
            }
        }

        /// <summary>
        /// The ZeroMem of char arrays.
        /// </summary>
        public static void ZeroMem(char[] arr)
        {
            if (check_MemSet_args(arr) == false)
                return;

            fixed (char* pArr = arr)
            {
                char* ps = pArr;
                ZeroMemory((IntPtr)ps, (IntPtr)(arr.Length * sizeof(char)));
            }
        }

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern void FillMemory(IntPtr arr, IntPtr Length, byte fill);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern void ZeroMemory(IntPtr arr, IntPtr Length);

        private static bool check_MemSet_args<T>(T[] arr)
        {
            if (arr == null)
                throw new AccessViolationException("The array is null");

            return arr.Length > 0;
        }

        #endregion ZeroMem
    }
}
