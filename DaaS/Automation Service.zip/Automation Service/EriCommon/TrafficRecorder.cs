﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using System.Diagnostics;
using TracerX;

namespace EriCommon
{
    /// <summary>
    /// The TrafficRecorder class is designed to record traffic to file.
    /// </summary>
    public class TrafficRecorder
    {
        /// <summary>
        /// Specifies the direction of the traffic
        /// </summary>
        public enum Mode
        {
            /// <summary>
            /// Client to Server.
            /// </summary>
            C2S = 1,
            /// <summary>
            /// Server to Client.
            /// </summary>
            S2C = 2,
        };

        /// <summary>
        /// The InitCtx class holds the initial context of the traffic recorder.
        /// </summary>
        public class InitCtx
        {
            /// <summary>
            /// The ZERO time.
            /// </summary>
            public readonly UInt32 m_zero_tick_count;
            /// <summary>
            /// The context creation time.
            /// </summary>
            public readonly DateTime m_now;

            /// <summary>
            /// The maximum data size (MB) to be recorded in the file.
            /// </summary>
            public readonly UInt64 m_max_data_size_bytes;

            /// <summary>
            /// The InitCtx ctor.
            /// </summary>
            public InitCtx(UInt32 max_data_size_MB = 0)
            {
                m_now = DateTime.Now;
                m_zero_tick_count = _get_time_stamp(m_now);
                m_max_data_size_bytes = 1024 * 1024 * (UInt64)max_data_size_MB;
            }
        }

        /// <summary>
        /// The TrafficRecorder constructor.
        /// </summary>
        public TrafficRecorder(string filename, Mode mode, InitCtx init_ctx = null)
        {
            m_init_ctx = init_ctx;
            init(get_filename(filename, mode));
        }

        /// <summary>
        /// The TrafficRecorder constructor.
        /// </summary>
        public TrafficRecorder(string filename, InitCtx init_ctx = null)
        {
            m_init_ctx = init_ctx;
            init(filename);
        }

        /// <summary>
        /// The TrafficRecorder ctor.
        /// </summary>
        public TrafficRecorder( Mode mode, InitCtx init_ctx = null)
        {
            m_init_ctx = init_ctx;
            init(get_filename(null, mode));
        }

        /// <summary>
        /// The TrafficRecorder dtor.
        /// </summary>
        public void Dispose()
        {
            close_file();
        }

        /// <summary>
        /// The TrafficRecorder dtor.
        /// </summary>
        ~TrafficRecorder()
        {
        }

        /// <summary>
        /// Flushes buffered data to the file.
        /// </summary>
        public void Flush()
        {
            m_writer.Flush();
        }

        /// <summary>
        /// Writes data to the file (no flush).
        /// </summary>
        public void Write(byte[] buffer, UInt32 offset, UInt32 length, UInt32 high_byte = 0)
        {
            if (buffer != null && length > 0)
            {
                if (m_init_ctx.m_max_data_size_bytes > 0 &&
                    m_init_ctx.m_max_data_size_bytes <= m_data_bytes_written_in_file)
                {
                    open_file();
                }

                m_data_bytes_written_in_file += length;

                write(buffer, offset, length, high_byte);
            }
        }

        static private string get_filename(string filename, Mode mode)
        {
            if (filename == null || filename.Length == 0)
            {
                string directory_name = TracerX.FileBase.GetExpandedDefaultDir();
                string fn_prefix = Path.Combine(directory_name, string.Format("ECMN_{0}", DateTime.Now.ToString("yyMMdd_HHmmss")));
                UInt32 recording_counter = (UInt32)Interlocked.Increment(ref sm_recording_counter);

                filename = string.Format("{0}.{1,000}_", fn_prefix, recording_counter);
            }

            return filename + ((mode == Mode.C2S) ? "C2S" : "S2C");
        }

        private const UInt32 LENGTH_MASK = 0x00FFFFFF;

        private void write(byte[] buffer, UInt32 offset, UInt32 length, UInt32 high_byte)
        {
            Debug.Assert(length <= LENGTH_MASK);
            Debug.Assert((high_byte & LENGTH_MASK) == 0);
            Debug.Assert(buffer == null || buffer.Length >= offset + length);
            Debug.Assert(m_writer != null);

            m_packet_header.tick_count = _get_time_stamp() - m_init_ctx.m_zero_tick_count;
            m_packet_header.length = length | high_byte;

            m_packet_header.Store( m_writer );

            if (buffer != null && length > 0)
                m_writer.Write(buffer, (int)offset, (int)length);
        }

        private void init( string filename )
        {
            if (m_init_ctx == null)
                m_init_ctx = new InitCtx();

            m_filename_prefix = filename;

            open_file();
        }

        private void open_file()
        {
            String filename;

            if (m_init_ctx.m_max_data_size_bytes > 0)
            {
                close_file();

                if (m_file_number < 2)
                {
                    m_file_number++;
                }
                else
                {
                    String filename_1 = m_filename_prefix + ".#1" + m_file_extension;
                    String filename_2 = m_filename_prefix + ".#2" + m_file_extension;

                    if (File.Exists(filename_2))
                    {
                        if (File.Exists(filename_1)) File.Delete(filename_1);
                        File.Move(filename_2, filename_1);
                    }
                }

                filename = m_filename_prefix + ".#" + m_file_number.ToString();
            }
            else
            {
                filename = m_filename_prefix;
            }

            m_writer = new BinaryWriter(File.Open(filename + m_file_extension, FileMode.Create, FileAccess.Write, FileShare.Read));

            m_packet_header.Init(m_init_ctx);
            m_packet_header.Store(m_writer);

            m_data_bytes_written_in_file = 0;
        }

        private void close_file()
        {
            if (m_writer == null)
                return;

            write(null, 0, 0, 0);

            m_writer.Flush();
            m_writer.Close();

            m_writer = null;
        }

        private struct RecordingPacketHeader
        {
            public const UInt32 STAMP = (UInt32)0xAAAAAAAA;
            public UInt32 prefix, tick_count, length, suffix;

            public void Init(InitCtx ini_ctx)
            {
                prefix = STAMP;
                tick_count = ini_ctx.m_zero_tick_count;
                length = 1; // version
                suffix = STAMP;
            }

            public void Store(BinaryWriter writer)
            {
                writer.Write(prefix);
                writer.Write(tick_count);
                writer.Write(length);
                writer.Write(suffix);
            }
        }

        private static UInt32 _get_time_stamp()
        {
            return _get_time_stamp(DateTime.Now);
        }

        private static UInt32 _get_time_stamp( DateTime now )
        {
            return (UInt32)now.Ticks;
        }

        private const String m_file_extension = ".REC";
        private InitCtx m_init_ctx;
        private UInt64  m_data_bytes_written_in_file = 0;
        private UInt32  m_file_number = 0;
        private String m_filename_prefix;

        private BinaryWriter m_writer;
        private RecordingPacketHeader m_packet_header;
        private static Int32 sm_recording_counter;
    }
}
