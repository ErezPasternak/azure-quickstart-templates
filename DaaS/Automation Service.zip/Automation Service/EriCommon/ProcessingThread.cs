﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using TracerX;

namespace EriCommon
{
    /// <summary>
    /// The ProcessingItem abstract class.
    /// </summary>
    public abstract class ProcessingItem : IDisposable
    {
        /// <summary>
        /// This method is called after dequeuing.
        /// </summary>
        public abstract void Proceed();

        /// <summary>
        /// This method overrides abstractly the method IDisposable.Dispose().
        /// </summary>
        public abstract void Dispose();

        /// <summary>
        /// Returns true id dispatched.
        /// </summary>
        public bool Done
        {
            get { return m_dispatch_ticks != 0; }
        }

        /// <summary>
        /// Returns the delta time (in ticks) between the StartTicks and EndTicks
        /// </summary>
        public Int64 Ticks
        {
            get
            {
                return EndTicks - StartTicks;
            }
        }

        /// <summary>
        /// Returns the StartTicks
        /// </summary>
        public Int64 StartTicks
        {
            get
            {
                Debug.Assert(m_add_ticks != 0);
                return m_add_ticks;
            }
        }

        /// <summary>
        /// Returns the EndTicks
        /// </summary>
        public Int64 EndTicks
        {
            get
            {
                Debug.Assert(Done);
                return m_dispatch_ticks;
            }
        }

        internal void SetTicks(bool add)
        {
// #if DEBUG
//             string class_name = ReflectionHelper.GetClassName(2);
//             Type ProcessingQueueThread_t = typeof(ProcessingQueueThread);
//             Type ProcessingThread_t = typeof(ProcessingThread);
//
//             Debug.Assert(class_name == ProcessingQueueThread_t.FullName ||
//                                             class_name == ProcessingThread_t.FullName);
// #endif

            if (add)
            {
                m_add_ticks = DateTime.Now.Ticks;
                m_dispatch_ticks = 0;
            }
            else
            {
                m_dispatch_ticks = DateTime.Now.Ticks;
            }
        }

        private Int64 m_add_ticks = 0;
        private Int64 m_dispatch_ticks = 0;
    }

    /// <summary>
    /// The ProcessingQueueThread class creates and manages a dispatch thread for processing FIFO items.
    /// </summary>
    public class ProcessingQueueThread : IDisposable
    {
        /// <summary>
        /// The ProcessingQueueThread ctor.
        /// </summary>
        public ProcessingQueueThread(string name, bool safe, ThreadHelper.Mode thread_mode = ThreadHelper.Mode.Background)
        {
            ThreadHelper.Create(name, thread_main, safe, thread_mode);
            m_started_event.WaitOne();
            m_started_event = null;
        }

        /// <summary>
        /// The ProcessingQueueThread default ctor.
        /// </summary>
        protected ProcessingQueueThread()
        {
        }

        /// <summary>Stops this instance.</summary>
        public void Stop()
        {
            if (m_thread != null && m_thread.IsAlive)
            {
                m_stop_loop_event.Set();

                if (m_thread.Join(5000) == false)
                {
                    m_thread.Abort();
                }

                m_thread = null;
            }
        }

        /// <summary>
        /// Queues an item.
        /// </summary>
        public bool AddItem(ProcessingItem item)
        {
            lock (this)
            {
                if (m_disposed)
                {
                    item.Dispose();
                    return false;
                }

                item.SetTicks(true);
                m_queue.Enqueue(item);
                m_queued_event.Set();

                return true;
            }
        }

        /// <summary>
        /// Returns the name.
        /// </summary>
        public string Name
        {
            get { return m_thread.Name; }
        }

        /// <summary>
        /// Returns the count of items in queue.
        /// </summary>
        public virtual UInt32 Count
        {
            get
            {
                lock (this)
                {
                    return (UInt32)m_queue.Count;
                }
            }
        }

        /// <summary>
        /// Returns true if disposed.
        /// </summary>
        public bool Disposed
        {
            get
            {
                return m_disposed;
            }
        }

        /// <summary>
        /// Returns true if not disposed.
        /// </summary>
        public bool Active
        {
            get
            {
                return m_disposed == false;
            }
        }

        /// <summary>
        /// Disposes the instance.
        /// </summary>
        public void Dispose()
        {
            lock (this)
            {
                if (m_disposed == true)
                {
                    return;
                }

                m_disposed = true;
                m_queued_event.Set();

                sm_logger.Debug(string.Format("ProcessingQueueThread \"{0}\" has been disposed.", Name));
            }
        }

        /// <summary>
        /// Gets the next item from the queue.
        /// </summary>
        protected virtual ProcessingItem Next
        {
            get { return m_queue.Dequeue(); }
        }

        internal void Loop(out ProcessingItem item)
        {
            WaitHandle[] waitHandles = new WaitHandle[] {
                                                            m_stop_loop_event,
                                                            m_queued_event      // should be last
                                                        };
            item = null;
            UInt32 count = 0;

            while (true)
            {
                if (count == 0)
                {
                    int index = WaitHandle.WaitAny(waitHandles);

                    if (waitHandles[index] == m_stop_loop_event)
                    {
                        break;
                    }
                }

                lock (this)
                {
                    if (m_disposed)
                    {
                        while (Count > 0)
                        {
                            item = Next;
                            item.Dispose();
                        }

                        return;
                    }

                    count = Count;

                    if (count == 0)
                    {
                        m_queued_event.Reset();
                        continue;
                    }

                    item = Next;
                }

                Proceed(item);
                item = null;
            }
        }

        internal virtual void Proceed(ProcessingItem item)
        {
            item.SetTicks(false);
            item.Proceed();
        }

        private void thread_main()
        {
            m_thread = Thread.CurrentThread;
            m_started_event.Set();

            sm_logger.Debug(string.Format("ProcessingQueueThread \"{0}\" has been started.", Name));

            ProcessingItem item = null;

            try
            {
                Loop(out item);
            }
            catch (System.Threading.ThreadAbortException)
            {
                return;
            }
            catch (System.Exception ex)
            {
                if (item == null)
                {
                    SafeCall.ExceptionHandler(ex, string.Format("ProcessingQueueThread \"{0}\" has been failed.", Name));
                }
                else
                {
                    SafeCall.ExceptionHandler(ex, string.Format("ProcessingQueueThread \"{0}\" has been failed.\n" +
                                                                 "Item: {1}", Name, item.ToString()));
                }
            }
            finally
            {
                if (m_disposed)
                {
                    sm_logger.Debug(string.Format("ProcessingQueueThread \"{0}\" has been terminated.", Name));
                }
            }
        }

        /// <summary>
        /// A manual reset event used to synchronize between adding and removing items from the queue.
        /// </summary>
        protected ManualResetEvent m_queued_event = new ManualResetEvent(false);

        /// <summary>
        /// A manual reset event used to stop the loop that processes the queue.
        /// </summary>
        protected ManualResetEvent m_stop_loop_event = new ManualResetEvent(false);

        /// <summary>
        /// The item queue.
        /// </summary>
        protected Queue<ProcessingItem> m_queue = new Queue<ProcessingItem>();

        private ManualResetEvent m_started_event =  new ManualResetEvent(false);
        private Thread m_thread = null;
        private bool m_disposed = false;

        private static Logger sm_logger = Logger.GetLogger(ReflectionHelper.GetClassName());
    }

    /// <summary>
    /// The ProcessingThread class creates and manages a dispatch thread for processing items.
    /// It is able to push ahead items.
    /// </summary>
    public class ProcessingThread : ProcessingQueueThread
    {
        /// <summary>
        /// The ProcessingThread class creates and manages a dispatch thread for processing items.
        /// </summary>
        public ProcessingThread(string name, bool safe) : base(name, safe) { }

        /// <summary>
        /// The ProcessingThread default ctor.
        /// </summary>
        protected ProcessingThread()
        {
        }

        /// <summary>
        /// PushAheadItem an item.
        /// </summary>
        public bool PushAheadItem(ProcessingItem item)
        {
            lock (this)
            {
                if (Disposed)
                {
                    return false;
                }

                m_stack.Push(item);
                m_queued_event.Set();

                return true;
            }
        }

        /// <summary>
        /// Returns the count of items in queue + stack.
        /// </summary>
        public override UInt32 Count
        {
            get
            {
                lock (this)
                {
                    return (UInt32)(m_queue.Count + m_stack.Count);
                }
            }
        }

        /// <summary>
        /// Gets the next item. Tries first from the stack, then from the queue.
        /// </summary>
        protected override ProcessingItem Next
        {
            get
            {
                if (m_stack.Count > 0)
                {
                    return m_stack.Pop();
                }

                return m_queue.Dequeue();
            }
        }

        /// <summary>
        /// The item stack, used to push ahead.
        /// </summary>
        protected Stack<ProcessingItem> m_stack = new Stack<ProcessingItem>();
    }
}
