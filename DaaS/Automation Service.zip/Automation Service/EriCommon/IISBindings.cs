﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Xml;
using System.Security.Cryptography.X509Certificates;
using System.Net.Sockets;
using System.Net;
using System.DirectoryServices;
using Microsoft.Web.Administration;

namespace EriCommon
{
    /// <summary>
    /// IISBindings class deals with the IIS bindings
    /// </summary>
    public static class IISBindings
    {
        /// <summary>
        /// Initialzes some static members
        /// </summary>
        static public void Initialize(String _ComponentName, // "Ericom Secure Gateway"
                                      String _ConfigFile)
        {
            ComponentName = _ComponentName;
            ConfigFile = _ConfigFile;
            LockFile = String.Format("Global\\{0}", ConfigFile);
        }

        /// <summary>
        /// Checks is the specified ports are already in use by other processes.
        /// API used by install shield (Olga + Eyal)
        /// </summary>
        static public bool ArePortsConflictingWithOtherProcess(String _secured_port, String _non_secured_port, out String ports_status)
        {
            ports_status = ArePortsConflictingWithOtherProcess(String.IsNullOrWhiteSpace(_secured_port)     ? 0 : UInt32.Parse(_secured_port),
                                                               String.IsNullOrWhiteSpace(_non_secured_port) ? 0 : UInt32.Parse(_non_secured_port));

            return String.IsNullOrWhiteSpace(ports_status);
        }

        /// <summary>
        /// Checks is the specified port is already in use by other processes.
        /// </summary>
        static public bool IsPortConflictingWithOtherProcess(String port, bool secured, out String ports_status)
        {
            return ArePortsConflictingWithOtherProcess((secured) ? port : null,
                                                       (secured) ? null : port,
                                                       out ports_status);
        }

        /// <summary>
        /// Checks is the specified ports are already in use by other processes.
        /// </summary>
        static public String ArePortsConflictingWithOtherProcess(uint secured_port, uint non_secured_port)
        {
            Log(String.Format("ArePortsConflictingWithOtherProcess() Started\nSecured Port = {0}\nNon Secured Port = {1}", secured_port, non_secured_port));

            String ports_status = String.Empty;

            String site_name;
            String protocol_name;

            if (secured_port > 0 &&
                is_port_in_use_by_another_process((int)secured_port) &&
                is_port_in_use_by_iis((int)secured_port, true, out site_name, out protocol_name) == false)
            {
                ports_status = String.Format("Port {0} is already in use by another process in the system.", secured_port);
            }

            if (non_secured_port > 0 &&
                is_port_in_use_by_another_process((int)non_secured_port) &&
                is_port_in_use_by_iis((int)non_secured_port, false, out site_name, out protocol_name) == false)
            {
                if (String.IsNullOrEmpty(ports_status))
                    ports_status = String.Format("Port {0} is already in use by another process in the system.", non_secured_port);
                else
                    ports_status = String.Format("Both ports {0} and {1} are already in use by other processes in the system.", secured_port, non_secured_port);
            }

            if (String.IsNullOrWhiteSpace(ports_status) == false)
            {
                ports_status += String.Format("\n\nPlease change {0} listening ports configuration.", ComponentName);
                Log("ArePortsConflictingWithOtherProcess() Done.\nConflicts detected:\n" + ports_status);
            }
            else
            {
                Log("ArePortsConflictingWithOtherProcess() Done.\nNo Conflicts detected");
            }

            return ports_status;
        }

        /// <summary>
        /// Checks is the specified port is already in use by other processes.
        /// </summary>
        static public String IsPortConflictingWithOtherProcess(uint port, bool secured)
        {
            return ArePortsConflictingWithOtherProcess((secured) ? port : 0,
                                                       (secured) ? 0    : port);
        }

        /// <summary>
        /// Checks is the specified ports are already in use by IIS.
        /// API used by install shield (Olga + Eyal)
        /// </summary>
        static public bool ArePortsConflictingWithIIS(String _secured_port, String _non_secured_port, out String ports_status, out String _new_ports_settings, out String _new_secured_port, out String _new_non_secured_port)
        {
            _new_ports_settings     = String.Empty;
            _new_secured_port       = String.Empty;
            _new_non_secured_port   = String.Empty;

            uint new_secured_port     = 0;
            uint new_non_secured_port = 0;

            ports_status = ArePortsConflictingWithIIS(String.IsNullOrWhiteSpace(_secured_port) ? 0 : UInt32.Parse(_secured_port),
                                                      String.IsNullOrWhiteSpace(_non_secured_port) ? 0 : UInt32.Parse(_non_secured_port),
                                                      out _new_ports_settings,
                                                      out new_secured_port,
                                                      out new_non_secured_port);

            if (new_secured_port > 0)
                _new_secured_port = new_secured_port.ToString();
            if (new_non_secured_port > 0)
                _new_non_secured_port = new_non_secured_port.ToString();

            return String.IsNullOrWhiteSpace(ports_status) == false;
        }

        /// <summary>
        /// Checks is the specified port is already in use by IIS.
        /// </summary>
        static public bool IsPortConflictingWithIIS(String port, bool secured, out String ports_status, out String new_port_settings, out String new_port)
        {
            String new_secured, new_unsecured;

            bool retval = ArePortsConflictingWithIIS((secured) ? port : null,
                                                     (secured) ? null : port,
                                                     out ports_status,
                                                     out new_port_settings,
                                                     out new_secured,
                                                     out new_unsecured);

            new_port = (secured) ? new_secured : new_unsecured;

            return retval;
        }

        /// <summary>
        /// Checks is the specified ports are already in use by IIS.
        /// </summary>
        static public String ArePortsConflictingWithIIS(uint secured_port, uint non_secured_port, out String new_ports_settings, out uint new_secured_port, out uint new_non_secured_port)
        {
            Log(String.Format("ArePortsConflictingWithIIS() Started\nSecured Port = {0}\nNon Secured Port = {1}", secured_port, non_secured_port));

            String ports_status  = String.Empty;
            new_ports_settings   = String.Empty;

            uint new_port = 8090;

            test_iis_port(secured_port,
                          true,
                          ref ports_status,
                          ref new_ports_settings,
                          ref new_port,
                          out new_secured_port);

            test_iis_port(non_secured_port,
                          false,
                          ref ports_status,
                          ref new_ports_settings,
                          ref new_port,
                          out new_non_secured_port);

            if (String.IsNullOrWhiteSpace(ports_status))
                Log("ArePortsConflictingWithIIS() Done.\nConflicts detected:\n" + ports_status);
            else
                Log("ArePortsConflictingWithIIS() Done.\nNo Conflicts detected");

            return ports_status;
        }

        /// <summary>
        /// Checks is the specified port is already in use by IIS.
        /// </summary>
        static public String IsPortConflictingWithIIS(uint port, bool secured, out String new_port_settings, out uint new_port)
        {
            uint new_secured, new_unsecured;

            String retval = ArePortsConflictingWithIIS((secured) ? port : 0,
                                                       (secured) ? 0    : port,
                                                       out new_port_settings,
                                                       out new_secured,
                                                       out new_unsecured);

            new_port = (secured) ? new_secured : new_unsecured;

            return retval;
        }

        /// <summary>
        /// Changes IIS ports.
        /// API used by install shield (Olga + Eyal)
        /// </summary>
        static public void ChangeIISPorts(String config_file_path,
                                          String _old_secured_port,     String _new_secured_port,
                                          String _old_non_secured_port, String _new_non_secured_port)
        {
            Log("ChangeIISPorts() Started");

            String config_file_full_path = Path.Combine(config_file_path, IISSettingsConfigFile);

            bool deleted_prev_file = true;

            try
            {
                if (File.Exists(config_file_full_path))
                    File.Delete(config_file_full_path);
            }
            catch
            {
                deleted_prev_file = false;
            }

            int old_secured_port, new_secured_port, old_non_secured_port, new_non_secured_port;

            if (Int32.TryParse(_old_secured_port, out old_secured_port) &&
                Int32.TryParse(_new_secured_port, out new_secured_port))
            {
                if (change_iis_port(true, old_secured_port, new_secured_port) && deleted_prev_file)
                    File.AppendAllText(config_file_full_path, String.Format("https{0}{1}{2}{3}{4}", IISSettingsSplitChar, old_secured_port, IISSettingsSplitChar, new_secured_port, Environment.NewLine), Encoding.UTF8);
            }

            if (Int32.TryParse(_old_non_secured_port, out old_non_secured_port) &&
                Int32.TryParse(_new_non_secured_port, out new_non_secured_port))
            {
                if (change_iis_port(false, old_non_secured_port, new_non_secured_port) && deleted_prev_file)
                {
                    File.AppendAllText(config_file_full_path, String.Format("http{0}{1}{2}{3}{4}", IISSettingsSplitChar, old_non_secured_port, IISSettingsSplitChar, new_non_secured_port, Environment.NewLine), Encoding.UTF8);
                }
            }

            Log("ChangeIISPorts() Ended");
        }
/*
        /// <summary>
        /// Restores all changed IIS ports.
        /// API used by install shield (Olga + Eyal)
        /// </summary>
        static public bool RestoreIISPorts(String config_file_path)
        {
            Log("RestoreIISPorts() Started");

            // Return true if IIS configuration changed and IIS restart is required

            String config_file_full_path = Path.Combine(config_file_path, IISSettingsConfigFile);
            if (File.Exists(config_file_full_path) == false)
            {
                Log("RestoreIISPorts() Failed.\nCouldn't find file " + config_file_full_path);
                return false;
            }

            Log("RestoreIISPorts()\n. Using file " + config_file_full_path);

            String _orig_secured_port = String.Empty, _current_secured_port = String.Empty, _orig_non_secured_port = String.Empty, _current_non_secured_port = String.Empty;
            int orig_secured_port, current_secured_port, orig_non_secured_port, current_non_secured_port;

            string[] lines = File.ReadAllLines(config_file_full_path, Encoding.UTF8);

            foreach (string line in lines)
            {
                Log("RestoreIISPorts()\n.Handling : " + line);

                String[] parts = line.Split(new char[] { IISSettingsSplitChar }, StringSplitOptions.RemoveEmptyEntries);

                if (parts.Length != 3)
                {
                    Log("RestoreIISPorts()\n.Line : " + line + " is invalid");
                    continue;
                }

                if (parts[0].Equals("https", StringComparison.OrdinalIgnoreCase))
                {
                    _orig_secured_port = parts[1];
                    _current_secured_port = parts[2];
                }
                else if (parts[0].Equals("http", StringComparison.OrdinalIgnoreCase))
                {
                    _orig_non_secured_port = parts[1];
                    _current_non_secured_port = parts[2];
                }
            }

            bool iis_settings_changed = false;

            if (Int32.TryParse(_orig_secured_port, out orig_secured_port) &&
                Int32.TryParse(_current_secured_port, out current_secured_port))
            {
                if (change_iis_port(true, current_secured_port, orig_secured_port))
                    iis_settings_changed = true;
            }

            if (Int32.TryParse(_orig_non_secured_port, out orig_non_secured_port) &&
                Int32.TryParse(_current_non_secured_port, out current_non_secured_port))
            {
                if (change_iis_port(false, current_non_secured_port, orig_non_secured_port))
                    iis_settings_changed = true;
            }

            try
            {
                File.Delete(config_file_full_path);
            }
            catch { }

            Log("RestoreIISPorts() Ended");

            return iis_settings_changed;
        }
*/
        /// <summary>
        /// Changes an IIS port.
        /// API used by install shield (Olga + Eyal)
        /// </summary>
        static public void ChangeIISPort(String config_file_path,
                                         String old_port,
                                         String new_port,
                                         bool   secured)
        {
            ChangeIISPort(config_file_path,
                          int.Parse(old_port),
                          int.Parse(new_port),
                          secured);
        }

        const String http  = "http";
        const String https = "https";

        /// <summary>
        /// Changes an IIS port.
        /// </summary>
        static public void ChangeIISPort(String config_file_path,
                                         int    old_port,
                                         int    new_port,
                                         bool   secured)
        {
            Log("ChangeIISPort() Started");

            String config_file_full_path = Path.Combine(config_file_path, IISSettingsConfigFile);

            bool deleted_prev_file = true;

            try
            {
                if (File.Exists(config_file_full_path))
                    File.Delete(config_file_full_path);
            }
            catch
            {
                deleted_prev_file = false;
            }

            if (change_iis_port(secured, old_port, new_port) && deleted_prev_file)
                File.AppendAllText(config_file_full_path,
                                   String.Format("{0}{1}{2}{3}{4}{5}",
                                                 (secured) ? https : http,
                                                 IISSettingsSplitChar,
                                                 old_port,
                                                 IISSettingsSplitChar,
                                                 new_port,
                                                 Environment.NewLine),
                                   Encoding.UTF8);

            Log("ChangeIISPort() Ended");
        }

        /// <summary>
        /// Adds an IIS port.
        /// API to used by install shield (Olga)
        /// </summary>
        static public bool AddIISPort(String config_file_path,
                                      String port,
                                      String certificate_thumbprint,
                                      bool   deleted_prev_file,
                                      String site_name = null) // Default Web Site
        {
            return AddIISPort(config_file_path,
                              int.Parse(port),
                              certificate_thumbprint,
                              deleted_prev_file,
                              site_name);
        }

        /// <summary>
        /// Adds an IIS port.
        /// </summary>
        static public bool AddIISPort(String config_file_path,
                                      int     port,
                                      String  certificate_thumbprint,
                                      bool    deleted_prev_file,
                                      String  site_name = null) // Default Web Site
        {
            Log("AddIISPort() Started");

            String config_file_full_path = Path.Combine(config_file_path, IISSettingsConfigFile);

            bool access_denied = false;

            try
            {
                if (deleted_prev_file && File.Exists(config_file_full_path))
                    File.Delete(config_file_full_path);
            }
            catch
            {
                access_denied = true;
            }

            bool added = false;

            if (add_iis_port(port, certificate_thumbprint, site_name))
            {
                if(access_denied == false)
                    File.AppendAllText(config_file_full_path,
                                       String.Format("{0}{1}{2}{3}{4}{5}",
                                                     (String.IsNullOrWhiteSpace(certificate_thumbprint)) ? http : https,
                                                     IISSettingsSplitChar,
                                                     0,
                                                     IISSettingsSplitChar,
                                                     port,
                                                     Environment.NewLine),
                                       Encoding.UTF8);

                added = true;
            }

            Log("AddIISPort() Ended");

            return added;
        }

        /// <summary>
        /// Restores all changed IIS ports.
        /// API used by install shield (Olga + Eyal)
        /// </summary>
        static public bool RestoreIISPorts(String config_file_path)
        {
            Log("RestoreIISPorts() Started");

            // Return true if IIS configuration changed and IIS restart is required

            String config_file_full_path = Path.Combine(config_file_path, IISSettingsConfigFile);
            if (File.Exists(config_file_full_path) == false)
            {
                Log("RestoreIISPort() Failed.\nCouldn't find file " + config_file_full_path);
                return false;
            }

            Log("RestoreIISPorts()\n. Using file " + config_file_full_path);

            String _orig_port    = String.Empty,
                   _curr_port = String.Empty;
            int    orig_port,
                   curr_port;

            string[] lines = File.ReadAllLines(config_file_full_path, Encoding.UTF8);

            bool iis_settings_changed = false;

            foreach (string line in lines)
            {
                Log("RestoreIISPorts()\n.Handling : " + line);

                String[] parts = line.Split(new char[] { IISSettingsSplitChar }, StringSplitOptions.RemoveEmptyEntries);

                if (parts.Length != 3)
                {
                    Log("RestoreIISPorts()\n.Line : " + line + " is invalid");
                    continue;
                }

                orig_port = 0;

                bool secured;

                if (parts[0].Equals(http))          secured = false;
                else if (parts[0].Equals(https))    secured = true;
                else continue;

                _orig_port = parts[1];
                _curr_port = parts[2];

                if (String.IsNullOrEmpty(_orig_port) == false && Int32.TryParse(_orig_port, out orig_port) &&
                    String.IsNullOrEmpty(_curr_port) == false && Int32.TryParse(_curr_port, out curr_port))
                {
                    if (orig_port > 0)
                    {
                        if (change_iis_port(secured, curr_port, orig_port))
                            iis_settings_changed = true;
                    }
                    else
                    {
                        if (remove_iis_port(secured, curr_port))
                            iis_settings_changed = true;
                    }
                }
            }

            try
            {
                File.Delete(config_file_full_path);
            }
            catch { }

            Log("RestoreIISPorts() Ended");

            return iis_settings_changed;
        }

        static private bool ImportCertificate()
        {
            String certificate_thumbprint;
            return ImportCertificate(Directory.GetCurrentDirectory(), true, out certificate_thumbprint);
        }

        /// <summary>
        /// YOCHAI
        /// </summary>
        static public bool ImportCertificate(String config_file_path, bool interactive, out String certificate_thumbprint)
        {
            certificate_thumbprint = null;

            EventWaitHandle lock_config_file = null;
            bool granted = false;

            try
            {
                certificate_thumbprint = SelectCertificate(interactive);

                if (String.IsNullOrEmpty(certificate_thumbprint))
                {
                    if (interactive)
                        MessageBox.Show("Import certificate canceled by the user.", String.Format("{0} Import Certificate Tool", ComponentName));

                    return false;
                }

                lock_config_file = new EventWaitHandle(true, EventResetMode.AutoReset, LockFile);
                granted = lock_config_file.WaitOne(5000);
                if (granted == false)
                    throw new Exception("Failed obtaining write ownership on the configuration file.");

                String config_file_full_path = Path.Combine(config_file_path, ConfigFile);

                XmlDocument app_config = new XmlDocument();
                app_config.Load(config_file_full_path);

                XmlNode app_settings = app_config.SelectSingleNode("/configuration/appSettings");
                StoreValue(ref app_settings, "CertificateThumbprint", certificate_thumbprint);

                app_config.Save(config_file_full_path);

                if (interactive)
                    MessageBox.Show(String.Format("Import certificate succeeded.\nCertificate Thumbprint is:\n{0}", certificate_thumbprint),
                                    String.Format("{0} Import Certificate Tool", ComponentName));

                return true;
            }
            catch (Exception e)
            {
                if (interactive)
                    MessageBox.Show(String.Format("Failed importing certificate. Reason:\n{0}", e.Message),
                                    String.Format("{0} Import Certificate Tool", ComponentName));

                return false;
            }
            finally
            {
                if (lock_config_file != null && granted)
                    lock_config_file.Set();
            }
        }

        static private String SelectCertificate(bool interactive)
        {
            String certificate_thumbprint = null;

            try
            {
                X509Store store = new X509Store("MY", StoreLocation.LocalMachine);
                store.Open(OpenFlags.ReadOnly | OpenFlags.OpenExistingOnly);

                X509Certificate2 x509 = null;

                switch(store.Certificates.Count)
                {
                    case 0 :
                        {
                            String generated_certificate_subject = null;
                            x509 = CertificateManager.Instance.LoadOrGenerateCertificate(null, ref generated_certificate_subject);
                            break;
                        }

                    case 1:
                        {
                            x509 = store.Certificates[0];
                            break;
                        }

                    default:
                        {
                            if(interactive == false)
                                x509 = store.Certificates[0];

                            break;
                        }
                }

                if (x509 == null)
                {
                    X509Certificate2Collection certs = X509Certificate2UI.SelectFromCollection(
                                                            store.Certificates,
                                                            "Local Computer/Personal",
                                                            String.Format("\nSelect the certificate to be used by {0}, then press the OK button.\n" +
                                                                            "When a certificate is selected, you can view its properties.\n",
                                                                          ComponentName),
                                                            X509SelectionFlag.SingleSelection,
                                                            GetMsiexecWindow());

                    // certs.Count == 0 means the user has pressed the 'Cancel' button

                    Debugger.Assert(certs.Count <= 1);

                    if (certs.Count == 1)
                    {
                        x509 = certs[0];
                    }
                }

                if (x509 != null)
                    certificate_thumbprint = x509.Thumbprint;
            }
            catch
            {

            }

            return certificate_thumbprint;
        }

        static private bool is_port_in_use_by_another_process(int port)
        {
            Log(String.Format("is_port_in_use_by_another_process() Started\nPort to check = {0}", port));

            TcpListener listener;
            bool in_use = true;

            try
            {
                // First check v4
                listener = new TcpListener(IPAddress.Any, port);
                listener.Server.ExclusiveAddressUse = true;
                listener.Start();
                listener.Stop();
            }
            catch (Exception e)
            {
                Log(String.Format("is_port_in_use_by_another_process() Ended\nPort {0} in use\nIPv4 check failed with: {1}", port, e.Message));
                return in_use;
            }

            try
            {
                // Then check v6
                try
                {
                    // Not all systems support IPv6
                    listener = new TcpListener(IPAddress.IPv6Any, port);
                }
                catch (Exception e)
                {
                    Log(String.Format("is_port_in_use_by_another_process() Ended\nPort {0} available\nIPv6 check failed with: {1}", port, e.Message));
                    return false;
                }

                listener.Server.ExclusiveAddressUse = true;
                listener.Start();
                listener.Stop();

                Log(String.Format("is_port_in_use_by_another_process() Ended\nPort {0} available", port));
                in_use = false;
            }
            catch (Exception e)
            {
                Log(String.Format("is_port_in_use_by_another_process() Ended\nPort {0} in use\nIPv6 check failed with: {1}", port, e.Message));
            }

            return in_use;
        }

        static void test_iis_port(uint port, bool secured, ref String ports_status, ref String new_ports_settings, ref uint new_port, out uint ret_new_port)
        {
            String site_name;
            String protocol_name;
            ret_new_port = 0;

            if (port > 0 &&
                is_port_in_use_by_iis((int)port, secured, out site_name, out protocol_name))
            {
                if (String.IsNullOrEmpty(protocol_name) == false)
                {
                    if (String.IsNullOrEmpty(site_name) == false)
                        ports_status += String.Format("The local IIS is configured to listen on port {0} for the {1} binding of \"{2}\" site.\n", port, protocol_name, site_name);
                    else
                        ports_status += String.Format("The local IIS is configured to listen on port {0} for the {1} binding.\n", port, protocol_name);
                }
                else
                {
                    ports_status += String.Format("The local IIS is configured to listen on port {0}.\n", port);
                }

                for (; ; new_port++)
                    if (new_port != port && is_port_in_use_by_another_process((int)new_port) == false)
                        break;

                ret_new_port = new_port;

                new_port++;

                new_ports_settings += String.Format("IIS https binding will be reconfigured to listen on port {0}.\n", ret_new_port);
            }
        }

        static private bool is_port_in_use_by_iis(int port, bool secured, out String site_name, out String protocol_name)
        {
            bool vista_and_later = System.Environment.OSVersion.Version.Major >= 6;

            try
            {
                if (vista_and_later == false)
                    return do_with_port_iis6(secured, port, -1, out site_name, out protocol_name);
                else
                    return do_with_port_iis7(secured, port, -1, out site_name, out protocol_name);
            }
            catch
            {
                site_name = null;
                protocol_name = null;
                return false;
            }

        }

        static private bool add_iis_port(int port, String certificate_thumbprint, String site_name)
        {
            bool vista_and_later = System.Environment.OSVersion.Version.Major >= 6;

            try
            {
                if (vista_and_later == false)
                    return add_port_iis6(port, certificate_thumbprint, site_name);
                else
                    return add_port_iis7(port, certificate_thumbprint, site_name);
            }
            catch(Exception ex)
            {
                String all = ex.AllMessages();
                return false;
            }
        }

        static private bool remove_iis_port(bool secured, int port)
        {
            bool vista_and_later = System.Environment.OSVersion.Version.Major >= 6;

            try
            {
                if (vista_and_later == false)
                    return remove_port_iis6(secured, port);
                else
                    return remove_port_iis7(secured, port);
            }
            catch
            {
                return false;
            }
        }

        static private bool change_iis_port(bool secured, int old_port, int new_port)
        {
            // NOTE: IIS restart is required after calling this function

            bool vista_and_later = System.Environment.OSVersion.Version.Major >= 6;

            try
            {
                String site_name;
                String protocol_name;

                if (vista_and_later == false)
                    return do_with_port_iis6(secured, old_port, new_port, out site_name, out protocol_name);
                else
                    return do_with_port_iis7(secured, old_port, new_port, out site_name, out protocol_name);
            }
            catch
            {
                return false;
            }
        }

        static private bool do_with_port_iis6(bool secured, int old_port, int new_port, out String site_name, out String protocol_name)
        {
            protocol_name = null;
            String func_name;
            String log;
            if (new_port <= 0)
            {
                log = String.Format("\nSecured = {0}\nPort = {1}\n", secured, old_port);
                func_name = "is_port_in_use_by_iis6()";
            }
            else
            {
                log = String.Format("\nSecured = {0}\nOld Port = {1}\nNew Port = {2}", secured, old_port, new_port);
                func_name = "change_port_in_use_by_iis6()";
            }

            Log(func_name + " Started" + log);

            site_name = null;

            DirectoryEntry entry = new DirectoryEntry("IIS://LocalHost/W3SVC");

            if (entry == null)
            {
                Log(func_name + " Aborted");
                return false;
            }

            foreach (DirectoryEntry site in entry.Children)
            {
                if (site == null)
                    continue;

                if (site.SchemaClassName != "IIsWebServer")
                    continue;

                PropertyValueCollection ServerCommentProperty = site.Properties["ServerComment"];
                if (ServerCommentProperty != null)
                    site_name = (String)ServerCommentProperty.Value;

                PropertyValueCollection BindingsProperty = site.Properties[secured ? "SecureBindings" : "ServerBindings"];

                if (BindingsProperty == null)
                    continue;

                for (int idx = 0; idx < BindingsProperty.Count; idx++)
                {
                    String binding_information = (String)BindingsProperty[idx];

                    if ((String.IsNullOrEmpty(binding_information)) ||
                        (binding_information.IndexOf(String.Format(":{0}:", old_port)) == -1))
                    {
                        continue;
                    }

                    if (new_port > 0)
                    {
                        BindingsProperty[idx] = binding_information.Replace(String.Format(":{0}:", old_port), String.Format(":{0}:", new_port));
                        site.CommitChanges();
                    }

                    if (new_port <= 0)
                        Log(func_name + " Ended.\nPort in use.");
                    else
                        Log(func_name + " Ended.\nPort changed.");

                    return true;

                }
            }

            if (new_port <= 0)
                Log(func_name + " Ended.\nPort NOT in use");
            else
                Log(func_name + " Ended.\nPort change Failed.");

            return false;
        }

        static private bool add_port_iis6(int port, String certificate_thumbprint, String site_name)
        {
            // NOT YET IMPLEMENTED
            return false;
        }

        static private bool remove_port_iis6(bool secured, int port)
        {
            // NOT YET IMPLEMENTED
            return false;
        }

        static private bool do_with_port_iis7(bool secured, int old_port, int new_port, out String site_name, out String protocol_name)
        {
            protocol_name = null;
            String func_name;
            String log;
            if (new_port <= 0)
            {
                log = String.Format("\nSecured = {0}\nPort = {1}\n", secured, old_port);
                func_name = "is_port_in_use_by_iis7()";
            }
            else
            {
                log = String.Format("\nSecured = {0}\nOld Port = {1}\nNew Port = {2}", secured, old_port, new_port);
                func_name = "change_port_in_use_by_iis7()";
            }

            Log(func_name + " Started" + log);

            site_name = null;

            String protocol_to_check = secured ? "https" : "http";
            String protocol, binding_information;

            using (ServerManager serverManager = new ServerManager())
            {
                SiteCollection siteCollection = serverManager.Sites;

                foreach (Site site in siteCollection)
                {
                    site_name = site.Name;

                    foreach (Microsoft.Web.Administration.Binding binding in site.Bindings)
                    {
                        protocol = binding.Protocol;
                        binding_information = binding.BindingInformation;

#if BUGGY_IMPLEMENTATION
                        if ((protocol.Equals(protocol_to_check, StringComparison.OrdinalIgnoreCase) == false) ||
                            (String.IsNullOrEmpty(binding_information)) ||
                            (binding_information.IndexOf(String.Format(":{0}:", old_port)) == -1))
                        {
                            continue;
                        }
#else
                        if (//(protocol.Equals(protocol_to_check, StringComparison.OrdinalIgnoreCase) == false) ||
                            (String.IsNullOrEmpty(binding_information)) ||
                            (binding_information.IndexOf(String.Format(":{0}:", old_port)) == -1))
                        {
                            continue;
                        }

                        protocol_name = protocol.ToUpper();
#endif
                        if (new_port > 0)
                        {
                            binding.BindingInformation = binding_information.Replace(String.Format(":{0}:", old_port), String.Format(":{0}:", new_port));
                            serverManager.CommitChanges();
                        }

                        if (new_port <= 0)
                            Log(func_name + " Ended.\nPort in use.");
                        else
                            Log(func_name + " Ended.\nPort changed.");

                        return true;
                    }
                }

                if (new_port <= 0)
                    Log(func_name + " Ended.\nPort NOT in use");
                else
                    Log(func_name + " Ended.\nPort change failed.");

                return false;
            }
        }

        static private bool is_port_in_use_by_iis7(bool secured, int port)
        {
            String site_name, protocol_name;
            return do_with_port_iis7(secured, port, -1, out site_name, out protocol_name);
        }

        static private bool add_port_iis7(int port, String certificate_thumbprint, String site_name)
        {
            Log(String.Format("add_port_iis7() Started\nPort = {0}\nNCertificate = {1}\nSite = {2}", port, certificate_thumbprint, site_name));

            bool secured = String.IsNullOrWhiteSpace(certificate_thumbprint) == false;

            if (is_port_in_use_by_iis7(secured, port))
                return false;

            bool added = false;

            if(site_name != null)
                site_name = site_name.ToUpper();

            using (ServerManager serverManager = new ServerManager())
            {
                SiteCollection siteCollection = serverManager.Sites;

                foreach (Site site in siteCollection)
                {
                    if (site_name != null && site.Name.ToUpper() != site_name)
                        continue;

                    String bindingInformation = String.Format("*:{0}:", port); // "*:445:"
                    Microsoft.Web.Administration.Binding new_binding = null;

                    byte[] certificateHash = null;
                    String certificateStoreName = null;

                    if (certificate_thumbprint != null)
                    {
                        certificateHash = StringHelper.HexStringToBytes(certificate_thumbprint);
                        certificateStoreName = "MY";// "Local Computer/Personal";

                        new_binding = site.Bindings.Add(bindingInformation, certificateHash, certificateStoreName);
                    }
                    else
                    {
                        new_binding = site.Bindings.Add(bindingInformation, http);
                    }

                    try
                    {
                        serverManager.CommitChanges();
                    }
                    catch (System.Exception ex)
                    {
                        if(certificate_thumbprint == null || !(ex is System.Runtime.InteropServices.COMException))
                            throw ex;

                        new_binding.CertificateHash = certificateHash;
                        new_binding.CertificateStoreName = certificateStoreName;

                        serverManager.CommitChanges();
                    }

                    added = true;

                    break;
                }
            }

            Log(String.Format("add_port_iis7() Done"));

            return added;
        }

        static private bool remove_port_iis7(bool secured, int port)
        {
            Log(String.Format("remove_port_iis7() Started\nPort = {0}", port));

            if (is_port_in_use_by_iis7(secured, port) == false)
                return false;

            bool removed = false;

            String site_name;
            String binding_information;

            using (ServerManager serverManager = new ServerManager())
            {
                SiteCollection siteCollection = serverManager.Sites;

                Microsoft.Web.Administration.Binding binding_to_be_removed = null;
                Site binding_site = null;

                foreach (Site site in siteCollection)
                {
                    site_name = site.Name;

                    foreach (Microsoft.Web.Administration.Binding binding in site.Bindings)
                    {
                        binding_information = binding.BindingInformation;

                        if ((String.IsNullOrEmpty(binding_information)) ||
                            (binding_information.IndexOf(String.Format(":{0}:", port)) == -1))
                        {
                            continue;
                        }

                        binding_to_be_removed = binding;
                        binding_site = site;
                        removed = true;

                        break;
                    }

                    if(removed)
                        break;
                }

                if (removed)
                {
                    binding_site.Bindings.Remove(binding_to_be_removed);
                    serverManager.CommitChanges();
                }
            }

            Log(String.Format("remove_port_iis7() Done"));

            return removed;
        }

        static private IntPtr GetMsiexecWindow()
        {
            Process[] localByName = Process.GetProcessesByName("msiexec");
            IntPtr msiexec_wnd = IntPtr.Zero;
            bool found_msiexec_wnd = false;

            foreach (Process p in localByName)
            {
                if (p.MainWindowHandle != IntPtr.Zero)
                {
                    if (found_msiexec_wnd)	// more than one window. can't know which is the correct one.
                    {
                        msiexec_wnd = IntPtr.Zero;
                        break;
                    }

                    msiexec_wnd = p.MainWindowHandle;
                    found_msiexec_wnd = true;
                }
            }

            return msiexec_wnd;
        }

        class MsiexecWindow : IWin32Window
        {
            IntPtr m_handle = IntPtr.Zero;

            public MsiexecWindow()
            {
                m_handle = GetMsiexecWindow();
            }

            public IntPtr Handle { get { return m_handle; } }
        }

        static private bool StoreValue(ref XmlNode section, String key_name, String key_value)
        {
            XmlNodeList list = section.ChildNodes;

            if (list != null && list.Count > 0)
            {
                foreach (XmlNode n in list)
                {
                    if (n.NodeType != XmlNodeType.Element)
                    {
                        Debugger.Assert(n.NodeType == XmlNodeType.Comment);
                        continue;
                    }

                    if (n.Attributes[0].Value.Trim().Equals(key_name, StringComparison.OrdinalIgnoreCase))
                    {
                        n.Attributes[1].Value = key_value;
                        return true;
                    }
                }
            }

            return false;
        }

        static private void Log(String text)
        {
            if (File.Exists("c:\\debug_esg_install") == false)
                return;

            MessageBox.Show(new MsiexecWindow(), text, String.Format("{0} Installer", ComponentName));
        }

        static private readonly String  IISSettingsConfigFile = "iis_orig_settings.txt";
        static private readonly char    IISSettingsSplitChar = ':';

        static private String ComponentName;
        static private String ConfigFile;
        static private String LockFile;

    }
}
