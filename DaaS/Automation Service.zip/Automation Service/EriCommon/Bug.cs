﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EriCommon
{
    public class Bug
    {
        public /*abstract*/ class Base
        {
            public Base()
            {
            }

            public void SetEmpty(bool value)
            {
                m_is_empty = value;
            }

            public bool Empty
            {
                get
                {
                    return m_is_empty;
                }

                set
                {
                    m_is_empty = value;
                }
            }

            public bool m_is_empty = true;
        }

        public class Derived<T> : Base
        {
            public Derived()
            {
            }

            public void LookAtTheBug()
            {
                Empty = false;

                if (m_is_empty)
                {
                    m_is_empty = false;
                    m_is_empty = true;
                }
            }

            public T GetValue()
            {
                Debug.Assert(Empty == false);  // this value was not set
                Empty = true;
                return m_value;
            }

            public void SetValue(T value)
            {
                Debug.Assert(Empty == true);   // this value is already set
                Empty = false;
                SetEmpty(false);

                Debug.Assert(Empty == false);   // this value is already set
                m_value = value;
            }

            public T Value
            {
                get
                {
                    return GetValue();
                }

                set
                {
                    SetValue(value);
                }
            }

            internal virtual void Set(object obj)
            {
                SetValue( (T)obj );
            }

            private T m_value;
        }

        public class DerivedLong : Derived<long>
        {
        }

        public static void Demo()
        {
            Derived<long> d = new Derived<long>();

            d.m_is_empty = false;

            if (d.m_is_empty == false)
            {
                d.m_is_empty = true;
            }

            d.LookAtTheBug();

            long v = 1234567890;

            d.Set(v);
        }
    }
}
