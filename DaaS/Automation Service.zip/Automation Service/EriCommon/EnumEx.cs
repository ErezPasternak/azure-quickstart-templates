﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Threading;
using System.Security.Cryptography;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ComponentModel;
using TracerX;

namespace EriCommon
{
    /// <summary>
    /// The EnumEx static class contains static methods extending the Enum class.
    /// </summary>
    public static class EnumEx
    {
        /// <summary>
        /// Parse
        /// </summary>
        public static T Parse<T>(string value, T? defval, out Exception e, Logger logger = null, bool ignoreCase = true) where T : struct
        {
            e = null;

            try
            {
                return (T)Enum.Parse(typeof(T), value, ignoreCase);
            }
            catch (System.Exception ex)
            {
                e = ex;

                if (defval == null)
                    throw ex;

                if (logger == null)
                    logger = Logger.Current;

                if (logger != null && logger.BinaryFileTraceLevel >= TracerX.TraceLevel.Warn)
                {
                    String type_name = typeof(T).ToString();
                    String text = String.Format("Unable to convert '{0}' to {1} enumeration.\n{2}\nThe default '{3}' value will be used.",
                                                value,
                                                type_name,
                                                ex.AllMessages(),
                                                defval.ToString());

                    if (logger.BinaryFileTraceLevel >= TracerX.TraceLevel.Debug)
                    {
                        logger.WarnFormat("{0}\n{1}", text, ex.StackTrace);
                    }
                    else
                    {
                        logger.Warn(text);
                    }
                }

            }

            return (T)defval;
        }

        /// <summary>
        /// Parse
        /// </summary>
        public static T Parse<T>(string value, T? defval, Logger logger = null, bool ignoreCase = true) where T : struct
        {
            Exception e;
            return Parse<T>(value, defval, out e, logger, ignoreCase);
        }

        /// <summary>
        /// TryParse
        /// </summary>
        public static bool TryParse<T>(string value, T defval, out T result, out Exception e, Logger logger = null, bool ignoreCase = true) where T : struct
        {
            result = Parse<T>(value, defval, out e, logger, ignoreCase);
            return e == null;
        }

        /// <summary>
        /// TryParse
        /// </summary>
        public static bool TryParse<T>(string value, T defval, out T result, Logger logger = null, bool ignoreCase = true) where T : struct
        {
            Exception e;
            return TryParse<T>(value, defval, out result, out e, logger, ignoreCase);
        }

        /// <summary>
        /// GetDescription
        /// </summary>
        public static String GetDescription<T>(T enumeratedType)
        {
            string value = enumeratedType.ToString();
            Type type = typeof(T);
            var name = Enum.GetNames(type).Where(f => f.Equals(value, StringComparison.CurrentCultureIgnoreCase)).Select(d => d).FirstOrDefault();

            if (name == null)
                return string.Empty;

            var field = type.GetField(name);
            var customAttribute = field.GetCustomAttributes(typeof(DescriptionAttribute), false);
            return customAttribute.Length > 0 ? ((DescriptionAttribute)customAttribute[0]).Description : name;
        }
    }
}
