﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Net.Sockets;
using System.Net.Security;
using System.Security;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using TracerX;

namespace EriCommon
{
    public partial class SslStreamEx_OLD
    {
        /// <summary>
        /// The TestType enum.
        /// </summary>
        public enum TestType
        {
            /// <summary>
            /// The Loop enum.
            /// </summary>
            Loop = 0,
            /// <summary>
            /// The ReadMultipleChuncks enum.
            /// </summary>
            ReadMultipleChuncks,
        }

        /// <summary>
        /// The Test method.
        /// </summary>

        public static void Test(TestType tt)
        {
            switch (tt)
            {
                case TestType.Loop:                 Test_Loop();
                                                    break;
                case TestType.ReadMultipleChuncks:  Test_ReadMultipleChuncks();
                                                    break;
            }
        }

        private static void Test_ReadMultipleChuncks()
        {
            sm_test_synch_begin = new ManualResetEvent(false);
            sm_test_synch_end = new ManualResetEvent(false);
            sm_test_synch_begin_read = new ManualResetEvent(false);
            ThreadHelper.Create("Server", Test_ReadMultipleChuncks_server_main, true, ThreadHelper.Mode.Foreground);
            ThreadHelper.Create("Client", Test_ReadMultipleChuncks_client_main, true, ThreadHelper.Mode.Foreground);
            sm_test_synch_end.WaitOne();
        }

        private const int TEST_ReadMultipleChuncks_BUFFER_SIZE = 1024 * 1024 * 16;

        static void Test_ReadMultipleChuncks_server_main()
        {
            try
            {
                Logger.Root.Info("Getting server certificate");
                X509Certificate2 server_certificate = CertificateManager.Instance.LoadOrGenerateCertificate(null, ref sm_generated_certificate_subject);

                if (String.IsNullOrWhiteSpace(sm_generated_certificate_subject))
                    sm_generated_certificate_subject = CertificateManager.DefaultCertificateSubject;

                TcpListener tcp_listener = new TcpListener(IPAddress.Loopback, 0);

                tcp_listener.Start();

                sm_test_port = ((IPEndPoint)tcp_listener.LocalEndpoint).Port;

                Logger.Root.Info("Listening on port ", sm_test_port);

                sm_test_synch_begin.Set();

                TcpClient client = tcp_listener.AcceptTcpClient();

                Logger.Root.Info("Client accepted");

                NetworkStream network_stream = client.GetStream();
                SslStreamEx_OLD ssl_stream = new SslStreamEx_OLD(network_stream, false, new TestOwner());

                Logger.Root.Info("Processing SSL authentication");
                ssl_stream.AuthenticateAsServer(server_certificate);
                Logger.Root.Info("SSL authentication done");

                byte[] buffer = new byte[TEST_ReadMultipleChuncks_BUFFER_SIZE];
                st_test_bytes_sent = 0;

                sm_test_synch_begin_read.Set();

                for (int n_bytes = 1; n_bytes < TEST_ReadMultipleChuncks_BUFFER_SIZE; n_bytes = (n_bytes * 7) / 3)
                {
                    st_test_bytes_sent += (UInt64)n_bytes;
                    Logger.Root.Info("Sending ", n_bytes, " bytes");
                    ssl_stream.Write(buffer, 0, n_bytes);
                    Logger.Root.Info(n_bytes, " bytes sent");
                    //Thread.Sleep(5000);
                }

                Logger.Root.Info("TOTAL BYTES SENT: ", st_test_bytes_sent);

                st_test_done = true;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            finally
            {
                st_test_done = true;
                sm_test_synch_begin.Set();
            }
        }

        static void Test_ReadMultipleChuncks_client_main()
        {
            try
            {
                sm_test_synch_begin.WaitOne();

                Logger.Root.Info("Connecting to port ", sm_test_port);
                TcpClient client = new TcpClient("localhost", sm_test_port);
                NetworkStream network_stream = client.GetStream();
                SslStreamEx_OLD ssl_stream = new SslStreamEx_OLD(network_stream, false, new RemoteCertificateValidationCallback(ValidateServerCertificate), null, new TestOwner());

                Logger.Root.Info("Processing SSL authentication");
                ssl_stream.AuthenticateAsClient(sm_generated_certificate_subject);
                Logger.Root.Info("SSL authentication done");

                sm_test_synch_begin_read.WaitOne();

                byte[] buffer = new byte[TEST_ReadMultipleChuncks_BUFFER_SIZE];
                client.ReceiveBufferSize = buffer.Length;

                UInt64 total_bytes_read = 0;

                while (st_test_done == false || st_test_bytes_sent > total_bytes_read)
                {
                    Thread.Sleep(100);
                    int n_bytes = asynch_read(ssl_stream, buffer, 0, TEST_ReadMultipleChuncks_BUFFER_SIZE);
                    total_bytes_read += (UInt64)n_bytes;
                    Logger.Root.Info(n_bytes, " bytes received, total received=", total_bytes_read, ", pending=", st_test_bytes_sent - total_bytes_read);
                }
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            finally
            {
                sm_test_synch_end.Set();
            }
        }

        private static void Test_Loop()
        {
            sm_test_synch_begin = new ManualResetEvent(false);
            sm_test_synch_end = new ManualResetEvent(false);
            ThreadHelper.Create("Server", Test_Loop_server_main, true, ThreadHelper.Mode.Foreground);
            ThreadHelper.Create("Client", Test_Loop_client_main, true, ThreadHelper.Mode.Foreground);
        }

        private const int TEST_Loop_BUFFER_SIZE = 10000;//1024 * 128;
        private const int LOOP_MAX_COUNT = 10000;

        static void Test_Loop_server_main()
        {
            try
            {
                Logger.Root.Info("Getting server certificate");
                X509Certificate2 server_certificate = CertificateManager.Instance.LoadOrGenerateCertificate(null, ref sm_generated_certificate_subject);

                TcpListener tcp_listener = new TcpListener(IPAddress.Loopback, 0);

                tcp_listener.Start();

                sm_test_port = ((IPEndPoint)tcp_listener.LocalEndpoint).Port;

                Logger.Root.Info("Listening on port ", sm_test_port);

                sm_test_synch_begin.Set();

                TcpClient client = tcp_listener.AcceptTcpClient();

                Logger.Root.Info("Client accepted");

                NetworkStream network_stream = client.GetStream();
                SslStreamEx_OLD ssl_stream = new SslStreamEx_OLD(network_stream, false, new TestOwner());

                Logger.Root.Info("Processing SSL authentication");
                ssl_stream.AuthenticateAsServer(server_certificate);
                Logger.Root.Info("SSL authentication done");

                byte[] buffer = new byte[TEST_Loop_BUFFER_SIZE];

                int counter;
                for (counter = 0; counter < LOOP_MAX_COUNT; counter++)
                {
                    Thread.Sleep(5000);

                    Logger.Root.Info("Sending ", buffer.Length, " bytes");
                    ssl_stream.Write(buffer, 0, buffer.Length);
                    Logger.Root.Info(buffer.Length, " bytes sent");
                }

                sm_test_synch_end.WaitOne();
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            finally
            {
                sm_test_synch_begin.Set();
            }
        }

        static void Test_Loop_client_main()
        {
            try
            {
                sm_test_synch_begin.WaitOne();

                Logger.Root.Info("Connecting to port ", sm_test_port);
                TcpClient client = new TcpClient("localhost", sm_test_port);
                NetworkStream network_stream = client.GetStream();
                SslStreamEx_OLD ssl_stream = new SslStreamEx_OLD(network_stream, false, new RemoteCertificateValidationCallback(ValidateServerCertificate), null, new TestOwner());

                Logger.Root.Info("Processing SSL authentication");
                ssl_stream.AuthenticateAsClient(sm_generated_certificate_subject);
                Logger.Root.Info("SSL authentication done");

                byte[] buffer = new byte[TEST_Loop_BUFFER_SIZE];

                int counter;
                for (counter = 0; counter < LOOP_MAX_COUNT; counter++)
                {
                    int n_bytes = 0;

                    for (int idx = 0; idx < buffer.Length; idx += n_bytes)
                    {
                        int bytes_to_read = 1024;
                        if (buffer.Length - idx < bytes_to_read)
                            bytes_to_read = buffer.Length - idx;

                        n_bytes = asynch_read(ssl_stream, buffer, idx, bytes_to_read);
                    }
                }
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            finally
            {
                sm_test_synch_end.Set();
            }
        }

        class TestOwner : IOwner
        {
            #region IOwner Members

            public byte[] GetWriteBuffer(uint size, ref object asyncState)
            {
                return (byte[])asyncState;
            }

            public void OnReadyToWriteOnOuterStream(object asyncState)
            {
            }

            #endregion
        }

        private static int asynch_read(SslStreamEx_OLD ssl_stream, byte[] buffer, int offset, int count)
        {
//            Logger.Root.Info("Trying to read ", count, " bytes at #", offset);
            IAsyncResult result = ssl_stream.BeginRead(buffer, offset, count, null, buffer);
            System.Threading.WaitHandle wait_handle = result.AsyncWaitHandle;
            wait_handle.WaitOne();
            int n;

            n = ssl_stream.EndRead(result);

//            Logger.Root.Info(n, " bytes read");

            return n;
        }

        private static bool ValidateServerCertificate(object sender,
                                                      X509Certificate certificate,
                                                      X509Chain chain,
                                                      SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }

        private static ManualResetEvent sm_test_synch_begin,
                                        sm_test_synch_end,
                                        sm_test_synch_begin_read;
        private static UInt64           st_test_bytes_sent;
        private static bool             st_test_done;
        private static int              sm_test_port;
        private static String           sm_generated_certificate_subject;
    }
}
