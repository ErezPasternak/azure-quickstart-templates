﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace EriCommon
{
    /// <summary>
    /// The HexaDump class ....
    /// </summary>
    public class HexaDump
    {
        /// <summary>
        /// Converts binary data to a hexa dump string, every 16 bytes on a separate line
        /// </summary>
        public static string Convert(byte[] buffer, UInt32 offset, UInt32 length)
        {
            StringWriter writer = new StringWriter();
            HexaDump hexa_dump = new HexaDump(writer);
            hexa_dump.Write(buffer, offset, length);

            return writer.ToString();
        }

        /// <summary>
        /// Converts binary data to a hexa dump string, every 16 bytes on a separate line
        /// </summary>
        public static string Convert(byte[] buffer)
        {
            return Convert(buffer, 0, (UInt32)buffer.Length);
        }

        /// <summary>
        /// HexaDump ctor.
        /// </summary>
        public HexaDump(TextWriter writer)
        {
            Debug.Assert(writer != null);
            m_writer = writer;
        }

        /// <summary>
        /// Writes a new chunk of binary data to the writer.
        /// </summary>
        public void Write(byte[] buffer, UInt32 offset, UInt32 length)
        {
            Debug.Assert(buffer != null);

            if (offset >= buffer.Length)
            {
                Debug.Assert(false);
                return;
            }

            if (buffer.Length < offset + length)
            {
                Debug.Assert(false);
                length = (UInt32)buffer.Length - offset;
            }

            UInt32 index = 0;

            while (length >= FULL_LINE_SIZE)
            {
                write_full_line(buffer, index, offset);
                offset += FULL_LINE_SIZE;
                index += FULL_LINE_SIZE;
                length -= FULL_LINE_SIZE;
            }

            if (length == 0)
                return;

            write_partial_line(buffer, index, offset, length);
        }

        private const UInt32 FULL_LINE_SIZE = 16;

        private void write_full_line(byte[] buffer, UInt32 index, UInt32 offset)
        {
            //"%04X: %02X %02X %02X %02X  %02X %02X %02X %02X  %02X %02X %02X %02X  %02X %02X %02X %02X |%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c|"
            string line = string.Format("{0:X4}: {1:X2} {2:X2} {3:X2} {4:X2}  {5:X2} {6:X2} {7:X2} {8:X2} {9:X2} {10:X2} {11:X2} {12:X2}  {13:X2} {14:X2} {15:X2} {16:X2} |{17}{18}{19}{20}{21}{22}{23}{24}{25}{26}{27}{28}{29}{30}{31}{32}|",
                                         index,
                                         buffer[offset + 0],
                                         buffer[offset + 1],
                                         buffer[offset + 2],
                                         buffer[offset + 3],
                                         buffer[offset + 4],
                                         buffer[offset + 5],
                                         buffer[offset + 6],
                                         buffer[offset + 7],
                                         buffer[offset + 8],
                                         buffer[offset + 9],
                                         buffer[offset + 10],
                                         buffer[offset + 11],
                                         buffer[offset + 12],
                                         buffer[offset + 13],
                                         buffer[offset + 14],
                                         buffer[offset + 15],
                                         b2c(buffer[offset + 0]),
                                         b2c(buffer[offset + 1]),
                                         b2c(buffer[offset + 2]),
                                         b2c(buffer[offset + 3]),
                                         b2c(buffer[offset + 4]),
                                         b2c(buffer[offset + 5]),
                                         b2c(buffer[offset + 6]),
                                         b2c(buffer[offset + 7]),
                                         b2c(buffer[offset + 8]),
                                         b2c(buffer[offset + 9]),
                                         b2c(buffer[offset + 10]),
                                         b2c(buffer[offset + 11]),
                                         b2c(buffer[offset + 12]),
                                         b2c(buffer[offset + 13]),
                                         b2c(buffer[offset + 14]),
                                         b2c(buffer[offset + 15]));

            m_writer.WriteLine(line);
        }

        private void write_partial_line(byte[] buffer, UInt32 index, UInt32 offset, UInt32 length)
        {
            string line = string.Format("{0:X4}: {1} {2} {3} {4}  {5} {6} {7} {8} {9} {10} {11} {12}  {13} {14} {15} {16} |{17}{18}{19}{20}{21}{22}{23}{24}{25}{26}{27}{28}{29}{30}{31}{32}|",
                                         index,
                                         b2x(buffer, offset, length, 0),
                                         b2x(buffer, offset, length, 1),
                                         b2x(buffer, offset, length, 2),
                                         b2x(buffer, offset, length, 3),
                                         b2x(buffer, offset, length, 4),
                                         b2x(buffer, offset, length, 5),
                                         b2x(buffer, offset, length, 6),
                                         b2x(buffer, offset, length, 7),
                                         b2x(buffer, offset, length, 8),
                                         b2x(buffer, offset, length, 9),
                                         b2x(buffer, offset, length, 10),
                                         b2x(buffer, offset, length, 11),
                                         b2x(buffer, offset, length, 12),
                                         b2x(buffer, offset, length, 13),
                                         b2x(buffer, offset, length, 14),
                                         b2x(buffer, offset, length, 15),
                                         b2c(buffer, offset, length, 0),
                                         b2c(buffer, offset, length, 1),
                                         b2c(buffer, offset, length, 2),
                                         b2c(buffer, offset, length, 3),
                                         b2c(buffer, offset, length, 4),
                                         b2c(buffer, offset, length, 5),
                                         b2c(buffer, offset, length, 6),
                                         b2c(buffer, offset, length, 7),
                                         b2c(buffer, offset, length, 8),
                                         b2c(buffer, offset, length, 9),
                                         b2c(buffer, offset, length, 10),
                                         b2c(buffer, offset, length, 11),
                                         b2c(buffer, offset, length, 12),
                                         b2c(buffer, offset, length, 13),
                                         b2c(buffer, offset, length, 14),
                                         b2c(buffer, offset, length, 15));

            m_writer.WriteLine(line);
        }

        private bool isprint(char c)
        {
            return !(c < 0x20 || c > 127);
        }

        private char b2c(byte b)
        {
            char c = (char)b;

            if (isprint(c) == false)
                c = '.';

            return c;
        }

        private char b2c(byte[] buffer, UInt32 offset, UInt32 length, int add)
        {
            return (length > add) ? b2c(buffer[offset + add]) : '\x20';
        }

        private string b2x(byte[] buffer, UInt32 offset, UInt32 length, int add)
        {
            return (length > add) ? buffer[offset + add].ToString("X2") : "\x20\x20";
        }

        private TextWriter m_writer;
    }
}
