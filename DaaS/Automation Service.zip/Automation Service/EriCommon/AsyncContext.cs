﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;

namespace EriCommon
{
    /// <summary>
    /// The AsyncContext abstract class.
    /// </summary>
    public abstract class AsyncContext : IAsyncResult
    {
        /// <summary>
        /// The AsyncContext CTOR.
        /// </summary>
        public AsyncContext(AsyncCallback callback, object state)
        {
            m_reset_at_end = false;
            Set(callback, state);
        }

        /// <summary>
        /// YOCHAI!!!
        /// </summary>
        public AsyncContext()
        {
            m_reset_at_end = true;
            Set(null, null);
        }

        /// <summary>
        /// YOCHAI!!!
        /// </summary>
        public void Set(AsyncCallback callback, object state)
        {
            m_callback = callback;
            m_state = state;
        }

        /// <summary>
        /// The BeginInvoke method.
        /// </summary>
        public IAsyncResult BeginInvoke()
        {
            Debug.Assert(m_busy == false);
            m_busy = true;
            m_invoke_ar = sm_delegate.BeginInvoke(this, sm_invoke_callback, this);
            return this;
        }

        /// <summary>
        /// The EndInvoke method.
        /// </summary>
        public void EndInvoke()
        {
            Debug.Assert(m_busy);
            m_busy = false;

            sm_delegate.EndInvoke(m_invoke_ar);

            if (m_reset_at_end)
                Set(null, null);
        }

        #region IAsyncResult Members

        // GENERIC CODE
        object IAsyncResult.AsyncState
        {
            get { return m_state; }
        }

        // GENERIC CODE
        WaitHandle IAsyncResult.AsyncWaitHandle
        {
            get { return m_invoke_ar.AsyncWaitHandle; }
        }

        // GENERIC CODE
        bool IAsyncResult.CompletedSynchronously
        {
            get { return m_invoke_ar.CompletedSynchronously; }
        }

        // GENERIC CODE
        bool IAsyncResult.IsCompleted
        {
            get { return m_invoke_ar.IsCompleted; }
        }
        #endregion

        delegate void DelegateT(AsyncContext ctx);
        static DelegateT sm_delegate = new DelegateT(delegate_func);
        static AsyncCallback sm_invoke_callback = new AsyncCallback(my_callback);

        /// <summary>
        /// </summary>
        protected abstract void proceed();

        private static void delegate_func(AsyncContext ctx)
        {
            ctx.proceed();
        }

        private static void my_callback(IAsyncResult ar)
        {
            AsyncContext ctx = (AsyncContext)ar.AsyncState;
            ctx.m_callback(ctx);
        }

        readonly bool m_reset_at_end;

        // Input data
        private AsyncCallback m_callback;
        private object m_state;
        private bool m_busy = false;

        // Internal data
        private IAsyncResult m_invoke_ar;
    }
}
