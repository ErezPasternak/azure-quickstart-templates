﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Security;
using System.IO;
using System.Net.Sockets;
using System.Diagnostics;
using System.Security.Cryptography.X509Certificates;
using System.Security.Authentication;
using System.Threading;
using System.Threading.Tasks;

namespace EriCommon
{
    /// <summary>
    /// A SslStream class wrapper which provides enhanced read and write capabilities (not limited to 16KB)
    /// </summary>
    public partial class SslStreamEx : SslStream
    {
        private readonly bool           m_enhanced;
        private readonly NetworkStream  m_network_stream;
        private readonly MemStream      m_inner_stream;
        private byte[]                  m_read_buffer;
        private int                     m_read_offset;
        private int                     m_read_count;

#if DEBUG
        private bool m_busy_read  = true;   // will be set to false when authenticated
        private bool m_busy_write = true;   // will be set to false when authenticated
#endif //DEBUG

        /// <summary>
        /// The SslStreamEx constructor.
        /// </summary>
        public SslStreamEx(Stream innerStream, bool enhanced = true)
            : base(enhanced ? new MemStream(innerStream) : innerStream)
        {
            init(enhanced, innerStream, out m_enhanced, out m_network_stream, out m_inner_stream);
        }

        /// <summary>
        /// The SslStreamEx constructor.
        /// </summary>
        public SslStreamEx(Stream innerStream, bool leaveInnerStreamOpen, bool enhanced = true)
            : base(enhanced ? new MemStream(innerStream) : innerStream, leaveInnerStreamOpen)
        {
            init(enhanced, innerStream, out m_enhanced, out m_network_stream, out m_inner_stream);
        }

        /// <summary>
        /// The SslStreamEx constructor.
        /// </summary>
        public SslStreamEx(Stream innerStream, bool leaveInnerStreamOpen, RemoteCertificateValidationCallback userCertificateValidationCallback, bool enhanced = true)
            : base(enhanced ? new MemStream(innerStream) : innerStream, leaveInnerStreamOpen, userCertificateValidationCallback)
        {
            init(enhanced, innerStream, out m_enhanced, out m_network_stream, out m_inner_stream);
        }

        /// <summary>
        /// The SslStreamEx constructor.
        /// </summary>
        public SslStreamEx(Stream innerStream, bool leaveInnerStreamOpen, RemoteCertificateValidationCallback userCertificateValidationCallback, LocalCertificateSelectionCallback userCertificateSelectionCallback, bool enhanced = true)
            : base(enhanced ? new MemStream(innerStream) : innerStream, leaveInnerStreamOpen, userCertificateValidationCallback, userCertificateSelectionCallback)
        {
            init(enhanced, innerStream, out m_enhanced, out m_network_stream, out m_inner_stream);
        }

        /// <summary>
        /// The SslStreamEx constructor.
        /// </summary>
        public SslStreamEx(Stream innerStream, bool leaveInnerStreamOpen, RemoteCertificateValidationCallback userCertificateValidationCallback, LocalCertificateSelectionCallback userCertificateSelectionCallback, EncryptionPolicy encryptionPolicy, bool enhanced = true)
            : base(enhanced ? new MemStream(innerStream) : innerStream, leaveInnerStreamOpen, userCertificateValidationCallback, userCertificateSelectionCallback, encryptionPolicy)
        {
            init(enhanced, innerStream, out m_enhanced, out m_network_stream, out m_inner_stream);
        }

        private void init(bool enhanced, Stream innerStream, out bool _enhanced, out NetworkStream _network_stream, out MemStream _inner_stream)
        {
            _enhanced  = enhanced;

            if (enhanced)
            {
                _network_stream = innerStream is NetworkStream ? (NetworkStream)innerStream : null;
                _inner_stream   = (MemStream)InnerStream;
            }
            else
            {
                _network_stream = null;
                _inner_stream   = null;
            }
        }

        /// <summary>
        /// YOCHAI
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (m_inner_stream == null || LeaveInnerStreamOpen)
                return;

            m_inner_stream.Dispose();
        }

        /// <summary>
        /// YOCHAI
        /// </summary>
        public static int GetEncryptedSize(int count)
        {
            return MemStream.GetEncryptedSize(count);
        }

        /// <summary>
        /// YOCHAI
        /// </summary>
        public void SetWriteBufferSize(int count)
        {
            if (m_enhanced)
                m_inner_stream.SetWriteBufferSize(count, false);
        }

        #region Read overrides

        // We override the Read functions because SslStream will only return maximum of 16 KB (SSL chunk size) in a single read operation.

        /// <summary>
        /// The ReadAsync method.
        /// </summary>
        public override Task<int> ReadAsync(byte[] buffer, int offset, int count, CancellationToken cancellationToken = default(CancellationToken))
        {
            return Task<int>.Factory.FromAsync(BeginRead, EndRead, buffer, offset, count, null);
        }

        /// <summary>
        /// The Read method.
        /// </summary>
        public override int Read(byte[] buffer, int offset, int count)
        {
#if DEBUG
            Debugger.Assert(m_busy_read == false);
            m_busy_read = true;
#endif //DEBUG

            int bytesRead = base.Read(buffer, offset, count);

            if (m_enhanced)
            {
                int current_offset  = offset + bytesRead;
                int max_read_offset = offset + count;

                readMore(buffer, current_offset, max_read_offset, ref bytesRead);
            }

#if DEBUG
            Debugger.Assert(m_busy_read);
            m_busy_read = false;
#endif //DEBUG

            return bytesRead;
        }

        /// <summary>
        /// The BeginRead method.
        /// </summary>
        public override IAsyncResult BeginRead(byte[] buffer, int offset, int count, AsyncCallback asyncCallback, Object asyncState)
        {
#if DEBUG
            Debugger.Assert(m_busy_read == false);
            m_busy_read = true;
#endif //DEBUG

            if (m_enhanced)
            {
                m_read_buffer = buffer;
                m_read_offset = offset;
                m_read_count = count;
            }

            return base.BeginRead(buffer, offset, count, asyncCallback, asyncState);
        }

        /// <summary>
        /// The EndRead method.
        /// </summary>
        public override int EndRead(IAsyncResult asyncResult)
        {
#if DEBUG
            Debugger.Assert(m_busy_read == true);
#endif //DEBUG

            int bytesRead = base.EndRead(asyncResult);

            if (m_enhanced)
            {
                int current_offset  = m_read_offset + bytesRead;
                int max_read_offset = m_read_offset + m_read_count;

                readMore(m_read_buffer, current_offset, max_read_offset, ref bytesRead);

                Debugger.Assert(bytesRead <= m_read_count);
            }

#if DEBUG
            m_busy_read = false;
#endif //DEBUG

            return bytesRead;
        }

        private void readMore(byte[] buffer, int current_offset, int max_read_offset, ref int bytesRead)
        {
            int temp;

//          According to the research of EYAL, the TRY block is unnecessary
//             try
//             {
                while ((current_offset < max_read_offset) && DataAvailable)
                {
                    temp = base.Read(buffer, current_offset, max_read_offset - current_offset);

                    if (temp == 0)
                        break;

                    bytesRead += temp;
                    current_offset += temp;
                }
//             }
//             catch (System.Exception ex)
//             {
//             	if (ex is IOException)
//                     return;
//
//                 throw ex;
//             }
        }

        private bool DataAvailable
        {
            get
            {
                Debugger.Assert(m_network_stream != null);

                // MSDN:  If DataAvailable is true, a call to Read returns immediately!
                return m_network_stream != null ? m_network_stream.DataAvailable : false;
            }
        }

        #endregion Read overrides

        #region Write overrides

        // We override the Write functions because SslStream will fragment the buffer into many small writes on the inner stream.

        /// <summary>
        /// The WriteAsync method.
        /// </summary>
        public override Task WriteAsync(byte[] buffer, int offset, int count, CancellationToken cancellationToken = default(CancellationToken))
        {
            return Task.Factory.FromAsync(BeginWrite, EndWrite, buffer, offset, count, null);
        }

        /// <summary>
        /// The Write method.
        /// </summary>
        public override void Write(byte[] buffer, int offset, int count)
        {
#if DEBUG
            Debugger.Assert(m_busy_write == false);
            m_busy_write = true;
#endif //DEBUG

            if (m_enhanced)
            {
                //Console.Write("BeginWrite: {0} ==> ", count);

                m_inner_stream.SetWriteBufferSize(count);
                base.Write(buffer, offset, count);      // SslStream will call m_inner_stream.Write() in a loop, breaking the original buffer to small encrypted chunks. Instead of writing the chunk, m_inner_stream will not just accumulate it into a single buffer.
                m_inner_stream.FlushToOuterStream();    // now synchronously write the accumulated buffer in a single operation.
            }
            else
            {
                base.Write(buffer, offset, count);
            }

#if DEBUG
            Debugger.Assert(m_busy_write);
            m_busy_write = false;
#endif //DEBUG
        }

        /// <summary>
        /// The BeginWrite method.
        /// </summary>
        public override IAsyncResult BeginWrite(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
        {
#if DEBUG
            Debugger.Assert(m_busy_write == false);
            m_busy_write = true;
#endif //DEBUG

            if (m_enhanced)
            {
                //Console.Write("BeginWrite: {0} ==> ", count);

                m_inner_stream.SetWriteBufferSize(count);
                base.Write(buffer, offset, count);                               // SslStream will call m_inner_stream.Write() in a loop, breaking the original buffer to small encrypted chunks. Instead of writing the chunk, m_inner_stream will not just accumulate it into a single buffer.
                return m_inner_stream.BeginFlushToOuterStream(callback, state);  // now asynchronously write the accumulated buffer in a single operation.
            }
            else
            {
                return base.BeginWrite(buffer, offset, count, callback, state);
            }
        }

        /// <summary>
        /// The EndWrite method.
        /// </summary>
        public override void EndWrite(IAsyncResult asyncResult)
        {
#if DEBUG
            Debugger.Assert(m_busy_write);
#endif //DEBUG

            if (m_enhanced)
            {
                m_inner_stream.EndWrite(asyncResult);
            }
            else
            {
                base.EndWrite(asyncResult);
            }

#if DEBUG
            m_busy_write = false;
#endif //DEBUG
        }

        #endregion Write overrides

        #region Authentication overrides

        // We override the BeginAuthenticateAs() functions because they do not release the asyncState parameter passed to them.

        private class AuthenticateContext : IAsyncResult
        {
            public static AsyncCallback sm_Callback;

            public AuthenticateContext(AsyncCallback asyncCallback, object asyncState)
            {
                m_asyncCallback = asyncCallback;
                m_asyncState = asyncState;
            }

            static AuthenticateContext()
            {
                sm_Callback = new AsyncCallback(Callback);
            }

            private static void Callback(IAsyncResult ar)
            {
                AuthenticateContext me = (AuthenticateContext)ar.AsyncState;
                me.m_ar = ar;
                if (me.m_asyncCallback != null)
                    me.m_asyncCallback(me);
            }

            public IAsyncResult AsyncResult
            {
                get
                {
                    m_asyncCallback = null;
                    m_asyncState    = null;
                    return m_ar;
                }

                set
                {
                    m_ar = value;
                }
            }

            #region IAsyncResult Members

            public object AsyncState
            {
                get { return m_asyncState; }
            }

            public System.Threading.WaitHandle AsyncWaitHandle
            {
                get { return null;/*throw new NotImplementedException();*/ }
            }

            public bool CompletedSynchronously
            {
                get { return (m_ar == null) ? false : m_ar.CompletedSynchronously; }
            }

            public bool IsCompleted
            {
                get { return (m_ar == null) ? false : m_ar.IsCompleted; }
            }

            #endregion

            private AsyncCallback m_asyncCallback;
            private Object m_asyncState;
            private IAsyncResult m_ar = null;
        }

        /// <summary>
        /// The BeginAuthenticateAsServer method.
        /// </summary>
        public override IAsyncResult BeginAuthenticateAsServer(X509Certificate serverCertificate, AsyncCallback asyncCallback, object asyncState)
        {
            AuthenticateContext authenticate_context = new AuthenticateContext(asyncCallback, asyncState);
            IAsyncResult ret = base.BeginAuthenticateAsServer(serverCertificate, AuthenticateContext.sm_Callback, authenticate_context);

            if ((ret is AuthenticateContext) == false)
                authenticate_context.AsyncResult = ret;

            return authenticate_context;
        }

        /// <summary>
        /// The BeginAuthenticateAsServer method.
        /// </summary>
        public override IAsyncResult BeginAuthenticateAsServer(X509Certificate serverCertificate, bool clientCertificateRequired, SslProtocols enabledSslProtocols, bool checkCertificateRevocation, AsyncCallback asyncCallback, object asyncState)
        {
            // note: base class implementation of the first function overload is to call this function
            AuthenticateContext authenticate_context = asyncState is AuthenticateContext ? (AuthenticateContext)asyncState : new AuthenticateContext(asyncCallback, asyncState);
            IAsyncResult ret = base.BeginAuthenticateAsServer(serverCertificate, clientCertificateRequired, enabledSslProtocols, checkCertificateRevocation, AuthenticateContext.sm_Callback, authenticate_context);
            authenticate_context.AsyncResult = ret;

            return authenticate_context;
        }

        /// <summary>
        /// The EndAuthenticateAsServer method.
        /// </summary>
        public override void EndAuthenticateAsServer(IAsyncResult asyncResult)
        {
            AuthenticateContext authenticate_context = (AuthenticateContext)asyncResult;
            base.EndAuthenticateAsServer(authenticate_context.AsyncResult);
#if DEBUG
            on_authenticate();
#endif //DEBUG
        }

        /// <summary>
        /// The BeginAuthenticateAsClient method.
        /// </summary>
        public override IAsyncResult BeginAuthenticateAsClient(string targetHost, AsyncCallback asyncCallback, object asyncState)
        {
            AuthenticateContext authenticate_context = new AuthenticateContext(asyncCallback, asyncState);
            IAsyncResult ret = base.BeginAuthenticateAsClient(targetHost, AuthenticateContext.sm_Callback, authenticate_context);

            if ((ret is AuthenticateContext) == false)
                authenticate_context.AsyncResult = ret;

            return authenticate_context;
        }

        /// <summary>
        /// The BeginAuthenticateAsClient method.
        /// </summary>
        public override IAsyncResult BeginAuthenticateAsClient(string targetHost, X509CertificateCollection clientCertificates, SslProtocols enabledSslProtocols, bool checkCertificateRevocation, AsyncCallback asyncCallback, object asyncState)
        {
            // note: base class implementation of the first function overload is to call this function
            AuthenticateContext authenticate_context = asyncState is AuthenticateContext ? (AuthenticateContext)asyncState : new AuthenticateContext(asyncCallback, asyncState);
            IAsyncResult ret = base.BeginAuthenticateAsClient(targetHost, clientCertificates, enabledSslProtocols, checkCertificateRevocation, AuthenticateContext.sm_Callback, authenticate_context);
            authenticate_context.AsyncResult = ret;

            return authenticate_context;
        }

        /// <summary>
        /// The EndAuthenticateAsClient method.
        /// </summary>
        public override void EndAuthenticateAsClient(IAsyncResult asyncResult)
        {
            AuthenticateContext authenticate_context = (AuthenticateContext)asyncResult;
            base.EndAuthenticateAsClient(authenticate_context.AsyncResult);
#if DEBUG
            on_authenticate();
#endif //DEBUG
        }

#if DEBUG
        void on_authenticate()
        {
            m_busy_read = m_busy_write = false;
        }

        /// <summary>
        /// The AuthenticateAsClient method.
        /// </summary>
        public override void AuthenticateAsClient(string targetHost)
        {
            base.AuthenticateAsClient(targetHost);
            on_authenticate();
        }

        /// <summary>
        /// The AuthenticateAsClient method.
        /// </summary>
        public override void AuthenticateAsClient(string targetHost, X509CertificateCollection clientCertificates, SslProtocols enabledSslProtocols, bool checkCertificateRevocation)
        {
            base.AuthenticateAsClient(targetHost, clientCertificates, enabledSslProtocols, checkCertificateRevocation);
            on_authenticate();
        }

        /// <summary>
        /// The AuthenticateAsServer method.
        /// </summary>
        public override void AuthenticateAsServer(X509Certificate serverCertificate)
        {
            base.AuthenticateAsServer(serverCertificate);
            on_authenticate();
        }

        /// <summary>
        /// The AuthenticateAsServer method.
        /// </summary>
        public override void AuthenticateAsServer(X509Certificate serverCertificate, bool clientCertificateRequired, SslProtocols enabledSslProtocols, bool checkCertificateRevocation)
        {
            base.AuthenticateAsServer(serverCertificate, clientCertificateRequired, enabledSslProtocols, checkCertificateRevocation);
            on_authenticate();
        }

#endif //DEBUG

        #endregion Authentication overrides

#if NETWORKSTREAMEX

        private class NetworkStreamEx : NetworkStream
        {
            private const int N = 5;
            private bool m_enhanced;

            private byte[]  m_first_N_bytes_buffer = new byte[N];
            private int     m_first_N_bytes_offset = 0;

            private byte[]  m_buffer;
            private int     m_offset;

            public NetworkStreamEx(bool enhanced, Socket socket)
                : base(socket) { m_enhanced = enhanced; }
            public NetworkStreamEx(bool enhanced, Socket socket, bool ownsSocket)
                : base(socket, ownsSocket) { m_enhanced = enhanced; }
            public NetworkStreamEx(bool enhanced, Socket socket, FileAccess access)
                : base(socket, access) { m_enhanced = enhanced; }
            public NetworkStreamEx(bool enhanced, Socket socket, FileAccess access, bool ownsSocket)
                : base(socket, access, ownsSocket) { m_enhanced = enhanced; }

            public override int Read(byte[] buffer, int offset, int count)
            {
                int bytesRead = base.Read(buffer, offset, count);

                if (m_enhanced)
                    set_enhandced(bytesRead, buffer, offset);

                return bytesRead;
            }

            public override IAsyncResult BeginRead(byte[] buffer, int offset, int count, AsyncCallback asyncCallback, Object asyncState)
            {
                if (m_enhanced)
                {
                    m_buffer = buffer;
                    m_offset = offset;
                }

                return base.BeginRead(buffer, offset, count, asyncCallback, asyncState);
            }

            public override int EndRead(IAsyncResult asyncResult)
            {
                if (m_enhanced)
                {
                    byte[] buffer = m_buffer;
                    m_buffer = null;

                    int bytesRead = base.EndRead(asyncResult);

                    set_enhandced(bytesRead, buffer, m_offset);

                    return bytesRead;
                }

                return base.EndRead(asyncResult);
            }

            private void set_enhandced(int bytesRead, byte[] buffer, int offset)
            {
                int bytes2Copy = Math.Min(bytesRead, N - m_first_N_bytes_offset);
                System.Buffer.BlockCopy(buffer, offset, m_first_N_bytes_buffer, m_first_N_bytes_offset, bytes2Copy);
                m_first_N_bytes_offset += bytes2Copy;

                if (m_first_N_bytes_offset == N)
                    m_enhanced = false;
            }

            public byte[] GetRawData()
            {
                return m_first_N_bytes_buffer;
            }
        }

        public byte[] GetHandshakeRawData()
        {
            if (m_network_stream is NetworkStreamEx)
                return ((NetworkStreamEx)m_network_stream).GetRawData();

            return null;
        }

#endif  // NETWORKSTREAMEX
    }
}
