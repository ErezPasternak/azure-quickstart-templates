﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;
using System.Runtime.Serialization;

using TracerX;

namespace EriCommon
{
    public partial class Server
    {
        /// <summary>
        /// The Service class.
        /// A Server handles many services
        /// </summary>
        public abstract class Service
        {
            /// <summary>
            /// The constructor
            /// </summary>
            public Service(Server owner, String name, uint version, bool multi_step)
            {
#if DEBUG
                Service service = null;
                owner.m_services_sorted.TryGetValue(name, out service);
                Debug.Assert(service == null);
#endif
                Debug.Assert(owner != null);
                Debug.Assert(! String.IsNullOrWhiteSpace(name));
                Debug.Assert(name.Length <= owner.ServiceNameLength);
                Owner = owner;
                Name = name;
                Version = version;
                Logger = Owner.CreateLogger(name);
                MultiStep = multi_step;

                lock (Owner.m_services_list)
                {
                    Owner.m_services_sorted.Add(Name, this);
                    Owner.m_services_list.Add(this);
                    Owner.Features.Add(Name, Version);
                }
            }

            /// <summary>
            /// The MULTI-STEP property
            /// </summary>
            public readonly bool MultiStep;

            /// <summary>
            /// The owning server
            /// </summary>
            public Server Owner
            {
                get;
                private set;
            }

            /// <summary>
            /// The service logger
            /// </summary>
            public Logger Logger
            {
                get;
                private set;
            }

            /// <summary>
            /// Returns a formated line of statistics
            /// </summary>
            public String GetStatisticsText()
            {
                return m_counters.GetStatisticsText(Name, Owner.m_service_name_format.ToString());
            }

            /// <summary>
            /// The service name
            /// </summary>
            public String Name
            {
                get;
                private set;
            }

            /// <summary>
            /// The service version (ZERO is the default)
            /// </summary>
            public uint Version
            {
                get;
                private set;
            }

            /// <summary>
            /// Converts the message ID the a string. When overridden, an enum value name can be returned.
            /// </summary>
            public virtual String GetMessageIdText(int message_id)
            {
                return Owner.GetMessageIdText(message_id);
            }

            /// <summary>
            /// The service counters
            /// </summary>
            protected Counters m_counters = new Counters();
        }

        /// <summary>
        /// The ServiceT generic class (used for strong type checking)
        /// </summary>
        public abstract class ServiceT<REQUEST, RESPONSE> : Service
                where REQUEST  : Request
                where RESPONSE : Response, new()
        {
            /// <summary>
            /// The constructor
            /// </summary>
            public ServiceT(Server owner, String name, uint version, bool multi_step)
                : base(owner, name, version, multi_step)
            {

            }

            /// <summary>
            /// Processing trigger
            /// </summary>
            public void Proceed(Object context, uint version, REQUEST request, out RESPONSE response)
            {
                response = null;

                try
                {
                    proceed(context, version, request, ref response);
                }
                catch (System.Exception ex)
                {
                    SafeCall.ExceptionHandler(ex, null);
                }
            }

            private void proceed(Object context, uint version, REQUEST request, ref RESPONSE response)
            {
                Debug.Assert(request != null);

                if (request == null)
                {
                    response = (RESPONSE)Activator.CreateInstance(typeof(RESPONSE),
                                                                  null /*request*/,
                                                                  Response.Status.NULL_REQUEST,
                                                                  "Null request" );
                    return;
                }

                request.RefreshDict();
                //request.CallError = null;
                //request.ServiceName = Name;

                MultiStepRequest multi_step_request = (MultiStep) ? request.CastToMultiStep : null;

                ulong request_counter = m_counters.Submit();
                ulong owner_request_counter = Owner.m_counters.Submit();

                Exception e = null;

                String id = String.Format("{0}/{1}", owner_request_counter, request_counter);
                String log_text;

                if (Logger != null)
                {
                    log_text = String.Format("Begin service ({0})\n", id);

                    log_text += request.GetText(this);
                    log_text = log_text.TrimEnd(null);
                    Logger.Info(log_text);
                }

                DateTime started_at = DateTime.Now;

                try
                {
                    if (version > Version)
                    {
                        response = (RESPONSE)Activator.CreateInstance(typeof(RESPONSE),
                                                                      request,
                                                                      Response.Status.UNSUPPORTED_VERSION,
                                                                      String.Format("Unsupported version {0} for '{1}' service request", version, Name) );
                    }
                    else
                    {
                        response = proceed(context, version, request);
                    }
                }
                catch (System.Exception ex)
                {
                    response = (RESPONSE)Activator.CreateInstance(typeof(RESPONSE),
                                                                  request,
                                                                  Response.Status.INTERNAL_ERROR,
                                                                  e.AllMessages() );

                    e = ex;
                    SafeCall.ExceptionHandler(e, null);
//                    request.CallError = e.AllMessages();
//                    request.CallErrorType = CallErrorType.Exception;
                }
                finally
                {
                    Debug.Assert(response != null);

                    TimeSpan ts = DateTime.Now - started_at;
                    double elapsed_seconds = ts.TotalSeconds;

                    bool succeeded =
//                                      request.CallError == null &&
//                                      response          != null &&
                                     response.SUCCESS;

                    if (response != null)
                    {
                        response.ServiceName = Name;
                    }

                    m_counters.Resume(succeeded, elapsed_seconds);
                    Owner.m_counters.Resume(succeeded, elapsed_seconds);

                    if (Logger != null)
                    {
                        log_text = String.Format("The service has {0} ({1})\n{2}",
                                                    (succeeded) ? "succeeded" : "failed",
                                                    id,
                                                    Owner.GetFieldText("Elapsed Seconds", elapsed_seconds.ToString("F3")));

//                         if (String.IsNullOrWhiteSpace(request.CallError) == false)
//                         {
//                             log_text += Owner.GetFieldText(response == null                                         ? ""
//                                                            response.STATUS == Server.Response.Status.INTERNAL_ERROR ? "*EXCEPTION*" :
//                                                                                                                      "*UNSUPPORTED*",
//                                                            request.CallError);
//                         }
//
//                         if (e != null)
//                         {
//                             log_text += Owner.GetFieldText("*EXCEPTION*", request.CallError);
//                         }

//                         if (response != null)
                        log_text += response.GetText(this);

                        log_text = log_text.TrimEnd(null);

                        if (e == null)
                            Logger.Info(log_text);
                        else
                            Logger.Warn(log_text);
                    }

                    Owner.report_CSV(this, request, response, elapsed_seconds);
                }
            }

            /// <summary>
            /// Specific processing method (should be overridded)
            /// </summary>
            protected abstract RESPONSE proceed(Object context, uint version, REQUEST request);
        }

    }
}
