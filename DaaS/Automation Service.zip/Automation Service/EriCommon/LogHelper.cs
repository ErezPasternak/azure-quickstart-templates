﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Threading;
using TracerX;

namespace EriCommon
{
    /// <summary>
    /// The LogHelper static class contains static methods dealing with the standard logging capability.
    /// </summary>
    public static class LogHelper
    {
        #region Public

        /// <summary>
        /// The Defaults enum specifies some default values used by this class.
        /// </summary>
        public enum Defaults
        {
            /// <summary>
            /// The maximum file size, in megabytes.
            /// </summary>
            MaxSizeMb = 32,
            /// <summary>
            /// The maximum number of archive files.
            /// </summary>
            MaxArchives = 99
        };

        /// <summary>
        /// The binary file size property.
        /// </summary>
        public static uint BinaryFileLoggingMaxSizeMb
        {
            get { return Logger.BinaryFileLogging.MaxSizeMb; }
            set { Logger.BinaryFileLogging.MaxSizeMb = value; }
        }

        /// <summary>
        /// Opens the log of an application acting as service, using the most frequent default parameters.
        /// </summary>
        public static void OpenServiceLog(bool start_circular_part)
        {
            OpenServiceLog((uint)Defaults.MaxSizeMb, (uint)Defaults.MaxArchives, start_circular_part);
        }

        /// <summary>
        /// Opens the log of an application acting as service.
        /// </summary>
        public static void OpenServiceLog(uint max_size_MB = (uint)Defaults.MaxSizeMb, uint max_archives = (uint)Defaults.MaxArchives, bool start_circular_part = true)
        {
            Thread current = Thread.CurrentThread;
            Process process = Process.GetCurrentProcess();

            if( current.Name == null )
            {
            }
            // Set log destination initial values
            Logger.Root.BinaryFileTraceLevel = TracerX.TraceLevel.Info;
            Logger.Root.EventLogTraceLevel = TracerX.TraceLevel.Error;
            Logger.Root.ConsoleTraceLevel = TracerX.TraceLevel.Off;
            Logger.Root.EventHandlerTraceLevel = TracerX.TraceLevel.Fatal;
#if DEBUG
            Logger.Root.DebugTraceLevel = TracerX.TraceLevel.Verbose;
#endif

            // Set the BinaryFileLogging attributes
            Logger.BinaryFileLogging.Directory = @"%EXEDIR%\Logs";
            Logger.BinaryFileLogging.FullFilePolicy = FullFilePolicy.Wrap;

            if (BinaryFileLoggingMaxSizeMb == 0)
            {
                if (0 == max_size_MB)
                    max_size_MB = (uint)Defaults.MaxSizeMb;

                BinaryFileLoggingMaxSizeMb = max_size_MB;
            }

            if (0 == max_archives)
                max_archives = (uint)Defaults.MaxArchives;
            Logger.BinaryFileLogging.Archives = max_archives;
            Logger.BinaryFileLogging.Use_00 = true;
            Logger.BinaryFileLogging.AddToListOfRecentlyCreatedFiles = true;
            Logger.BinaryFileLogging.Open();

            if (start_circular_part)
                StartCircularPart();
        }

        /// <summary>
        /// Starts the circular part of the log.
        /// </summary>
        public static void StartCircularPart()
        {
            Logger.BinaryFileLogging.CircularStartDelaySeconds = uint.MaxValue;
        }

        #endregion
    }
}
