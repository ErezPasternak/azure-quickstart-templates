﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.ServiceProcess;
using TracerX;
using System.Threading;

namespace EriCommon
{
    /// <summary>
    /// The WindowsService is the framework of any service program.
    /// </summary>
    public class WindowsService : ServiceBase
    {
        #region Event Delegates

        /// <summary>
        /// </summary>
        public delegate void OnStartDelegate(WindowsService sw, string[] args);
        /// <summary>
        /// </summary>
        public delegate void OnStopDelegate(WindowsService sw);

        /// <summary>
        /// </summary>
        public delegate void OnPauseDelegate(WindowsService sw);
        /// <summary>
        /// </summary>
        public delegate void OnContinueDelegate(WindowsService sw);

        /// <summary>
        /// </summary>
        public delegate void OnShutdownDelegate(WindowsService sw);
        /// <summary>
        /// </summary>
        public struct PowerEventCtx
        {
            /// <summary>
            /// </summary>
            public WindowsService sw;
            /// <summary>
            /// </summary>
            public PowerBroadcastStatus powerStatus;
            /// <summary>
            /// </summary>
            public PowerEventCtx(WindowsService _sw, PowerBroadcastStatus _powerStatus)
            {
                sw = _sw;
                powerStatus = _powerStatus;
            }
        }

        /// <summary>
        /// </summary>
        public delegate bool OnPowerEventDelegate(PowerEventCtx ctx);

        /// <summary>
        /// </summary>
        public struct CustomCommandCtx
        {
            /// <summary>
            /// </summary>
            public WindowsService sw;
            /// <summary>
            /// </summary>
            public int command;
            /// <summary>
            /// </summary>
            public CustomCommandCtx(WindowsService _sw, int _command)
            {
                sw = _sw;
                command = _command;
            }
        }

        /// <summary>
        /// </summary>
        public delegate void OnCustomCommandDelegate(CustomCommandCtx ctx);

        #endregion

        #region Public Methods

        /// <summary>
        /// AsService
        /// </summary>
        public bool AsService
        {
            get { return m_as_service; }
        }

        /// <summary>
        /// Running
        /// </summary>
        public bool Running
        {
            get { return m_running; }
        }

        /// <summary>
        /// The WindowsService ctor.
        /// </summary>
        public WindowsService(string name,
                              OnStartDelegate on_start,
                              OnStopDelegate on_stop = null,
                              OnPauseDelegate on_pause = null,
                              OnContinueDelegate on_continue = null,
                              OnShutdownDelegate on_shutdown = null,
                              OnPowerEventDelegate on_power_event = null,
                              OnCustomCommandDelegate on_custom_command = null,
                              bool use_name_in_logger = false,
                              bool run_in_high_process_priority = true)
        {
            m_logger = Logger.GetLogger((use_name_in_logger) ? String.Format("WindowsService.{0}", name) : "WindowsService");

            Debug.Assert(on_start != null);
            m_on_start = on_start;
            m_on_stop = on_stop;

            Debug.Assert((on_pause == null && on_continue == null) || (on_pause != null && on_continue != null));
            m_on_pause = on_pause;
            m_on_continue = on_continue;

            m_on_shutdown = on_shutdown;
            m_on_power_event = on_power_event;
            m_on_custom_command = on_custom_command;

            components = new System.ComponentModel.Container();
            ServiceName = name;

            CanStop = m_on_stop != null;

            CanPauseAndContinue = m_on_pause != null && m_on_continue != null;
            CanShutdown = m_on_shutdown != null;

            m_run_in_high_process_priority = run_in_high_process_priority;
        }

        /// <summary>
        /// Returns the Logger
        /// </summary>
        public Logger Logger
        {
            get { return m_logger; }
        }

        /// <summary>
        /// RunUnderUnitTestArg
        /// </summary>
        public const String RunUnderUnitTestArg = "/RunUnderUnitTest\x2B";

        /// <summary>
        /// RunUnderUnitTestArg
        /// </summary>
        public const String RunArg = "/Run";

        /// <summary>
        /// The Windows Service main function
        /// </summary>
        public bool Main(string[] args)
        {
            AppCfg.InhibitLoad = true;

            if (args != null && args.Length > 0)
            {
                if (args[0].Equals(RunUnderUnitTestArg, StringComparison.OrdinalIgnoreCase))
                {
                    UnitTestSetup.InitializeOutProcess();
                    run_as_program(args);
                    return true;
                }

                if (args[0].Equals(RunArg, StringComparison.OrdinalIgnoreCase))
                {
                    run_as_program(args);
                    return true;
                }

                return false;
            }

            run_as_service();
            return true;
        }

        /// <summary>
        /// Join the service main thread
        /// </summary>
        public void Join()
        {
            m_thread.Join();
        }

        private void run_as_program(string[] args)
        {
            m_as_service = false;
            OnStart(args);
        }

        private void run_as_service()
        {
            ServiceBase.Run(this);
        }

        /// <summary>
        /// The minimum and maximum command id value.
        /// </summary>
        public const int MinCustomCommand = 128, MaxCustomCommand = 256;

        /// <summary>
        /// Executes a custom command.
        /// </summary>
        public static void ExecuteCustomCommand(string service_name, int command)   // must be is range 128..256
        {
            Debug.Assert(command >= MinCustomCommand && command <= MaxCustomCommand);

            ServiceController service = new ServiceController(service_name);
            service.ExecuteCommand(command);
        }

        #endregion

        #region Override Methods

        /// <summary>
        /// Disposes the service.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        protected Thread m_thread;
 
        /// <summary>
        /// Starts the service.
        /// </summary>
        protected override void OnStart(string[] args)
        {
            Debug.Assert(m_running == false);

            if (m_running)
                return;

            if (m_as_service && m_run_in_high_process_priority)
            {
                Process thisProc = Process.GetCurrentProcess();
                thisProc.PriorityClass = ProcessPriorityClass.High;
            }

            m_thread = ThreadHelper.Create(ServiceName, service_init_thread/*on_start*/, args, false, ThreadHelper.Mode.Foreground);
        }

        private void service_init_thread(object args/*string[] args*/)
        {
            m_running = true;

            try
            {
                SafeCall.ServiceProgramMain(thread_main, (string[])args);
            }
            finally
            {
                m_running = false;
            }
        }

        private void thread_main(string[] args/*object args*/)
        {
            using (m_logger.InfoBlock("Service is started.",
                                      "Service is terminated.",
                                      TracerX.Destinations.EventLog))
            {
                if (AppCfg.InhibitLoad)
                {
                    AppCfg.InhibitLoad = false;
                    AppCfg.Load();
                }

                m_on_start(this, args);
            }
        }

        /// <summary>
        /// Stops the service.
        /// </summary>
        protected override void OnStop()
        {
            using (m_logger.InfoBlock("Stopping the service...",
                                      "The service was stopped.",
                                      TracerX.Destinations.EventLog))
            {
                SafeCall.Run(new SafeCall.DoIt<WindowsService>(m_on_stop), this);
            }
        }

        /// <summary>
        /// Pauses the service.
        /// </summary>
        protected override void OnPause()
        {
            using (m_logger.InfoBlock("Pausing the service...",
                                      "The service was stopped.",
                                      TracerX.Destinations.EventLog))
            {
                SafeCall.Run(new SafeCall.DoIt<WindowsService>(m_on_pause), this);
            }
        }

        /// <summary>
        /// Resumes after pausing the service.
        /// </summary>
        protected override void OnContinue()
        {
            using (m_logger.InfoBlock("Resuming the service...",
                                      "The service was resumed.",
                                      TracerX.Destinations.EventLog))
            {
                SafeCall.Run(new SafeCall.DoIt<WindowsService>(m_on_continue), this);
            }
        }

        /// <summary>
        /// Deals with the system shutdown event.
        /// </summary>
        protected override void OnShutdown()
        {
            using (m_logger.InfoBlock("Treating the operating system shutdown notification...",
                                      "The operating system shutdown notification was treated.",
                                      TracerX.Destinations.EventLog))
            {
                SafeCall.Run(new SafeCall.DoIt<WindowsService>(m_on_shutdown), this);
            }
        }

        /// <summary>
        /// Deals with power events.
        /// </summary>
        protected override bool OnPowerEvent(PowerBroadcastStatus powerStatus)
        {
            using (m_logger.InfoBlock(String.Format("Treating the power event '{0}'...", powerStatus),
                                      String.Format("The power event '{0}' was treated.", powerStatus),
                                      TracerX.Destinations.EventLog))
            {
                return SafeCall.Run<bool, PowerEventCtx>(new SafeCall.ReturnIt<bool, PowerEventCtx>(m_on_power_event),
                                                         new PowerEventCtx(this, powerStatus),
                                                         get_default_return_on_power_event(powerStatus));
            }
        }

        /// <summary>
        /// The default return for any power event.
        /// </summary>
        protected virtual bool get_default_return_on_power_event(PowerBroadcastStatus powerStatus)
        {
            return true;
        }

        /// <summary>
        /// Deals with custom command events.
        /// </summary>
        protected override void OnCustomCommand(int command)
        {
            if (m_on_custom_command == null)
                return;

            Debug.Assert(command >= MinCustomCommand && command <= MaxCustomCommand);   //HOW???

            using (m_logger.InfoBlock(String.Format("Treating the custom command #{0}...", command),
                                      String.Format("The custom command #{0} was treated.", command),
                                      TracerX.Destinations.EventLog))
            {
                SafeCall.Run(new SafeCall.DoIt<CustomCommandCtx>(m_on_custom_command), new CustomCommandCtx(this, command));
            }
        }

        #endregion

        #region Private Methods

//         private void on_start(string[] args/*object context*/)
//         {
//             string[] args = (string[])context;
//             m_on_start(args);
//         }

//         private bool on_power_event(object context)
//         {
//             return m_on_power_event((PowerBroadcastStatus)context);
//         }

//         private void on_custom_command(object context)
//         {
//             m_on_custom_command((int)context);
//         }

        #endregion

        /// <summary>
        /// The Logger
        /// </summary>
        protected Logger m_logger;

        #region Private Data Members

        private System.ComponentModel.IContainer components = null;

        private OnStartDelegate m_on_start;
        private OnStopDelegate m_on_stop;
        private OnPauseDelegate m_on_pause;
        private OnContinueDelegate m_on_continue;
        private OnShutdownDelegate m_on_shutdown;
        private OnPowerEventDelegate m_on_power_event;
        private OnCustomCommandDelegate m_on_custom_command;

        private bool m_run_in_high_process_priority;
        private bool m_as_service = true;
        private bool m_running = false;

        #endregion
    }
}
