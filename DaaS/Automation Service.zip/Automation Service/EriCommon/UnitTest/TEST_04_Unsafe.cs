﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FluentAssertions;

using EriCommon;

namespace UnitTest
{
    /// <summary>
    /// Summary description for TEST_04_Unsafe
    /// </summary>
    [TestClass]
    public class TEST_04_Unsafe
    {
        public TEST_04_Unsafe()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        const int max_factor = 1024 * 16;
        const int multiply_factor = 64;

        [TestMethod]
        public void Test_05_CompareUnsafeSafe()
        {
            for (int factor = 1; factor <= max_factor; factor *= 2)
                CompareUnsafeSafe(factor);
        }

        void CompareUnsafeSafe(int factor)
        {
            factor *= multiply_factor;

            byte[] buffer_1 = new byte[factor];
            byte[] buffer_2 = new byte[factor];

            int max_tests = (1024 * 1024 * 128) / factor;

            DateTime start_time;
            start_time = DateTime.Now;

            for (int count = 0; count < max_tests; count++)
                Array.Copy(buffer_1, 0, buffer_2, 0, factor);

            TimeSpan safe_elapsed = DateTime.Now.Subtract(start_time);

            start_time = DateTime.Now;

            for (int count = 0; count < max_tests; count++)
                Unsafe.MemCpy(buffer_1, 0, buffer_2, 0, (uint)factor);

            TimeSpan unsafe_elapsed = DateTime.Now.Subtract(start_time);

            Int64 safe_elapsed_ticks = safe_elapsed.Ticks,
                  unsafe_elapsed_ticks = unsafe_elapsed.Ticks;

            Int64 delta = unsafe_elapsed_ticks - safe_elapsed_ticks;
            Int64 percent = unsafe_elapsed_ticks * 100 / safe_elapsed_ticks;

            System.Diagnostics.Trace.WriteLine(String.Format("Length={0}, Percent={1}, Unsafe={2}, Safe={3}", factor, percent, unsafe_elapsed_ticks, safe_elapsed_ticks));
        }
    }
}
