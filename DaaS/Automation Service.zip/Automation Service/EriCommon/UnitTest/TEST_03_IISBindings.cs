﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FluentAssertions;

using EriCommon;
using System.Net.Sockets;
using System.Net;

namespace UnitTest
{
    /// <summary>
    /// Summary description for TEST_03_IISBindings
    /// </summary>
    [TestClass]
    public class TEST_03_IISBindings
    {
        public TEST_03_IISBindings()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext) 
        {
            set_other_program_listener();
            not_other_program_listener_port = other_program_listener_port;
            other_program_listener.Stop();
            set_other_program_listener();

            IISBindings.Initialize("EriCommon Unit Test", "EriCommonUnitTest.config");
        }

        // Use ClassCleanup to run code after all tests in a class have run
        [ClassCleanup()]
        public static void MyClassCleanup() 
        {

        }
        //
        // Use TestInitialize to run code before running each test 
        static void set_other_program_listener()
        {
            other_program_listener = new TcpListener(IPAddress.Any, 0);
            other_program_listener.Server.ExclusiveAddressUse = true;
            other_program_listener.Start();
            IPEndPoint ep = (IPEndPoint) other_program_listener.LocalEndpoint;
            other_program_listener_port = ep.Port;
        }

        [TestInitialize()]
        public void MyTestInitialize()
        {
        }

        static TcpListener other_program_listener;
        static Int32 other_program_listener_port;
        static Int32 not_other_program_listener_port;
        static Int32 iis_port = 80;

    // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void MyTestCleanup()
        {

        }

        #endregion

        [TestMethod]
        public void Test_03_001_ArePortsConflictWithOtherProcess()
        {
            String ports_status;
            
            ports_status = IISBindings.IsPortConflictingWithOtherProcess((uint)not_other_program_listener_port, false);
            ports_status.Should().BeNullOrEmpty();

            ports_status = IISBindings.IsPortConflictingWithOtherProcess((uint)not_other_program_listener_port, true);
            ports_status.Should().BeNullOrEmpty();

            ports_status = IISBindings.IsPortConflictingWithOtherProcess((uint)other_program_listener_port, false);
            ports_status.Should().NotBeNullOrEmpty();

            ports_status = IISBindings.IsPortConflictingWithOtherProcess((uint)other_program_listener_port, true);
            ports_status.Should().NotBeNullOrEmpty();
        }

        [TestMethod]
        public void Test_03_002_ArePortsConflictingWithIIS()
        {
            String ports_status;
            String new_port_settings;
            uint new_port;

            ports_status = IISBindings.IsPortConflictingWithIIS((uint)not_other_program_listener_port, false, out new_port_settings, out new_port);
            ports_status.Should().BeNullOrEmpty();

            ports_status = IISBindings.IsPortConflictingWithIIS((uint)not_other_program_listener_port, true, out new_port_settings, out new_port);
            ports_status.Should().BeNullOrEmpty();

            ports_status = IISBindings.IsPortConflictingWithIIS((uint)iis_port, false, out new_port_settings, out new_port);
            ports_status.Should().NotBeNullOrEmpty();

            ports_status = IISBindings.IsPortConflictingWithIIS((uint)iis_port, true, out new_port_settings, out new_port);
            ports_status.Should().NotBeNullOrEmpty();
        }

        [TestMethod]
        public void Test_03_003_ImportCertificate()
        {
            String certificate_thumbprint;
            bool ok = IISBindings.ImportCertificate(".", false, out certificate_thumbprint);
            ok.Should().BeTrue();
        }

//         [TestMethod]
//         public void Test_ChangeIISPort()
//         {
//             IISBindings.ChangeIISPort(".", 0, 555, true);
//             IISBindings.RestoreIISPort(".", true);
//         }

        [TestMethod]
        public void Test_03_004_AddIISPort()
        {
            test_AddIISPort(null);
            String tp = "00 86 46 d6 d0 95 78 06 23 fc 29 95 06 e3 76 ad 9b c9 c0 77";
//            String tp = "86 4e c2 e1 09 a3 e6 36 9a 02 64 07 25 42 2e 40 c5 ac 48 df";
            test_AddIISPort(tp);
        }

        public void test_AddIISPort(String certificate_thumbprint)
        {
            bool ok;

            String new_port_settings;
            uint new_port;

            if (certificate_thumbprint != null)
                certificate_thumbprint = certificate_thumbprint.Replace("\x20", "");

            bool secured = certificate_thumbprint != null;

            ok = IISBindings.AddIISPort(".", not_other_program_listener_port, certificate_thumbprint, true, null);
            ok.Should().BeTrue();

            for (int cnt = 0; cnt < 10; cnt++)
            {
                int hold = other_program_listener_port;

                set_other_program_listener();
                int port = other_program_listener_port;
                other_program_listener_port = hold;
                String cert = null;
                if (cnt % 2 == 1)
                    cert = certificate_thumbprint;
                ok = IISBindings.AddIISPort(".", port, cert, false, null);
                ok.Should().BeTrue();
            }

            IISBindings.RestoreIISPorts(".");

            String ports_status = IISBindings.IsPortConflictingWithIIS((uint)not_other_program_listener_port, secured, out new_port_settings, out new_port);
            ports_status.Should().BeNullOrEmpty();
        }
    }
}
