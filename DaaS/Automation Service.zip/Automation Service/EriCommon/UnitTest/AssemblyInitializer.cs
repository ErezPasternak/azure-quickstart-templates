﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Reflection;

using TracerX;
using EriCommon;

namespace UnitTest
{
    [TestClass]
    public class AssemblyInitializer
    {
        [AssemblyInitialize]
        public static void AssemblyInitialize(TestContext context) 
        {
            UnitTestSetup.InitializeInProcess(Assembly.GetExecutingAssembly());
        }
    }
}
