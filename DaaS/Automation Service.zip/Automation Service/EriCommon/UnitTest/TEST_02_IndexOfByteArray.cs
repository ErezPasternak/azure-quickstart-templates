﻿using System;
using System.Diagnostics;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FluentAssertions;

using EriCommon;

namespace UnitTest
{
    /// <summary>
    /// Summary description for TEST_02_IndexOfByteArray
    /// </summary>
    [TestClass]
    public class TEST_02_IndexOfByteArray
    {
        public TEST_02_IndexOfByteArray()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_02_001_NullOrEmptyArrays()
        {
            byte[] a1 = new byte[] { 1, 2 };
            byte[] a2 = new byte[0];
            byte[] null_a = null;

            int retval;

            retval = null_a.IndexOf(a1, 0, 7, 0, 7);
            retval.Should().Be(-1);

            retval = a1.IndexOf(null_a, 0, 7, 0, 7);
            retval.Should().Be(-1);

            retval = a1.IndexOf(a2, 0, 7, 0, 7);
            retval.Should().Be(-1);

            retval = a2.IndexOf(a1, 0, 7, 0, 7);
            retval.Should().Be(-1);
        }

        [TestMethod]
        public void Test_02_002_Regular()
        {
            int retval;

            retval = new byte[] {1,2,3,4}.IndexOf(new byte[] {0} );
            retval.Should().Be(-1);

            retval = new byte[] { 1, 2, 3, 4 }.IndexOf(new byte[] { 1 });
            retval.Should().Be(0);

            retval = new byte[] { 1, 2, 3, 4 }.IndexOf(new byte[] { 4 });
            retval.Should().Be(3);

            retval = new byte[] { 1, 2, 3, 4 }.IndexOf(new byte[] { 1, 2 });
            retval.Should().Be(0);

            retval = new byte[] { 1, 2, 3, 4 }.IndexOf(new byte[] { 4, 4 });
            retval.Should().Be(-1);

            retval = new byte[] { 1, 2, 3, 4 }.IndexOf(new byte[] { 3, 4 });
            retval.Should().Be(2);

            retval = new byte[] { 1, 1, 1, 2 }.IndexOf(new byte[] { 1,1,2 });
            retval.Should().Be(1);
        }

        static public int SearchMark(byte[] source, int offset, int length, byte[] mark)
        {
            int pos = offset;
            int endOffset = offset + length - 1;
            int matchCount = 0;

            while (true)
            {
                pos = Array.IndexOf(source, mark[0], pos, length - pos + offset);

                if (pos < 0)
                    return -1;

                matchCount = 1;

                for (int i = 1; i < mark.Length; i++)
                {
                    int checkPos = pos + i;

                    if (checkPos > endOffset)
                    {
                        //found end, return matched chars count
                        return (0 - i);
                    }

                    if (!source[checkPos].Equals(mark[i]))
                        break;

                    matchCount++;
                }

                if (matchCount == mark.Length)
                    return pos;

                //Reset next round read pos
                pos += matchCount;
                //clear matched chars count
                matchCount = 0;
            }
        }

        //[TestMethod]
        public void Test_02_003_Eyals()
        {
            int retval;

            retval = SearchMark(new byte[] { 1, 1, 1, 2 }, 0, 4, new byte[] { 1, 1, 2 });
            retval.Should().Be(1);
        }

        [TestMethod]
        public void Test_02_004_Unsafe()
        {
            byte[] a1 = new byte[] { 1, 2 };
            byte[] a2 = new byte[0];
            byte[] null_a = null;

            int retval;

            retval = Unsafe.IndexOf(null_a, a1, 0, 7, 0, 7);
            retval.Should().Be(-1);

            retval = Unsafe.IndexOf(a1, null_a, 0, 7, 0, 7);
            retval.Should().Be(-1);

            retval = Unsafe.IndexOf(a1, a2, 0, 7, 0, 7);
            retval.Should().Be(-1);

            retval = Unsafe.IndexOf(a2, a1, 0, 7, 0, 7);
            retval.Should().Be(-1);

            retval = Unsafe.IndexOf(new byte[] { 1, 2, 3, 4 }, new byte[] { 0 });
            retval.Should().Be(-1);

            retval = Unsafe.IndexOf(new byte[] { 1, 2, 3, 4 }, new byte[] { 1 });
            retval.Should().Be(0);

            retval = Unsafe.IndexOf(new byte[] { 1, 2, 3, 4 }, new byte[] { 4 });
            retval.Should().Be(3);

            retval = Unsafe.IndexOf(new byte[] { 1, 2, 3, 4 }, new byte[] { 1, 2 });
            retval.Should().Be(0);

            retval = Unsafe.IndexOf(new byte[] { 1, 2, 3, 4 }, new byte[] { 4, 4 });
            retval.Should().Be(-1);

            retval = Unsafe.IndexOf(new byte[] { 1, 2, 3, 4 }, new byte[] { 3, 4 });
            retval.Should().Be(2);

            retval = Unsafe.IndexOf(new byte[] { 1, 1, 1, 2 }, new byte[] { 1, 1, 2 });
            retval.Should().Be(1);
        }

        const int max_factor = 1024 * 16;
        const int multiply_factor = 5;

        [TestMethod]
        public void Test_02_005_CompareUnsafeSafe()
        {
            for (int factor = 1; factor <= max_factor; factor *= 2)
                CompareUnsafeSafe(factor);
        }

        void CompareUnsafeSafe(int factor)
        {
            factor *= multiply_factor;

            byte[] pattern = new byte[] { 1,3,2,4,5,6,7,8,9,0,6,2,43,1,4,13,10 };
            byte[] terminator = new byte[] { 13, 10, 7, 7, 8, 99 };
            byte[] http_header = new byte[(pattern.Length * factor) + 128];

            int cnt;

            for(cnt = 0; cnt < factor; cnt++)
                Unsafe.MemCpy(pattern, 0, http_header, (uint)(cnt * pattern.Length), (uint)pattern.Length);

            byte[] http_header_terminator = new byte[] { 13,10,13,10 };
            Unsafe.MemCpy(terminator, 0, http_header, (uint)(cnt * pattern.Length), (uint)terminator.Length);
            
            int retval;
            int expected = (factor * pattern.Length) - 2;

            retval = http_header.IndexOf(http_header_terminator);
            retval.Should().Be(expected);
            retval = Unsafe.IndexOf(http_header, http_header_terminator);
            retval.Should().Be(expected);

            int max_tests = (1024 * 1024) / factor;

            DateTime start_time;
            start_time = DateTime.Now;

            for(int count = 0; count < max_tests; count++)
                retval = http_header.IndexOf(http_header_terminator);

            TimeSpan safe_elapsed = DateTime.Now.Subtract(start_time);

            start_time = DateTime.Now;

            for (int count = 0; count < max_tests; count++)
                retval = Unsafe.IndexOf(http_header, http_header_terminator);

            TimeSpan unsafe_elapsed = DateTime.Now.Subtract(start_time);

            Int64 safe_elapsed_ticks = safe_elapsed.Ticks,
                  unsafe_elapsed_ticks = unsafe_elapsed.Ticks;

            Int64 delta = unsafe_elapsed_ticks - safe_elapsed_ticks;
            Int64 percent = unsafe_elapsed_ticks * 100 / safe_elapsed_ticks;

            System.Diagnostics.Trace.WriteLine(String.Format("Lines={0}, Percent={1}, Unsafe={2}, Safe={3}", factor, percent, unsafe_elapsed_ticks, safe_elapsed_ticks));
        }

        [TestMethod]
        public void Test_02_006_CompareUnsafeWithSearchMark()
        {
            for (int factor = 1; factor <= max_factor; factor *= 2)
                CompareUnsafeWithSearchMark(factor);
        }

        void CompareUnsafeWithSearchMark(int factor)
        {
            factor *= multiply_factor;

            byte[] pattern = new byte[] { 1, 3, 2, 4, 5, 6, 7, 8, 9, 0, 6, 2, 43, 1, 4, 13, 10 };
            byte[] terminator = new byte[] { 13, 10, 7, 7, 8, 99 };
            byte[] http_header = new byte[(pattern.Length * factor) + 128];

            int cnt;

            for (cnt = 0; cnt < factor; cnt++)
                Unsafe.MemCpy(pattern, 0, http_header, (uint)(cnt * pattern.Length), (uint)pattern.Length);

            byte[] http_header_terminator = new byte[] { 13, 10, 13, 10 };
            Unsafe.MemCpy(terminator, 0, http_header, (uint)(cnt * pattern.Length), (uint)terminator.Length);

            int retval;
            int expected = (factor * pattern.Length) - 2;

            retval = SearchMark(http_header, 0, http_header.Length, http_header_terminator);
            retval.Should().Be(expected);
            retval = Unsafe.IndexOf(http_header, http_header_terminator);
            retval.Should().Be(expected);

            int max_tests = (1024 * 1024) / factor;

            DateTime start_time;
            start_time = DateTime.Now;

            for (int count = 0; count < max_tests; count++)
                retval = SearchMark(http_header, 0, http_header.Length, http_header_terminator);

            TimeSpan safe_elapsed = DateTime.Now.Subtract(start_time);

            start_time = DateTime.Now;

            for (int count = 0; count < max_tests; count++)
                retval = Unsafe.IndexOf(http_header, http_header_terminator);

            TimeSpan unsafe_elapsed = DateTime.Now.Subtract(start_time);

            Int64 safe_elapsed_ticks = safe_elapsed.Ticks,
                  unsafe_elapsed_ticks = unsafe_elapsed.Ticks;

            Int64 delta = unsafe_elapsed_ticks - safe_elapsed_ticks;
            Int64 percent = unsafe_elapsed_ticks * 100 / safe_elapsed_ticks;

            System.Diagnostics.Trace.WriteLine(String.Format("Lines={0}, Percent={1}, Unsafe={2}, Safe={3}", factor, percent, unsafe_elapsed_ticks, safe_elapsed_ticks));

//            delta.Should().BeLessThan(0);
//            percent.Should().BeLessThan(95);
//            percent.Should().BeLessThan(90);
//            percent.Should().BeLessThan(85);
//            percent.Should().BeLessThan(80);
        }
    }
}
