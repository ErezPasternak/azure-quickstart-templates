﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FluentAssertions;

using EriCommon;
using System.Net;
using System.Threading;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;

namespace UnitTest
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class TEST_01_SslStreamEx
    {
        public TEST_01_SslStreamEx()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_01_001_SynchronousAuthentication()
        {
            Action server = createSynchronousServer;
            IAsyncResult server_result = server.BeginInvoke(null, null);

            Action client = createSynchronousClient;
            IAsyncResult client_result = client.BeginInvoke(null, null);

            server.EndInvoke(server_result);
            client.EndInvoke(client_result);
        }

        [TestMethod]
        public void Test_01_002_SynchronousIO()
        {
            Test_SynchronousAuthentication();

            const int sizeof_buffer = 1024 * 1024;
            byte[] send_buffer = new byte[sizeof_buffer];
            byte[] recv_buffer = new byte[sizeof_buffer];

            for (int cnt = 0; cnt < 10; cnt++)
            {
                m_client.Write(send_buffer, 0, send_buffer.Length);

                int bytes_read = m_server.Read(recv_buffer, 0, recv_buffer.Length);
                bytes_read.Should().Be(sizeof_buffer);
                recv_buffer.Should().Equal(send_buffer);
            }
        }

        //[TestMethod]
        public void Test_01_003_OverlappedSynchronousReads()
        {
            Test_SynchronousAuthentication();

            Action reader = readSynchronous;

            IAsyncResult result_1 = reader.BeginInvoke(null, null);
            IAsyncResult result_2 = reader.BeginInvoke(null, null);

            reader.EndInvoke(result_1);
            reader.EndInvoke(result_2);
        }

        //[TestMethod]
        public void Test_01_004_OverlappedAsynchronousReads()
        {
            Test_SynchronousAuthentication();

            byte[] recv_buffer_1 = new byte[1];
            IAsyncResult result_1 = m_server.BeginRead(recv_buffer_1, 0, recv_buffer_1.Length, null, null);

            try
            {
                byte[] recv_buffer_2 = new byte[1];
                IAsyncResult result_2 = m_server.BeginRead(recv_buffer_2, 0, recv_buffer_2.Length, null, null);
                false.Should().BeTrue();
            }
            catch (System.Exception ex)
            {
                (ex is System.NotSupportedException).Should().BeTrue();
            }
        }

        [TestMethod]
        public void Test_01_005_OverlappedMixedReads()
        {
            Test_SynchronousAuthentication();

            byte[] recv_buffer_1 = new byte[1];
            IAsyncResult result_1 = m_server.BeginRead(recv_buffer_1, 0, recv_buffer_1.Length, null, null);

            try
            {
                readSynchronous();
                false.Should().BeTrue();
            }
            catch (System.Exception ex)
            {
                (ex is System.NotSupportedException).Should().BeTrue();
            }
        }

//         [TestMethod]
//         public void Test_AsynchronousIO()
//         {
//             Test_SynchronousAuthentication();
// 
//             m_terminated = new ManualResetEvent(false);
// 
//             asynchServer();
//             asynchClient();
// 
//             m_terminated.WaitOne();
//         }

        #region Internal Methods
        void createServer()
        {
            TcpListener tcp_listener = new TcpListener(IPAddress.Loopback, 0);

            tcp_listener.Start();

            m_port = ((IPEndPoint)tcp_listener.LocalEndpoint).Port;

            m_synch_begin.Set();

            TcpClient client = tcp_listener.AcceptTcpClient();

            NetworkStream network_stream = client.GetStream();

            m_server = new SslStreamEx(network_stream, m_enhanced);
        }

        void createSynchronousServer()
        {
            createServer();
            m_server.AuthenticateAsServer(sm_certificate);
        }

        void createClient()
        {
            m_synch_begin.WaitOne();

            TcpClient client = new TcpClient("localhost", m_port);
            NetworkStream network_stream = client.GetStream();
            m_client = new SslStreamEx(network_stream, false, new RemoteCertificateValidationCallback(ValidateServerCertificate));
        }
        
        void createSynchronousClient()
        {
            createClient();
            m_client.AuthenticateAsClient(sm_generated_certificate_subject);
        }

        static X509Certificate2 getCertificate()
        {
            X509Certificate2 certificate = CertificateManager.Instance.LoadOrGenerateCertificate(null, ref sm_generated_certificate_subject);

            if (String.IsNullOrWhiteSpace(sm_generated_certificate_subject))
                sm_generated_certificate_subject = CertificateManager.DefaultCertificateSubject;

            return certificate;
        }

        static bool ValidateServerCertificate(object sender,
                                              X509Certificate certificate,
                                              X509Chain chain,
                                              SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }

        void readSynchronous()
        {
            byte[] recv_buffer = new byte[1];
            int bytes_read = m_server.Read(recv_buffer, 0, recv_buffer.Length);
            bytes_read.Should().Be(recv_buffer.Length);
        }

        static void init_asynch_buffers(out byte[][] buffers)
        {
            const int sizeof_buffer = 1024 * 1024;

            buffers = new byte[2][];
            buffers[0] = new byte[sizeof_buffer];
            buffers[1] = new byte[sizeof_buffer];
        }

//         void asynchClient()
//         {
//             init_asynch_buffers(out m_client_buffers);
// 
//             m_client.BeginWrite(m_client_buffers[0], )
//         }

        #endregion Internal Methods

        #region Data Members

        bool m_enhanced = true;

        static String           sm_generated_certificate_subject;
        static X509Certificate2 sm_certificate = getCertificate();

        int                     m_port;
        
//        byte[][]                m_client_buffers;
//        byte[][]                m_server_buffers;
//        ManualResetEvent        m_terminated;
//        uint                    m_IO_count = 0;

        ManualResetEvent        m_synch_begin = new ManualResetEvent(false);
        SslStreamEx             m_server;
        SslStreamEx             m_client;

        #endregion Data Members
    }
}
