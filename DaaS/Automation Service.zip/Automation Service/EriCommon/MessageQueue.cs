﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace EriCommon
{
    /// <summary>
    /// The MessageQueue class creates and manages a queue of messages.
    /// </summary>
    public class MessageQueue
    {
        /// <summary>
        /// The Item abstract class.
        /// </summary>
        public abstract class Item : ProcessingItem
        {
            /// <summary>
            /// Sends itself to a message queue.
            /// </summary>
            public bool Send(MessageQueue message_queue)
            {
                return message_queue.Send(this, ref m_ack_event);
            }

            /// <summary>
            /// Posts itself to a message queue.
            /// </summary>
            public bool Post(MessageQueue message_queue)
            {
                return message_queue.Post(this);
            }

            internal void SetEvent()
            {
                if (m_ack_event != null)
                    m_ack_event.Set();
            }

            private ManualResetEvent m_ack_event;
        }

        /// <summary>
        /// Sends an item.
        /// </summary>
        public bool Send(Item item)
        {
            return item.Send(this);
        }

        private bool Send(Item item, ref ManualResetEvent ack_event)
        {
            if (m_ownerThread == Thread.CurrentThread)
            {
                if (m_queue.Disposed == false)
                {
                    m_queue.Proceed(item);
                    return true;
                }

                return false;
            }

            if (ack_event == null)
                ack_event = new ManualResetEvent(false);
            else
                ack_event.Reset();

            bool ok = m_queue.AddItem(item);

            if (ok)
                ack_event.WaitOne();

            return ok;
        }

        /// <summary>
        /// Posts an item.
        /// </summary>
        public bool Post(Item item)
        {
            return m_queue.AddItem(item);
        }

        /// <summary>
        /// Stops the message loop, disposing the queue.
        /// </summary>
        public void StopLoop()
        {
            m_queue.Dispose();
        }

        /// <summary>
        /// Creates a message queue and loops.
        /// </summary>
        public static void Loop(out MessageQueue message_queue)
        {
            message_queue = new MessageQueue();
            message_queue.m_queue.Loop();
        }

        private class ProcessingQueue : ProcessingQueueThread
        {
            public void Loop()
            {
                ProcessingItem item;
                base.Loop(out item);
            }

            internal override void Proceed(ProcessingItem item)
            {
                base.Proceed(item);
                ((Item)item).SetEvent();
            }
        }

        private MessageQueue() { }

        ProcessingQueue m_queue = new ProcessingQueue();
        Thread m_ownerThread = Thread.CurrentThread;
    }
}
