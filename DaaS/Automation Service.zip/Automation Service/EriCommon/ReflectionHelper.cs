﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Diagnostics;

namespace EriCommon
{
    /// <summary>
    /// The ReflectionHelper static class contains static functions dealing with the .NET reflection capability.
    /// </summary>
    public static class ReflectionHelper
    {
        /// <summary>
        /// Returns the class name of the caller (when skipFrames==1).
        /// </summary>
        public static string GetClassName(UInt32 skipFrames = 1)
        {
            Debug.Assert(skipFrames > 0);
            StackFrame frame = new StackFrame((int)skipFrames);
            System.Reflection.MethodBase method = frame.GetMethod();
            return method.DeclaringType.FullName;
        }

        /// <summary>
        /// Returns the class name of the caller (when skipFrames==1).
        /// </summary>
        public static string GetMethodName(UInt32 skipFrames = 1)
        {
            Debug.Assert(skipFrames > 0);
            StackFrame frame = new StackFrame((int)skipFrames);
            System.Reflection.MethodBase method = frame.GetMethod();
            return method.Name;
        }

        /// <summary>
        /// Returns the T interface from the specified assembly.
        /// The factory class must define (implicitly or explicitly) a default constructor.
        /// The factory class must define a non-public method named GetInterface that requires no parameters and returns the T interface.
        /// </summary>
        static T GetInterface<T>(string assembly_filename,          // a filename containing also extension
                                 string factory_full_class_name)    // a class name preceded by the the assembly name
        {
            Assembly assembly = Assembly.LoadFrom(assembly_filename);
            Type type = assembly.GetType(factory_full_class_name);

            object obj = Activator.CreateInstance(type);

            MethodInfo mi = type.GetMethod("GetInterface", BindingFlags.NonPublic | BindingFlags.Instance);

            return (T)mi.Invoke(obj, null);
        }

        /// <summary>
        /// Returns the T interface from the specified assembly.
        /// The assembly name and the DLL file title must be the same.
        /// The assembly file must reside in the current folder or in a folder contained in the search path.
        /// The assembly must contain a factory class named InterfaceFactory.
        /// The factory class must define (implicitly or explicitly) a public default constructor.
        /// The factory class must define a non-public method named GetInterface that requires no parameters and returns the T interface.
        /// </summary>
        static T GetInterface<T>(string assembly_name)          // the name of the assembly
        {
            return GetInterface<T>( assembly_name + ".dll",
                                    assembly_name + "." + "InterfaceFactory" );
        }
    }
}
