﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;

namespace EriCommon
{
    public static class ProcessHelper
    {
        public static int GetMainThreadId()
        {
            if (m_main_thread_id == 0)
            {
                Process process = Process.GetCurrentProcess();
                ProcessThreadCollection threads = process.Threads;

                DateTime prev = DateTime.Now,
                         curr;

                ProcessThread main_thread = null;

                foreach (ProcessThread pt in threads)
                {
                    curr = pt.StartTime;

                    if (prev > curr)
                    {
                        prev = curr;
                        main_thread = pt;
                    }
                }

                m_main_thread_id = main_thread.Id;
            }

            return m_main_thread_id;
        }

        public static bool IsMainThread()
        {
            return Thread.CurrentThread.ManagedThreadId == GetMainThreadId();
        }

        private static int m_main_thread_id;
    }
}
