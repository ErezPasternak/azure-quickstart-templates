﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Diagnostics;

namespace EriCommon
{
    /// <summary>
    /// The IPAddressRange class
    /// </summary>
    public class IPAddressRange
    {
        /// <summary>
        /// The AddressFamily
        /// </summary>
        public AddressFamily addressFamily { get; private set; }

        /// <summary>
        /// The lower address
        /// </summary>
        public byte[] lowerBytes { get; private set; }

        /// <summary>
        /// The upper address
        /// </summary>
        public byte[] upperBytes { get; private set; }

        /// <summary>
        /// The lower IPAddress
        /// </summary>
        public IPAddress LowerIPAddress
        {
            get { return new IPAddress(lowerBytes); }
        }

        /// <summary>
        /// The upper IPAddress
        /// </summary>
        public IPAddress UpperIPAddress
        {
            get { return new IPAddress(upperBytes); }
        }

        /// <summary>
        /// The lower IPAddress string
        /// </summary>
        public String LowerIP
        {
            get { return LowerIPAddress.ToString(); }
        }

        /// <summary>
        /// The upper IPAddress string
        /// </summary>
        public String UpperIP
        {
            get { return UpperIPAddress.ToString(); }
        }

        /// <summary>
        /// The c-tor using IPAddress-es
        /// </summary>
        public IPAddressRange(IPAddress lower, IPAddress upper)
        {
            initialize(lower, upper);
        }

        private void initialize(IPAddress lower, IPAddress upper)
        {
            // Assert that lower.AddressFamily == upper.AddressFamily
            Debug.Assert(lower.AddressFamily == upper.AddressFamily);

            if (lower.AddressFamily != upper.AddressFamily)
                throw new ArgumentException(String.Format("Address families do not match. Lower={0}, Upper={1}.", lower.ToString(), upper.ToString()));

            this.addressFamily  = lower.AddressFamily;
            this.lowerBytes     = lower.GetAddressBytes();
            this.upperBytes     = upper.GetAddressBytes();
        }

        /// <summary>
        /// The c-tor using strings
        /// </summary>
        public IPAddressRange(String lower, String upper)
        {
            initialize(IPAddress.Parse(lower), IPAddress.Parse(upper));
        }

        /// <summary>
        /// Returns true if its is
        /// </summary>
        public bool IsInRange(IPAddress address)
        {
            if (address.AddressFamily != addressFamily)
            {
                return false;
            }

            byte[] addressBytes = address.GetAddressBytes();

            bool lowerBoundary = true, upperBoundary = true;

            for (int i = 0; i < this.lowerBytes.Length &&
                (lowerBoundary || upperBoundary); i++)
            {
                if ((lowerBoundary && addressBytes[i] < lowerBytes[i]) ||
                    (upperBoundary && addressBytes[i] > upperBytes[i]))
                {
                    return false;
                }

                lowerBoundary &= (addressBytes[i] == lowerBytes[i]);
                upperBoundary &= (addressBytes[i] == upperBytes[i]);
            }

            return true;
        }

        /// <summary>
        /// Returns true if its is
        /// </summary>
        public bool IsInRange(String address)
        {
            return IsInRange( IPAddress.Parse(address));
        }
    }
}
