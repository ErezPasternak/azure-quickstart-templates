﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;

namespace EriCommon
{
    /// <summary>
    /// The SocketHelper static class contains static functions dealing with sockets, addresses, etc.
    /// </summary>
    public static class SocketHelper
    {
        /// <summary>
        /// On success sets ip_address and host_is_a_name to the appropriate values,
        /// otherwise an exception is thrown.
        /// </summary>
        public static void GetIPAddress(string remote_host, out IPAddress ip_address, out bool host_is_a_name, bool prefer_IPv4 = false)
        {
            if (IPAddress.TryParse(remote_host, out ip_address))
            {
                host_is_a_name = false;
            }
            else
            {
                // remote_host is a name, or an invalid IP address
                host_is_a_name = true;
                IPHostEntry host_entry = Dns.GetHostEntry(remote_host);
                ip_address = host_entry.AddressList[0];

                if (prefer_IPv4)
                {
                    if (ip_address.AddressFamily == AddressFamily.InterNetwork || host_entry.AddressList.Length == 1)
                        return;

                    IPAddress temp_ip_address;
                    for (int idx = 1; idx < host_entry.AddressList.Length; idx++)
                    {
                        temp_ip_address = host_entry.AddressList[idx];
                        if (temp_ip_address.AddressFamily == AddressFamily.InterNetwork)
                        {
                            ip_address = temp_ip_address;
                            break;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// On success sets ip_address to the appropriate values,
        /// otherwise an exception is thrown.
        /// </summary>
        public static void GetIPAddress(string remote_host, out IPAddress ip_address, bool prefer_IPv4 = false)
        {
            bool host_is_a_name;
            GetIPAddress(remote_host, out ip_address, out host_is_a_name, prefer_IPv4);
        }

        /// <summary>
        /// Async method version.
        /// On success sets ip_address and host_is_a_name to the appropriate values,
        /// otherwise an exception is thrown.
        /// </summary>
        public static async Task<Tuple<IPAddress, bool>> GetIPAddressAsync(string remote_host, bool prefer_IPv4 = false)
        {
            IPAddress ip_address;
            bool host_is_a_name;

            if (IPAddress.TryParse(remote_host, out ip_address))
            {
                host_is_a_name = false;
            }
            else
            {
                // remote_host is a name, or an invalid IP address
                host_is_a_name = true;
                IPHostEntry host_entry = await Dns.GetHostEntryAsync(remote_host);
                ip_address = host_entry.AddressList[0];

                if (prefer_IPv4                                             &&
                    ip_address.AddressFamily != AddressFamily.InterNetwork  &&
                    host_entry.AddressList.Length > 1)
                {
                    IPAddress temp_ip_address;
                    for (int idx = 1; idx < host_entry.AddressList.Length; idx++)
                    {
                        temp_ip_address = host_entry.AddressList[idx];
                        if (temp_ip_address.AddressFamily == AddressFamily.InterNetwork)
                        {
                            ip_address = temp_ip_address;
                            break;
                        }
                    }
                }
            }

            return Tuple.Create(ip_address, host_is_a_name);
        }
    }
}
