﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace EriCommon
{
    /// <summary>
    /// The RwLock class envelopes the ReaderWriterLockSlim object.
    /// </summary>
    public class RwLock
    {
        /// <summary>
        /// The RwLock ctor, initializes the ReaderWriterLockSlim object.
        /// </summary>
        public RwLock(bool supports_recursion)
        {
            m_lock = new ReaderWriterLockSlim(supports_recursion ? LockRecursionPolicy.SupportsRecursion : LockRecursionPolicy.NoRecursion);
        }

        /// <summary>
        /// The EnterReadLock wrapper.
        /// </summary>
        public Unlocker EnterReadLock()
        {
            m_lock.EnterReadLock();
            return new Unlocker(m_lock, LockMode.Read);
        }

        /// <summary>
        /// The EnterUpgradeableReadLock wrapper.
        /// </summary>
        public Unlocker EnterUpgradeableReadLock()
        {
            m_lock.EnterUpgradeableReadLock();
            return new Unlocker(m_lock, LockMode.UpgradeableRead);
        }

        /// <summary>
        /// The EnterWriteLock wrapper.
        /// </summary>
        public Unlocker EnterWriteLock()
        {
            m_lock.EnterWriteLock();
            return new Unlocker(m_lock, LockMode.Write);
        }

        /// <summary>
        /// The TryEnterReadLock wrapper.
        /// </summary>
        public Unlocker TryEnterReadLock(int millisecondsTimeout, out bool granted)
        {
            granted = m_lock.TryEnterReadLock(millisecondsTimeout);
            return new Unlocker(granted ? m_lock : null, LockMode.Read);
        }

        /// <summary>
        /// The TryEnterUpgradeableReadLock wrapper.
        /// </summary>
        public Unlocker TryEnterUpgradeableReadLock(int millisecondsTimeout, out bool granted)
        {
            granted = m_lock.TryEnterUpgradeableReadLock(millisecondsTimeout);
            return new Unlocker(granted ? m_lock : null, LockMode.Read);
        }

        /// <summary>
        /// The TryEnterWriteLock wrapper.
        /// </summary>
        public Unlocker TryEnterWriteLock(int millisecondsTimeout, out bool granted)
        {
            granted = m_lock.TryEnterWriteLock(millisecondsTimeout);
            return new Unlocker(granted ? m_lock : null, LockMode.Read);
        }

        /// <summary>
        /// The TryEnterReadLock wrapper.
        /// </summary>
        public Unlocker TryEnterReadLock(TimeSpan timeout, out bool granted)
        {
            granted = m_lock.TryEnterReadLock(timeout);
            return new Unlocker(granted ? m_lock : null, LockMode.Read);
        }

        /// <summary>
        /// The TryEnterUpgradeableReadLock wrapper.
        /// </summary>
        public Unlocker TryEnterUpgradeableReadLock(TimeSpan timeout, out bool granted)
        {
            granted = m_lock.TryEnterUpgradeableReadLock(timeout);
            return new Unlocker(granted ? m_lock : null, LockMode.Read);
        }

        /// <summary>
        /// The TryEnterWriteLock wrapper.
        /// </summary>
        public Unlocker TryEnterWriteLock(TimeSpan timeout, out bool granted)
        {
            granted = m_lock.TryEnterWriteLock(timeout);
            return new Unlocker(granted ? m_lock : null, LockMode.Read);
        }

        internal enum LockMode { Read, UpgradeableRead, Write };

        /// <summary>
        /// The Unlocker class.
        /// </summary>
        public class Unlocker : IDisposable
        {
            private readonly LockMode m_mode;
            private ReaderWriterLockSlim m_lock;

            internal Unlocker(ReaderWriterLockSlim lck, LockMode mode)
            {
                m_mode = mode;
                m_lock = lck;
            }

            /// <summary>
            /// The Unlocker dtor.
            /// </summary>
            ~Unlocker()
            {
                Debug.Assert(m_lock == null); // not used in a 'using' block
            }

            /// <summary>
            /// Unlocks the ReaderWriterLockSlim object.
            /// </summary>
            public void Dispose()
            {
                if (m_lock == null)
                    return;

                switch (m_mode)
                {
                    case LockMode.Read: m_lock.ExitReadLock(); break;
                    case LockMode.UpgradeableRead: m_lock.ExitUpgradeableReadLock(); break;
                    case LockMode.Write: m_lock.ExitWriteLock(); break;
                }

                m_lock = null;
            }
        }

        private ReaderWriterLockSlim m_lock;
    }
}
