﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace EriCommon
{
    public partial class Server
    {
        class NameFormat
        {
            public NameFormat(uint default_length, bool append_new_line)
            {
                m_default_length = default_length;
                m_append_new_line = append_new_line;
                Length = default_length;
            }

            public uint Length
            {
                get { return m_length; }
                set
                {
                    Debug.Assert(value >= m_default_length);
                    if (value < m_default_length || value == m_length)
                        return;

                    m_length = value;
                    m_format = String.Format("{{0,-{0}}}: {{1}}", m_length);
                    if (m_append_new_line)
                        m_format += '\n';
                }
            }

            public override String ToString()
            {
                return m_format;
            }

            private readonly uint m_default_length;
            private readonly bool m_append_new_line;
            private uint m_length;
            private String m_format;
        }
    }
}
