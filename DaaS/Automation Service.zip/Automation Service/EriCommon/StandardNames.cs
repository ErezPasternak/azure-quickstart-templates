﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.DirectoryServices.ActiveDirectory;

namespace EriCommon
{
    /// <summary>
    /// The StandardNames helper class defines standardization for names.
    /// </summary>
    public static class StandardNames
    {
        static String st_ComputerDomainName = "\n";
        /// <summary>
        /// Returns the computer domain name, if the computer is part of a domain, otherwise null.
        /// </summary>
        public static string GetComputerDomainName()
        {
            lock (st_ComputerDomainName)
            {
                if (st_ComputerDomainName == "\n")
                {
                    try
                    {
                        st_ComputerDomainName = Domain.GetComputerDomain().Name;
                    }
                    catch (System.Exception)
                    {
                        // the machine is not part of a domain
                        st_ComputerDomainName = String.Empty;
                    }
                }
            }

            return st_ComputerDomainName;
        }

        /// <summary>
        /// Returns the computer name.
        /// </summary>
        public static string GetComputerName()
        {
            return Environment.MachineName;
        }

        /// <summary>
        /// Returns the full computer name, in the format computer_name[.domain_name].
        /// </summary>
        public static string GetFullComputerName()
        {
            string domain_name;

            try
            {
                domain_name = "." + GetComputerDomainName();
            }
            catch (System.Exception)
            {
                domain_name = "";
                // The there is no domain, that's OK
            }

            return Environment.MachineName + domain_name;
        }

        static String st_UserDomainName = "\n";
        /// <summary>
        /// Returns the user domain name, if the user is part of a domain, otherwise null.
        /// </summary>
        public static string GetUserDomainName()
        {
            lock (st_UserDomainName)
            {
                if (st_UserDomainName == "\n")
                {
                    try
                    {
                        st_UserDomainName = Domain.GetCurrentDomain().Name;
                    }
                    catch (System.Exception)
                    {
                        // the machine is not part of a domain
                        st_UserDomainName = String.Empty;
                    }
                }

            }

            return st_UserDomainName;
        }

        /// <summary>
        /// Returns the user name.
        /// </summary>
        public static string GetUserName()
        {
            return Environment.UserName;
        }

        /// <summary>
        /// Returns the full user name, in the format user_name[@domain_name].
        /// </summary>
        public static string GetFullUserName()
        {
            string domain_name;

            try
            {
                domain_name = "@" + GetUserDomainName();
            }
            catch (System.Exception)
            {
                domain_name = "";
                // The there is no domain, that's OK
            }

            return Environment.UserName + domain_name;
        }
    }
}
