using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using TracerX.Properties;
using System.Diagnostics;

namespace TracerX.Viewer {
    internal partial class FilterDialog : Form {
        private MainForm _mainForm = MainForm.TheMainForm;
        private ColumnHeader _clickedHeader;
        private bool _suppressEvents = true;
        private ListViewItemSorter _threadIdSorter;
        private ListViewItemSorter _sessionSorter;
        private ListViewItemSorter _threadNameSorter;
        private ListViewItemSorter _loggerSorter;
        private ListViewItemSorter _methodSorter;

        public FilterDialog() {
            InitializeComponent();

            this.Icon = Properties.Resources.scroll_view;
            InitTraceLevels();
            InitSessions();
            InitThreadIds();
            InitThreadNames();
            InitLoggers();
            InitMethods();
            InitText();

            _suppressEvents = true;
        }

        public FilterDialog(ColumnHeader clickedHeader) : this() {
            _clickedHeader = clickedHeader;

            if (_clickedHeader == _mainForm.headerLevel) {
                tabControl1.SelectedTab = traceLevelPage;
            } else if (_clickedHeader == _mainForm.headerSession) {
                tabControl1.SelectedTab = sessionPage;
            } else if (_clickedHeader == _mainForm.headerLogger) {
                tabControl1.SelectedTab = loggerPage;
            } else if (_clickedHeader == _mainForm.headerMethod) {
                tabControl1.SelectedTab = methodPage;
            } else if (_clickedHeader == _mainForm.headerThreadId) {
                tabControl1.SelectedTab = threadIdPage;
            } else if (_clickedHeader == _mainForm.headerThreadName) {
                tabControl1.SelectedTab = threadNamePage;
            } else if (_clickedHeader == _mainForm.headerText) {
                tabControl1.SelectedTab = textPage;
            }
        }

        // Create a delegate to compare the Checked states of two ListViewItems
        // for sorting via ListViewItemSorter.
        private ListViewItemSorter.RowComparer _checkComparer = delegate(ListViewItem x, ListViewItem y) {
            if (x.Checked == y.Checked) return 0;
            if (x.Checked) return 1;
            else return -1;
        };

        protected override void OnLoad(EventArgs e) {
            base.OnLoad(e);

            ok.Enabled = false;   
            apply.Enabled = false; 
            _suppressEvents = false;
        }

        private void AnyListView_ItemChecked(object sender, ItemCheckedEventArgs e) {
            if (_suppressEvents) return;
            ok.Enabled = true;
            apply.Enabled = true;

            IndicateTabFilter(sessionPage, sessionListView);
            Int32 seconds = IndicateTabFilter(loggerPage, loggerListView);
            System.Diagnostics.Debug.WriteLine("IndicateTabFilter(loggerPage, loggerListView): {0}", seconds);
            IndicateTabFilter(methodPage, methodListView);
            IndicateTabFilter(threadNamePage, threadNameListView);
            IndicateTabFilter(threadIdPage, threadIdListView);
        }

        private Int32 IndicateTabFilter(TabPage page, ListView listView)
        {
            int Count = listView.Items.Count;
            Int64 started_at = DateTime.Now.Ticks;
            ListView.CheckedListViewItemCollection CheckedItems = listView.CheckedItems;
//            int CheckedItemsCount = CheckedItems.Count;
            int CheckedItemsCount = 0;
            foreach (ListViewItem item in listView.Items)
            {
                if (item.Checked)
                        CheckedItemsCount++;
            }

            Int64 done_at = DateTime.Now.Ticks;
            Int32 seconds = (Int32)((done_at - started_at) / (1000 * 10000));

            bool isFiltered = CheckedItemsCount != Count;

            if (page.Text[0] == '*')
            {
                if (!isFiltered)
                {
                    page.Text = page.Text.Trim('*');
                }
            }
            else
            {
                if (isFiltered)
                {
                    page.Text = "*" + page.Text;
                }
            }

            return seconds;
        }


        // For some reason, the AnyListView_ItemChecked event occurs when switching
        // between tabs that have ListViews.  Use the Selecting and SelectedIndexChanged
        // events to prevent OK and Apply from getting enabled just by switching tabs.
        private void tabControl1_Selecting(object sender, TabControlCancelEventArgs e) {
            _suppressEvents = true;
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e) {
            _suppressEvents = false;
        }

        private void ok_Click(object sender, EventArgs e) {
            apply_Click(null, null);
        }

        private void apply_Click(object sender, EventArgs e) {
            _mainForm.VisibleTraceLevels = SelectedTraceLevels;
            _mainForm.FilteredBySession = ApplySessionSelection();
            _mainForm.FilteredByThreadId = ApplyThreadIdSelection();
            _mainForm.FilteredByThreadName = ApplyThreadNameSelection();
            _mainForm.FilteredByLogger = ApplyLoggerSelection();
            _mainForm.FilteredByMethod = ApplyMethodSelection();
            _mainForm.FilteredByText = ApplyTextSelection();

            Debug.Assert((_mainForm.VisibleTraceLevels & TraceLevel.Verbose) == 0);
            _mainForm.FilteredByTraceLevels = _mainForm.VisibleTraceLevels != 
                                                                         (TraceLevel.Fatal   |
                                                                         TraceLevel.Error   |
                                                                         TraceLevel.Warn    |
                                                                         TraceLevel.Info    |
//                                                                         TraceLevel.Verbose |
                                                                         TraceLevel.Debug);
            _mainForm.Filtered = _mainForm.FilteredByTraceLevels ||
                                 _mainForm.FilteredBySession ||
                                 _mainForm.FilteredByThreadId ||
                                 _mainForm.FilteredByThreadName ||
                                 _mainForm.FilteredByLogger ||
                                 _mainForm.FilteredByMethod ||
                                 _mainForm.FilteredByText;

            ok.Enabled = false;
            apply.Enabled = false; 
            _mainForm.RebuildAllRows();
        }

        #region Trace Levels   
     
        private void InitTraceLevels() {
            // Display only the trace levels that actually exist in the file.
            int index = 0;
            traceLevelListBox.Items.Clear();
            foreach (TraceLevel level in Enum.GetValues(typeof(TraceLevel))) {
                if (level != TraceLevel.Inherited && (level & _mainForm.ValidTraceLevels) != 0) {
                    traceLevelListBox.Items.Add(level);
                    traceLevelListBox.SetItemChecked(index, (level & _mainForm.VisibleTraceLevels) != 0);
                    ++index;
                } 
            }

            IndicateTraceLevelFilter(_mainForm.ValidTraceLevels != _mainForm.VisibleTraceLevels);
        }

        private void IndicateTraceLevelFilter(bool isFiltered)
        {
            if (traceLevelPage.Text[0] == '*')
            {
                if (!isFiltered)
                {
                    traceLevelPage.Text = traceLevelPage.Text.Trim('*');
                }
            }
            else
            {
                if (isFiltered)
                {
                    traceLevelPage.Text = "*" + traceLevelPage.Text;
                }
            }
        }

        public TraceLevel SelectedTraceLevels {
            get {
                TraceLevel retval = TraceLevel.Inherited; // I.e. 0.
                foreach (TraceLevel level in traceLevelListBox.CheckedItems) {
                    retval |= level;
                }

                return retval;
            }
        }

        private void traceLevelListBox_ItemCheck(object sender, ItemCheckEventArgs e) {
            if (_suppressEvents) return;
            //ok.Enabled = e.NewValue == CheckState.Checked || traceLevelListBox.CheckedItems.Count > 1;
            apply.Enabled = true;
            ok.Enabled = true;

            int checkedCount = traceLevelListBox.CheckedItems.Count;

            if (e.NewValue == CheckState.Checked)
            {
                ++checkedCount;
            }
            else
            {
                --checkedCount;
            }

            IndicateTraceLevelFilter(checkedCount != traceLevelListBox.Items.Count);
        }

        private void selectAllTraceLevels_Click(object sender, EventArgs e) {
            for (int i = 0; i < traceLevelListBox.Items.Count; ++i) {
                traceLevelListBox.SetItemChecked(i, true);
            }
        }

        private void clearAllTraceLevels_Click(object sender, EventArgs e) {
            for (int i = 0; i < traceLevelListBox.Items.Count; ++i) {
                traceLevelListBox.SetItemChecked(i, false);
            }
        }

        private void invertTraceLevels_Click(object sender, EventArgs e) {
            for (int i = 0; i < traceLevelListBox.Items.Count; ++i) {
                bool x = traceLevelListBox.GetItemChecked(i);
                traceLevelListBox.SetItemChecked(i, !x);
            }
        }

        private void traceLevelListBox_Format(object sender, ListControlConvertEventArgs e) {
            e.Value = Enum.GetName(typeof(TraceLevel), e.ListItem);
        }
        #endregion Trace Levels

        #region Sessions

        private void InitSessions() {
            sessionListView.BeginUpdate();

            // Populate the session listview from SessionObjects.AllSessions.
            lock (SessionObjects.Lock) {
                foreach (Reader.Session ses in SessionObjects.AllSessionObjects) {
                    ListViewItem item = new ListViewItem(new string[] { string.Empty, ses.Name });
                    item.Checked = ses.Visible;
                    item.Tag = ses;
                    this.sessionListView.Items.Add(item);
                }
            }

            sessionCheckCol.Width = -1;
            sessionListView.EndUpdate();
            IndicateTabFilter(sessionPage, sessionListView);
        }

        private void checkAll( ListView list_view, TabPage page )
        {
            bool hold_suppress = _suppressEvents;
            _suppressEvents = true;

            try
            {
                foreach (ListViewItem item in list_view.Items)
                    item.Checked = true;
            }
            finally
            {
                IndicateTabFilter(page, list_view);
            	_suppressEvents = hold_suppress;
            }
        }

        private void uncheckAll(ListView list_view, TabPage page)
        {
            bool hold_suppress = _suppressEvents;
            _suppressEvents = true;

            try
            {
                foreach (ListViewItem item in list_view.Items)
                    item.Checked = false;
            }
            finally
            {
                IndicateTabFilter(page, list_view);
                _suppressEvents = hold_suppress;
            }
        }

        private void invertAll(ListView list_view, TabPage page)
        {
            bool hold_suppress = _suppressEvents;
            _suppressEvents = true;

            try
            {
                foreach (ListViewItem item in list_view.Items)
                    item.Checked = !item.Checked;
            }
            finally
            {
                IndicateTabFilter(page, list_view);
                _suppressEvents = hold_suppress;
            }
        }

        private bool ApplySessionSelection() {
            bool filtered = false;
            foreach (ListViewItem item in sessionListView.Items) {
                Reader.Session ses = (Reader.Session)item.Tag;
                ses.Visible = item.Checked;

                if (item.Checked == false)
                    filtered = true;
            }

            return filtered;
        }

        private void checkAllSessions_Click(object sender, EventArgs e) {
            checkAll( sessionListView, sessionPage );
        }

        private void uncheckAllSessionss_Click(object sender, EventArgs e) {
            uncheckAll( sessionListView, sessionPage );
        }

        private void invertSessions_Click(object sender, EventArgs e) {
            invertAll( sessionListView, sessionPage );
        }

        private void sessionListView_ColumnClick(object sender, ColumnClickEventArgs e) {
            _suppressEvents = true;
            // Create the sorting objects the first time they are required.
            if (_sessionSorter == null) {
                // Create a delegate for comparing the IDs of the Session objects that
                // correspond to two ListViewItems.
                ListViewItemSorter.RowComparer idComparer = delegate(ListViewItem x, ListViewItem y) {
                    // The ListViewItem tags are ThreadObjects.
                    int xint = ((Reader.Session)x.Tag).Index;
                    int yint = ((Reader.Session)y.Tag).Index;

                    return xint - yint;
                };

                sessionCol.Tag = idComparer;
                sessionCheckCol.Tag = _checkComparer;
                _sessionSorter = new ListViewItemSorter(sessionListView);
            }

            _sessionSorter.Sort(e.Column);
            _suppressEvents = false;
        }
        #endregion Sessions

        #region Thread Ids

        private void InitThreadIds() {
            threadIdListView.BeginUpdate();

            // Populate the thread ID listview from ThreadObjects.AllThreads.
            lock (ThreadObjects.Lock)
            {
                foreach (ThreadObject thread in ThreadObjects.AllThreadObjects)
                {
                    ListViewItem item = new ListViewItem(new string[] { string.Empty, thread.Id.ToString() });
                    item.Checked = thread.Visible;
                    item.Tag = thread;
                    this.threadIdListView.Items.Add(item);
                }
            }

            threadCheckCol.Width = -1;
            //threadIdCol.Width = -1;
            threadIdListView.EndUpdate();
            IndicateTabFilter(threadIdPage, threadIdListView);
        }

        private bool ApplyThreadIdSelection() {
            bool filtered = false;
            foreach (ListViewItem item in threadIdListView.Items) {
                ThreadObject thread = (ThreadObject)item.Tag;
                thread.Visible = item.Checked;

                if (item.Checked == false)
                    filtered = true;
            }

            return filtered;
        }

        private void checkAllThreadIds_Click(object sender, EventArgs e) {
            checkAll( threadIdListView, threadIdPage );
        }

        private void uncheckAllThreadIds_Click(object sender, EventArgs e) {
            uncheckAll( threadIdListView, threadIdPage );
        }

        private void invertThreadIDs_Click(object sender, EventArgs e) {
            invertAll( threadIdListView, threadIdPage );
        }

        private void threadIdListView_ColumnClick(object sender, ColumnClickEventArgs e) {
            _suppressEvents = true;
            // Create the sorting objects the first time they are required.
            if (_threadIdSorter == null) {
                // Create a delegate for comparing the IDs of the ThreadObjects that
                // correspond to two ListViewItems.
                ListViewItemSorter.RowComparer idComparer = delegate(ListViewItem x, ListViewItem y) {
                    // The ListViewItem tags are ThreadObjects.
                    int xint = ((ThreadObject)x.Tag).Id;
                    int yint = ((ThreadObject)y.Tag).Id;

                    return xint - yint;
                };

                threadIdCol.Tag = idComparer;
                threadCheckCol.Tag = _checkComparer;
                _threadIdSorter = new ListViewItemSorter(threadIdListView);
            }

            _threadIdSorter.Sort(e.Column);
            _suppressEvents = false;
        }
        #endregion Thread Ids

        #region Thread Names
        private void InitThreadNames() {
            threadNameListView.BeginUpdate();

            // Populate the thread name listview from ThreadNames.AllThreads.
            lock (ThreadNames.Lock)
            {
                foreach (ThreadName thread in ThreadNames.AllThreadNames)
                {
                    ListViewItem item = new ListViewItem(new string[] { string.Empty, thread.Name });
                    item.Checked = thread.Visible;
                    item.Tag = thread;
                    this.threadNameListView.Items.Add(item);
                }
            }

            threadNameCheckCol.Width = -1;
            //threadNameNameCol.Width = -1;            
            threadNameListView.EndUpdate();
            IndicateTabFilter(threadNamePage, threadNameListView);
        }

        private bool ApplyThreadNameSelection() {
            bool filtered = false;
            foreach (ListViewItem item in threadNameListView.Items) {
                ThreadName thread = (ThreadName)item.Tag;
                thread.Visible = item.Checked;

                if (item.Checked == false)
                    filtered = true;
            }

            return filtered;
        }

        private void checkAllThreadNames_Click(object sender, EventArgs e) {
            checkAll( threadNameListView, threadNamePage );
        }

        private void uncheckAllThreadNames_Click(object sender, EventArgs e) {
            uncheckAll( threadNameListView, threadNamePage );
        }

        private void invertThreadNames_Click(object sender, EventArgs e) {
            invertAll( threadNameListView, threadNamePage );
        }

        private void threadNameListView_ColumnClick(object sender, ColumnClickEventArgs e) {
            _suppressEvents = true;
            // Create the sorting objects the first time they are required.
            if (_threadNameSorter == null) {
                _threadNameSorter = new ListViewItemSorter(threadNameListView);
                threadNameCheckCol.Tag = _checkComparer;
            }

            _threadNameSorter.Sort(e.Column);
            _suppressEvents = false;
        }
        #endregion Thread Names

        #region Loggers

        private void InitLoggers() {
            lock (LoggerObjects.Lock) {
                foreach (LoggerObject logger in LoggerObjects.AllLoggers) {
                    ListViewItem item = new ListViewItem(new string[] { string.Empty, logger.Name });
                    item.Checked = logger.Visible;
                    item.Tag = logger;
                    this.loggerListView.Items.Add(item);
                }
            }

            SortLoggers(loggerNameCol.Index);
            IndicateTabFilter(loggerPage, loggerListView);
        }

        private void checkAllLoggers_Click(object sender, EventArgs e) {
            checkAll(loggerListView,loggerPage);
        }

        private void uncheckAllLoggers_Click(object sender, EventArgs e) {
            uncheckAll(loggerListView, loggerPage);
        }

        private void invertLoggers_Click(object sender, EventArgs e) {
            invertAll(loggerListView, loggerPage);
        }

        private bool ApplyLoggerSelection() {
            bool filtered = false;
            foreach (ListViewItem item in loggerListView.Items)
            {
                LoggerObject logger = (LoggerObject)item.Tag;
                bool prev_Visible = logger.Visible;
                logger.Visible = item.Checked;

                if (prev_Visible != logger.Visible)
                    MainForm.TheMainForm.FilteredByLoggerRoot = null;

                if (item.Checked == false)
                    filtered = true;
            }

            return filtered;
        }

        private void loggerListView_ColumnClick(object sender, ColumnClickEventArgs e) {
            SortLoggers(e.Column);
        }

        private void SortLoggers(int colIndex)
        {
            _suppressEvents = true;
            // Create the sorter object the first time it is required.
            if (_loggerSorter == null)
            {
                loggerCheckCol.Tag = _checkComparer;
                _loggerSorter = new ListViewItemSorter(loggerListView);
            }

            _loggerSorter.Sort(colIndex);
            _suppressEvents = false;
        }

        #endregion Loggers

        #region Methods

        private void InitMethods() {
            lock (MethodObjects.Lock) {
                foreach (MethodObject method in MethodObjects.AllMethods) {
                    ListViewItem item = new ListViewItem(new string[] { string.Empty, method.Name });
                    item.Checked = method.Visible;
                    item.Tag = method;
                    this.methodListView.Items.Add(item);
                }

                calledMethodsChk.Checked = Settings.Default.ShowCalledMethods;
            }

            IndicateTabFilter(methodPage, methodListView);
        }

        private void checkAllMethodss_Click(object sender, EventArgs e) {
            checkAll( methodListView, methodPage );
        }

        private void uncheckAllMethods_Click(object sender, EventArgs e) {
            uncheckAll( methodListView, methodPage );
        }

        private void invertMethods_Click(object sender, EventArgs e) {
            invertAll( methodListView, methodPage );
        }

        private bool ApplyMethodSelection() {
            bool filtered = false;
            foreach (ListViewItem item in methodListView.Items)
            {
                MethodObject method = (MethodObject)item.Tag;
                method.Visible = item.Checked;

                if (item.Checked == false)
                    filtered = true;
            }

            Settings.Default.ShowCalledMethods = calledMethodsChk.Checked;

            return filtered;
        }

        private void methodListView_ColumnClick(object sender, ColumnClickEventArgs e) {
            _suppressEvents = true;
            // Create the sorter object the first time it is required.
            if (_methodSorter == null) {
                methodCheckCol.Tag = _checkComparer;
                _methodSorter = new ListViewItemSorter(methodListView);
            }

            _methodSorter.Sort(e.Column);
            _suppressEvents = false;
        }

        private void calledMethodsChk_CheckedChanged(object sender, EventArgs e) {
            ok.Enabled = true;
            apply.Enabled = true;
        }

        #endregion Methods

        #region Text

        // Text filter settings live here.  Others have their own classes.
        private static string _includeText;
        private static string _excludeText;
        private static bool _includeChecked;
        private static bool _excludeChecked;
        private static bool _caseChecked;
        private static bool _wildChecked;
        private static bool _regexChecked;
        private static StringMatcher _includeMatcher;
        private static StringMatcher _excludeMatcher;

        public static event EventHandler TextFilterOnOff;

        /// <summary>True if text filtering is in effect.</summary>
        public static bool TextFilterOn {
            get { return _includeChecked || _excludeChecked; }
        }

        /// <summary>Turns text filtering off.</summary>
        public static void TextFilterDisable() {
            if (TextFilterOn) {
                _includeChecked = false;
                _excludeChecked = false;
                OnTextFilterOnOff(null);
            }
        }

        /// <summary>Determines if the string passes the text filter.</summary>
        public static bool TextFilterTestString(string line) {
            bool pass = true;

            if (_includeChecked) {
                pass = _includeMatcher.Matches(line);
            }

            if (pass && _excludeChecked) {
                pass = !_excludeMatcher.Matches(line);
            }

            return pass;
        }

        private static void OnTextFilterOnOff(object sender) {
            if (TextFilterOnOff != null)
                TextFilterOnOff(sender, EventArgs.Empty);
        }

        // Initialize the controls based on the static properties.
        private void InitText() {
            txtContains.Text = _includeText;
            chkContain.Checked = _includeChecked;

            txtDoesNotContain.Text = _excludeText;
            chkDoesNotContain.Checked = _excludeChecked;

            chkCase.Checked = _caseChecked;
            radWildcard.Checked = _wildChecked;            
            radRegex.Checked = _regexChecked;

            chkShowMultiline.Checked = MainForm.TheMainForm.TextFilterShowMultiline;

            //if (TextFilterOn) textPage.Text = "*" + textPage.Text;
        }

        // Set the static properties based on the controls.
        private bool ApplyTextSelection() {
            bool wasOn = TextFilterOn;
            MatchType matchType;

            _includeChecked = chkContain.Checked && !string.IsNullOrEmpty(txtContains.Text);
            _includeText = txtContains.Text;

            _excludeChecked = chkDoesNotContain.Checked && !string.IsNullOrEmpty(txtDoesNotContain.Text);
            _excludeText = txtDoesNotContain.Text;
            
            _caseChecked = chkCase.Checked;
            _wildChecked = radWildcard.Checked;
            _regexChecked = radRegex.Checked;

            MainForm.TheMainForm.TextFilterShowMultiline = chkShowMultiline.Checked;
            // TODO: radNormal.Checked?

            if (_regexChecked) {
                matchType = MatchType.RegularExpression;
            } else if (_wildChecked) {
                matchType = MatchType.Wildcard;
            } else {
                matchType = MatchType.Simple;
            }

            if (_includeChecked) {
                _includeMatcher = new StringMatcher(_includeText, chkCase.Checked, matchType);
            }

            if (_excludeChecked) {
                _excludeMatcher = new StringMatcher(_excludeText, chkCase.Checked, matchType);
            }

            if (TextFilterOn != wasOn) 
                OnTextFilterOnOff(this);

            return TextFilterOn;
        }

        private void Text_CheckboxChanged(object sender, EventArgs e) {
            txtContains.Enabled = chkContain.Checked;
            txtDoesNotContain.Enabled = chkDoesNotContain.Checked;

            if (_suppressEvents) return;
            
            ok.Enabled = true;
            apply.Enabled = true;

            textPage.Text = textPage.Text.Trim('*');

            if (chkContain.Checked || chkDoesNotContain.Checked)
            {
                textPage.Text = "*" + textPage.Text;
            }
        }

        private void Text_FilterTextChanged(object sender, EventArgs e) {
            if (_suppressEvents) return;
            ok.Enabled = true;
            apply.Enabled = true;
        }
        #endregion Text

        private void FilterDialog_Shown(object sender, EventArgs e)
        {
            _suppressEvents = false;
        }

        private void loggerListView_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}