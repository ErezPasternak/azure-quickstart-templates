﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.IO;
using System.Runtime.Serialization.Json;

namespace TracerX
{
    /// <summary>
    /// Yochai.......
    /// </summary>
    ///
    public class LoggerEx
    {
        /// <summary>
        /// Yochai.......
        /// </summary>
        ///
        public LoggerEx(Logger logger, String id)
        {
            m_logger = logger;
            m_id = id;
            m_decorated_id = String.Format("[{0}]", m_id);
        }

        /// <summary>
        /// Returns the message without markers
        /// </summary>
        public static String GetMessage(String message)
        {
            String id, context, netto_message;
            return SplitMessage(message, out id, out context, out netto_message);
        }

        public static String SplitMessage(String message, out String id, out String context, out String netto_message)
        {
            id = null;
            context = null;
            netto_message = message;

            String[] parts = message.Split(new string[] { st_marker_bin }, StringSplitOptions.RemoveEmptyEntries);

            Debug.Assert(parts.Count() >= 1 && parts.Count() <= 3);

            if (parts.Count() == 1)
            {
                return message;
            }

            id = parts[0];

            if (parts.Count() == 3)
            {
                context = parts[1];
                netto_message = parts[2];
            }
            else
            {
                // no context
                netto_message = parts[1];
            }

            return get_message(id, netto_message);
        }

        /// <summary>
        /// Associate a log context
        /// </summary>
        /// <param name="context"></param>
        public void SetContext(Object context)
        {
            if (context != null)
            {
                if (context is String)
                {
                    m_context = (String)context;
                }
                else
                {
                    m_context = ContextToString(context);
                }
            }
            else
            {
                m_context = null;
            }
        }

        private static String get_message(String id, String netto_message)
        {
            return id + " " + netto_message;
        }

        /// <summary>
        /// Serializes the context from object to (JSON) string
        /// </summary>
        /// <param name="contextObj"></param>
        /// <returns></returns>
        static private string ContextToString(Object contextObj)
        {
            // serialize to JSON
            using (MemoryStream stream = new MemoryStream())
            {
                DataContractJsonSerializer ser = new DataContractJsonSerializer(contextObj.GetType());
                ser.WriteObject(stream, contextObj);
                return Encoding.UTF8.GetString(stream.ToArray());
            }
        }

        /// <summary>
        /// De-serializes the context from (JSON) string to Object
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="contextStr"></param>
        /// <returns></returns>
        static public T StringToContext<T>(String contextStr)
        {
            // deserialize from JSON
            using (MemoryStream stream = new MemoryStream())
            {
                byte[] b = Encoding.UTF8.GetBytes(contextStr);
                stream.Write(b, 0, b.Length);
                stream.Position = 0;

                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(T));
                return (T)ser.ReadObject(stream);
            }
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        ///
        public void Log(TracerX.TraceLevel level, params object[] items)
        {
            if (m_logger.IsLevelEnabled(level) == false)
                return;

            String header = m_decorated_id + st_marker_bin;

            if (m_context != null)
            {
                header += m_context + st_marker_bin;
            }

            object[] result = new object[items.Length + 1];
            result[0] = header;
            Array.Copy(items, 0, result, 1, items.Length);

            switch (level)
            {
                case TracerX.TraceLevel.Fatal:
                    {
                        m_logger.Fatal(result);
                        break;
                    }
                case TracerX.TraceLevel.Error:
                    {
                        m_logger.Error(result);
                        break;
                    }
                case TracerX.TraceLevel.Warn:
                    {
                        m_logger.Warn(result);
                        break;
                    }
                case TracerX.TraceLevel.Info:
                    {
                        m_logger.Info(result);
                        break;
                    }
                case TracerX.TraceLevel.Debug:
                    {
                        m_logger.Debug(result);
                        break;
                    }
                case TracerX.TraceLevel.Verbose:
                    {
                        m_logger.Verbose(result);
                        break;
                    }
            }
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        ///
        public void EnforceLog(TracerX.TraceLevel level, params object[] items)
        {
            String header = m_decorated_id + st_marker_bin;

            if (m_context != null)
            {
                header += m_context + st_marker_bin;
            }

            object[] result = new object[items.Length + 1];
            result[0] = header;
            Array.Copy(items, 0, result, 1, items.Length);

            switch (level)
            {
                case TracerX.TraceLevel.Fatal:
                    {
                        m_logger.EnforceFatal(result);
                        break;
                    }
                case TracerX.TraceLevel.Error:
                    {
                        m_logger.EnforceError(result);
                        break;
                    }
                case TracerX.TraceLevel.Warn:
                    {
                        m_logger.EnforceWarn(result);
                        break;
                    }
                case TracerX.TraceLevel.Info:
                    {
                        m_logger.EnforceInfo(result);
                        break;
                    }
                case TracerX.TraceLevel.Debug:
                    {
                        m_logger.EnforceDebug(result);
                        break;
                    }
                case TracerX.TraceLevel.Verbose:
                    {
                        m_logger.EnforceVerbose(result);
                        break;
                    }
            }
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        ///
        public bool IsLevelEnabled(TracerX.TraceLevel level)
        {
            return (m_logger.IsLevelEnabled(level));
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        ///
        public String ID
        {
            get { return m_id; }
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        ///
        public String Context
        {
            get { return m_context; }
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        ///
        public TracerX.TraceLevel Level
        {
            get { return m_logger.BinaryFileTraceLevel; }
        }

        private readonly Logger m_logger;
        private readonly String m_id;
        private readonly String m_decorated_id;
        private string m_context;

        private const String st_marker_bin = "\x2B\x2F";
    }
}
