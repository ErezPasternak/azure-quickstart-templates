﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace TracerX {

#if USE_ERICOM_CUSTOM_CODE
    /// <summary>
    /// The Logger.Level methods log a call to a method and return an instance of this class.
    /// Its Dispose method logs the exit of the call.
    /// Users should not create instances of this object or call its methods.
    /// </summary>
    [EditorBrowsable(EditorBrowsableState.Never)]
    [Browsable(false)]
    public class LevelEnder : MarshalByRefObject, IDisposable {
        /// <summary>
        /// Internal ctor keeps logging clients from creating instances.
        /// </summary>
        internal LevelEnder(Logger logger)
        {
            m_logger = logger;

            m_level_BinaryFile = m_logger.BinaryFileTraceLevel;
            m_level_TextFile = m_logger.TextFileTraceLevel;
            m_level_Console = m_logger.ConsoleTraceLevel;
            m_level_DebugOut = m_logger.DebugTraceLevel;
            m_level_EventLog = m_logger.EventLogTraceLevel;
            m_level_EventHandler = m_logger.EventHandlerTraceLevel;
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        ~LevelEnder()
        {
            Dispose();
        }

        /// <summary>
        /// If MaybeLogCall logged entry into a call, this logs the exit.
        /// </summary>
        public void Dispose()
        {
            lock (this)
            {
                if (m_logger == null)
                    return;

                m_logger.BinaryFileTraceLevel = m_level_BinaryFile;
                m_logger.TextFileTraceLevel = m_level_TextFile;
                m_logger.ConsoleTraceLevel = m_level_Console;
                m_logger.DebugTraceLevel = m_level_DebugOut;
                m_logger.EventLogTraceLevel = m_level_EventLog;
                m_logger.EventHandlerTraceLevel = m_level_EventHandler;

                m_logger = null;
            }
        }

        private Logger m_logger;
        private TraceLevel  m_level_BinaryFile,
                            m_level_TextFile,
                            m_level_Console,
                            m_level_DebugOut,
                            m_level_EventLog,
                            m_level_EventHandler;
    } // LevelEnder

#endif //USE_ERICOM_CUSTOM_CODE
}
