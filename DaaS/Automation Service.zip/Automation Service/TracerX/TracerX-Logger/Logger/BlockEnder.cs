﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace TracerX {

#if USE_ERICOM_CUSTOM_CODE
    /// <summary>
    /// The Logger.*Block methods log a call to a method and return an instance of this class.
    /// Its Dispose method logs the exit of the call.
    /// Users should not create instances of this object or call its methods.
    /// </summary>
    [EditorBrowsable(EditorBrowsableState.Never)]
    [Browsable(false)]
    public class BlockEnder : MarshalByRefObject, IDisposable
    {
        /// <summary>
        /// Internal ctor.......
        /// </summary>
        internal BlockEnder(Logger logger, string text, TraceLevel level, Destinations enforce, Destinations avoid)
        {
            _logger = logger;
            _text = text;
            _level = level;
            _enforce = enforce;
            _avoid = avoid;
        }

        /// <summary>
        /// dtor.......
        /// </summary>
        ~BlockEnder()
        {
            Dispose();
        }

        /// <summary>
        /// Closes the block
        /// </summary>
        public void Dispose()
        {
            lock (this)
            {
                if (_logger == null)
                    return;

                _logger.LogBlockText(_text, _level, _enforce, _avoid);
                _logger = null;
            }
        }

        private Logger _logger;
        private string _text;
        private TraceLevel _level;
        private Destinations _enforce, _avoid;
    } // BlockEnder
#endif //USE_ERICOM_CUSTOM_CODE
}
