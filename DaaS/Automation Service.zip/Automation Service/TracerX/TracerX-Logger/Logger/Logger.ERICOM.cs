﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Diagnostics;

namespace TracerX {
#if USE_ERICOM_CUSTOM_CODE
    public partial class Logger
    {
        #region Public

        private static System.Reflection.Assembly MainAssembly;

        /// <summary>
        /// Yochai.......
        /// </summary>
        ///
        public static void SetMainAssembly(System.Reflection.Assembly a)
        {
            System.Diagnostics.Debug.Assert(MainAssembly == null);
            MainAssembly = a;
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        ///
        public static System.Reflection.Assembly GetMainAssembly()
        {
            return (MainAssembly != null) ? MainAssembly : Assembly.GetEntryAssembly() /*Logger.GetMainAssembly()*/;
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        ///
        public static char TreeSeparator
        {
            get { return '.'; }
        }

        /// <summary>
        /// Converts a string to the enum
        /// </summary>
        public bool IsLevelInUse(TraceLevel level)
        {
            return GetDestinations(level) != Destinations.None;
        }

        /// <summary>
        /// Converts a string to the enum
        /// </summary>
        public static TraceLevel GetLevel(string level_name, TraceLevel default_level = TraceLevel.Info)
        {
            switch (level_name.ToLower())
            {
                case "off":
                    {
                        return TraceLevel.Off;
                    }
                case "fatal":
                    {
                        return TraceLevel.Fatal;
                    }
                case "error":
                    {
                        return TraceLevel.Error;
                    }
                case "warn":
                    {
                        return TraceLevel.Warn;
                    }
                case "debug":
                    {
                        return TraceLevel.Debug;
                    }
                case "verbose":
                    {
                        return TraceLevel.Verbose;
                    }
                case "info":
                    {
                        return TraceLevel.Info;
                    }
                default:
                    {
                        return default_level;
                    }
            }
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public static string GetLevelName(TraceLevel level)
        {
            switch (level)
            {
                case TraceLevel.Off:
                    {
                        return "Off";
                    }
                case TraceLevel.Fatal:
                    {
                        return "Fatal";
                    }
                case TraceLevel.Error:
                    {
                        return "Error";
                    }
                case TraceLevel.Warn:
                    {
                        return "Warn";
                    }
                case TraceLevel.Debug:
                    {
                        return "Debug";
                    }
                case TraceLevel.Verbose:
                    {
                        return "Verbose";
                    }
            }

            return "Info";
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public static string GetCorrectLevelName(string level_name, TraceLevel default_level = TraceLevel.Info)
        {
            return GetLevelName(GetLevel(level_name, default_level));
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public static TraceLevel GlobalBinaryFileTraceLevel
        {
            get { return _global_BinaryFileTraceLevel; }
            set { _global_BinaryFileTraceLevel = value; _calculate_global_max_level(); }
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public TraceLevel MaxBinaryFileTraceLevel
        {
            get
            {
                TraceLevel level = BinaryFileTraceLevel;
                return (level > _global_BinaryFileTraceLevel) ? level : _global_BinaryFileTraceLevel;
            }
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public static TraceLevel GlobalTextFileTraceLevel
        {
            get { return _global_TextFileTraceLevel; }
            set { _global_TextFileTraceLevel = value; _calculate_global_max_level(); }
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public TraceLevel MaxTextFileTraceLevel
        {
            get
            {
                TraceLevel level = TextFileTraceLevel;
                return (level > _global_TextFileTraceLevel) ? level : _global_TextFileTraceLevel;
            }
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public static TraceLevel GlobalConsoleTraceLevel
        {
            get { return _global_ConsoleTraceLevel; }
            set { _global_ConsoleTraceLevel = value; _calculate_global_max_level(); }
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public TraceLevel MaxConsoleTraceLevel
        {
            get
            {
                TraceLevel level = ConsoleTraceLevel;
                return (level > _global_ConsoleTraceLevel) ? level : _global_ConsoleTraceLevel;
            }
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public static TraceLevel GlobalDebugTraceLevel
        {
            get { return _global_DebugTraceLevel; }
            set { _global_DebugTraceLevel = value; _calculate_global_max_level(); }
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public TraceLevel MaxDebugTraceLevel
        {
            get
            {
                TraceLevel level = DebugTraceLevel;
                return (level > _global_DebugTraceLevel) ? level : _global_DebugTraceLevel;
            }
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public static TraceLevel GlobalEventLogTraceLevel
        {
            get { return _global_EventLogTraceLevel; }
            set { _global_EventLogTraceLevel = value; _calculate_global_max_level(); }
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public TraceLevel MaxEventLogTraceLevel
        {
            get
            {
                TraceLevel level = EventLogTraceLevel;
                return (level > _global_EventLogTraceLevel) ? level : _global_EventLogTraceLevel;
            }
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public static TraceLevel GlobalEventHandlerTraceLevel
        {
            get { return _global_EventHandlerTraceLevel; }
            set { _global_EventHandlerTraceLevel = value; _calculate_global_max_level(); }
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public TraceLevel MaxEventHandlerTraceLevel
        {
            get
            {
                TraceLevel level = EventHandlerTraceLevel;
                return (level > _global_EventHandlerTraceLevel) ? level : _global_EventHandlerTraceLevel;
            }
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public struct DestLevel
        {
            /// <summary>
            /// Yochai.......
            /// </summary>
            public readonly Destinations m_dest;
            /// <summary>
            /// Yochai.......
            /// </summary>
            public readonly TraceLevel m_level;

            /// <summary>
            /// Yochai.......
            /// </summary>
            public DestLevel(Destinations dest, TraceLevel level)
            {
                m_dest = dest;
                m_level = level;
            }
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public LevelEnder TempLevel(params DestLevel[] dl_list)
        {
            LevelEnder ender = new LevelEnder(this);

            foreach (DestLevel dl in dl_list)
            {
                switch (dl.m_dest)
                {
                    case Destinations.BinaryFile: BinaryFileTraceLevel = dl.m_level; break;
                    case Destinations.TextFile: TextFileTraceLevel = dl.m_level; break;
                    case Destinations.Console: ConsoleTraceLevel = dl.m_level; break;
                    case Destinations.Debug: DebugTraceLevel = dl.m_level; break;
                    case Destinations.EventLog: EventLogTraceLevel = dl.m_level; break;
                    case Destinations.EventHandler: EventHandlerTraceLevel = dl.m_level; break;
                }
            }
            return ender;
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public LevelEnder TempLevel(TraceLevel level)
        {
            LevelEnder ender = new LevelEnder(this);

            BinaryFileTraceLevel = level;
            TextFileTraceLevel = level;
            ConsoleTraceLevel = level;
            DebugTraceLevel = level;
            EventLogTraceLevel = level;
            EventHandlerTraceLevel = level;

            return ender;
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void FatalEx(string msg, Exception e, bool append_stack_trace)
        {
            LogException(TraceLevel.Fatal, msg, e, append_stack_trace);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public BlockEnder FatalBlock(string entering, string terminating, Destinations enforce = Destinations.None, Destinations avoid = Destinations.None)
        {
            return MaybeLogBlock(TraceLevel.Fatal, entering, terminating, enforce, avoid);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceFatal(string msg)
        {
            EnforceLog(TraceLevel.Fatal, msg);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceFatal(object arg0)
        {
            EnforceLog(TraceLevel.Fatal, arg0);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceFatal(object arg0, object arg1)
        {
            EnforceLog(TraceLevel.Fatal, arg0, arg1);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceFatal(params object[] items)
        {
            EnforceLog(TraceLevel.Fatal, items);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceFatalFormat(string fmt, object obj0)
        {
            EnforceLogFormat(TraceLevel.Fatal, fmt, obj0);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceFatalFormat(string fmt, object obj0, object obj1)
        {
            EnforceLogFormat(TraceLevel.Fatal, fmt, obj0, obj1);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceFatalFormat(string fmt, params object[] parms)
        {
            EnforceLogFormat(TraceLevel.Fatal, fmt, parms);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void ErrorEx(string msg, Exception e, bool append_stack_trace = true)
        {
            LogException(TraceLevel.Error, msg, e, append_stack_trace);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public BlockEnder ErrorBlock(string entering, string terminating, Destinations enforce = Destinations.None, Destinations avoid = Destinations.None)
        {
            return MaybeLogBlock(TraceLevel.Error, entering, terminating, enforce, avoid);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceError(string msg)
        {
            EnforceLog(TraceLevel.Error, msg);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceError(object arg0)
        {
            EnforceLog(TraceLevel.Error, arg0);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceError(object arg0, object arg1)
        {
            EnforceLog(TraceLevel.Error, arg0, arg1);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceError(params object[] items)
        {
            EnforceLog(TraceLevel.Error, items);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceErrorFormat(string fmt, object obj0)
        {
            EnforceLogFormat(TraceLevel.Error, fmt, obj0);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceErrorFormat(string fmt, object obj0, object obj1)
        {
            EnforceLogFormat(TraceLevel.Error, fmt, obj0, obj1);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceErrorFormat(string fmt, params object[] parms)
        {
            EnforceLogFormat(TraceLevel.Error, fmt, parms);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void WarnEx(string msg, Exception e, bool append_stack_trace = true)
        {
            LogException(TraceLevel.Warn, msg, e, append_stack_trace);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public BlockEnder WarnBlock(string entering, string terminating, Destinations enforce = Destinations.None, Destinations avoid = Destinations.None)
        {
            return MaybeLogBlock(TraceLevel.Warn, entering, terminating, enforce, avoid);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceWarn(string msg)
        {
            EnforceLog(TraceLevel.Warn, msg);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceWarn(object arg0)
        {
            EnforceLog(TraceLevel.Warn, arg0);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceWarn(object arg0, object arg1)
        {
            EnforceLog(TraceLevel.Warn, arg0, arg1);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceWarn(params object[] items)
        {
            EnforceLog(TraceLevel.Warn, items);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceWarnFormat(string fmt, object obj0)
        {
            EnforceLogFormat(TraceLevel.Warn, fmt, obj0);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceWarnFormat(string fmt, object obj0, object obj1)
        {
            EnforceLogFormat(TraceLevel.Warn, fmt, obj0, obj1);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceWarnFormat(string fmt, params object[] parms)
        {
            EnforceLogFormat(TraceLevel.Warn, fmt, parms);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void InfoEx(string msg, Exception e, bool append_stack_trace = true)
        {
            LogException(TraceLevel.Info, msg, e, append_stack_trace);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public BlockEnder InfoBlock(string entering, string terminating, Destinations enforce = Destinations.None, Destinations avoid = Destinations.None)
        {
            return MaybeLogBlock(TraceLevel.Info, entering, terminating, enforce, avoid);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceInfo(string msg)
        {
            EnforceLog(TraceLevel.Info, msg);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceInfo(object arg0)
        {
            EnforceLog(TraceLevel.Info, arg0);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceInfo(object arg0, object arg1)
        {
            EnforceLog(TraceLevel.Info, arg0, arg1);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceInfo(params object[] items)
        {
            EnforceLog(TraceLevel.Info, items);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceInfoFormat(string fmt, object obj0)
        {
            EnforceLogFormat(TraceLevel.Info, fmt, obj0);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceInfoFormat(string fmt, object obj0, object obj1)
        {
            EnforceLogFormat(TraceLevel.Info, fmt, obj0, obj1);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceInfoFormat(string fmt, params object[] parms)
        {
            EnforceLogFormat(TraceLevel.Info, fmt, parms);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void DebugEx(string msg, Exception e, bool append_stack_trace = true)
        {
            LogException(TraceLevel.Debug, msg, e, append_stack_trace);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public BlockEnder DebugBlock(string entering, string terminating, Destinations enforce = Destinations.None, Destinations avoid = Destinations.None)
        {
            return MaybeLogBlock(TraceLevel.Debug, entering, terminating, enforce, avoid);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceDebug(string msg)
        {
            EnforceLog(TraceLevel.Debug, msg);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceDebug(object arg0)
        {
            EnforceLog(TraceLevel.Debug, arg0);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceDebug(object arg0, object arg1)
        {
            EnforceLog(TraceLevel.Debug, arg0, arg1);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceDebug(params object[] items)
        {
            EnforceLog(TraceLevel.Debug, items);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceDebugFormat(string fmt, object obj0)
        {
            EnforceLogFormat(TraceLevel.Debug, fmt, obj0);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceDebugFormat(string fmt, object obj0, object obj1)
        {
            EnforceLogFormat(TraceLevel.Debug, fmt, obj0, obj1);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceDebugFormat(string fmt, params object[] parms)
        {
            EnforceLogFormat(TraceLevel.Debug, fmt, parms);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void VerboseEx(string msg, Exception e, bool append_stack_trace = true)
        {
            LogException(TraceLevel.Verbose, msg, e, append_stack_trace);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public BlockEnder VerboseBlock(string entering, string terminating, Destinations enforce = Destinations.None, Destinations avoid = Destinations.None)
        {
            return MaybeLogBlock(TraceLevel.Verbose, entering, terminating, enforce, avoid);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceVerbose(string msg)
        {
            EnforceLog(TraceLevel.Verbose, msg);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceVerbose(object arg0)
        {
            EnforceLog(TraceLevel.Verbose, arg0);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceVerbose(object arg0, object arg1)
        {
            EnforceLog(TraceLevel.Verbose, arg0, arg1);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceVerbose(params object[] items)
        {
            EnforceLog(TraceLevel.Verbose, items);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceVerboseFormat(string fmt, object obj0)
        {
            EnforceLogFormat(TraceLevel.Verbose, fmt, obj0);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceVerboseFormat(string fmt, object obj0, object obj1)
        {
            EnforceLogFormat(TraceLevel.Verbose, fmt, obj0, obj1);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void EnforceVerboseFormat(string fmt, params object[] parms)
        {
            EnforceLogFormat(TraceLevel.Verbose, fmt, parms);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public static FileBase FileBase
        {
            get
            {
                return (Logger.BinaryFileLogging != null) ? (FileBase)Logger.BinaryFileLogging : (FileBase)Logger.TextFileLogging;
            }
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public static string RenameFile(string file_name_prefix, string file_extension)
        {
            FileBase file_base = FileBase;

            return RenameFile(file_base, file_name_prefix, file_extension);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public static string RenameFile(FileBase file_base, string file_name_prefix, string file_extension)
        {
            string file_directory = file_base.Directory;
            bool   use_00 = file_base.Use_00;
            uint n_archives = file_base.Archives;

            string full_pathname = FileBase.ComposeFullPathName(file_directory, file_name_prefix, file_extension, use_00 );

            if( n_archives == 0 )
                return full_pathname;

            string renamedFile = full_pathname + ".tempname";

            if (File.Exists(renamedFile))
                File.Delete(renamedFile);

            // DO NOT use outFile.Exists or outFile.Move() in here.
            for (int attempts = 3; attempts > 0 && File.Exists(full_pathname); --attempts)
            {
                try
                {
                    // If the file is in use (including by the viewer), this throws an exception.
                    File.Move(full_pathname, renamedFile);
                }
                catch (Exception)
                {
                    if (attempts <= 1)
                    {
                        // That was the last try.
                        throw;
                    }
                    else
                    {
                        // Give whoever has the file open (possibly the viewer) a
                        // chance to close it.
                        Thread.Sleep(100);
                    }
                }
            }

            ManageArchives( renamedFile, file_directory, file_name_prefix, n_archives, file_extension );

            return full_pathname;
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public static void ManageArchives(string renamedFile, string file_directory, string file_name_prefix, uint n_archives, string file_extension)
        {
            if (n_archives == 0)
                return;

            if (file_extension[0] == '.')
                file_extension = file_extension.Substring(1);

            string bareFilePath = Path.Combine(file_directory, file_name_prefix);
            int highestNumKept = (renamedFile == null) ? (int)n_archives : (int)n_archives - 1;

            // This gets the archived files in reverse order.
            // Logfiles from older versions may only have one numeric character in the filename suffix.
            string[] files = EnumOldFiles("_?*." + file_extension, file_directory, file_name_prefix);

            if (files != null)
            {
                foreach (string oldFile in files)
                {
                    // Extract the archive number that comes after "<file_name_prefix>_".
                    // The number must be one or two chars or it's not one of our files.
                    string plain = Path.GetFileNameWithoutExtension(oldFile);
                    string numPart = plain.Substring(file_name_prefix.Length + 1);

                    if (numPart.Length == 1 || numPart.Length == 2)
                    {
                        int num;

                        if (int.TryParse(numPart, out num) && num > 0)
                        {
                            if (num > highestNumKept)
                            {
                                // The archive number is more than the user wants to keep, so delete it.
                                try
                                {
                                    File.Delete(oldFile);
                                }
                                catch (Exception ex)
                                {
                                    string msg = string.Format("An exception occurred while deleting the old log file\n{0}\n\n{1}", oldFile, ex);
                                    Logger.EventLogging.Log(msg, Logger.EventLogging.ExceptionInArchive);
                                }
                            }
                            else if (renamedFile != null)
                            {
                                // Rename (increment the file's archive number by 1).
                                TryRename(oldFile, bareFilePath, num + 1, file_extension);
                            }
                        }
                    }
                }

                // Finally, rename the most recent log file, if it exists.
                if (renamedFile != null)
                {
                    TryRename(renamedFile, bareFilePath, 1, file_extension);
                }

            }
        }

        public static void SetExternalLogDestination(ExternalLogDestination external_log_destination)
        {
            System.Diagnostics.Debug.Assert(external_log_destination != null);

            sm_external_log_destination = external_log_destination;
        }

        public static void UnsetExternalLogDestination()
        {
            sm_external_log_destination = null;
        }
        #endregion

        #region Private/Protected/Internal

        internal static string[] EnumOldFiles(string suffixPattern, string file_directory, string file_name_prefix)
        {
            string[] files = null;

            try
            {
                // Get the archived log files in reverse order.
                // There must be two characters after the '_'.
                string wild = file_name_prefix + suffixPattern;
                files = System.IO.Directory.GetFiles(file_directory, wild, SearchOption.TopDirectoryOnly);
                Array.Sort(files, StringComparer.OrdinalIgnoreCase);
                Array.Reverse(files);
            }
            catch (Exception ex)
            {
                string msg = string.Format("An exception occurred enumerating old log files in\n{0}\n\n{1}", file_directory, ex);
                Logger.EventLogging.Log(msg, Logger.EventLogging.ExceptionInArchive);
            }

            return files;
        }

        internal static void TryRename(string from, string template, int num, string file_extension)
        {
            if (file_extension[0] == '.')
                file_extension = file_extension.Substring(1);

            string newFile = string.Format("{0}_{1:D2}.{2}", template, num, file_extension);

            try
            {
                File.Move(from, newFile);
            }
            catch (Exception ex)
            {
                string msg = string.Format("An exception occurred while renaming the old log file\n{0}\nto\n{1}\n\n{2}", from, newFile, ex);
                Logger.EventLogging.Log(msg, Logger.EventLogging.ExceptionInArchive);
            }
        }

        private void LogException(TraceLevel msgLevel, string msg, Exception e, bool append_stack_trace)
        {
            if (msg.Length > 0 && msg[msg.Length - 1] != '\n')
                msg = msg + "\n";

            if (append_stack_trace)
                MaybeLog(msgLevel, msg, e);
            else
                MaybeLog(msgLevel, msg, e.Message);
        }

        private BlockEnder MaybeLogBlock(TraceLevel level, string entering, string terminating, Destinations enforce, Destinations avoid)
        {
            BlockEnder result = null;

            lock (this)
            {
                Destinations destinations = GetDestinations(level);

                destinations |= enforce;
                destinations &= ~avoid;

                if (destinations != Destinations.None)
                {
                    LogBlockText(entering, level, enforce, avoid);
                    result = new BlockEnder(this, terminating, level, enforce, avoid);
                }
            }

            return result;
        }

        internal void LogBlockText(string text, TraceLevel level, Destinations enforce, Destinations avoid)
        {
            lock (this)
            {
                ThreadData threadData = ThreadData.CurrentThreadData;

                RendererMap.FindAndRender(text, threadData.StringWriter);
                string msg = threadData.ResetStringWriter();
                LogToDestinations(threadData, level, msg, enforce, avoid);
                FlushBinaryFile();
            }
        }

        private void EnforceLog(TraceLevel msgLevel, string msg)
        {
            lock (this)
            {
                using (TempLevel(msgLevel))
                {
                    MaybeLog(msgLevel, msg);
                }
            }
        }

        private void EnforceLog(TraceLevel msgLevel, object arg0)
        {
            lock (this)
            {
                using (TempLevel(msgLevel))
                {
                    MaybeLog(msgLevel, arg0);
                }
            }
        }

        private void EnforceLog(TraceLevel msgLevel, object arg0, object arg1)
        {
            lock (this)
            {
                using (TempLevel(msgLevel))
                {
                    MaybeLog(msgLevel, arg0, arg1);
                }
            }
        }

        private void EnforceLog(TraceLevel msgLevel, params object[] items)
        {
            lock (this)
            {
                using (TempLevel(msgLevel))
                {
                    MaybeLog(msgLevel, items);
                }
            }
        }

        private void EnforceLogFormat(TraceLevel msgLevel, string fmt, object obj0)
        {
            lock (this)
            {
                using (TempLevel(msgLevel))
                {
                    MaybeLogFormat(msgLevel, fmt, obj0);
                }
            }
        }

        private void EnforceLogFormat(TraceLevel msgLevel, string fmt, object obj0, object obj1)
        {
            lock (this)
            {
                using (TempLevel(msgLevel))
                {
                    MaybeLogFormat(msgLevel, fmt, obj0, obj1);
                }
            }
        }

        private void EnforceLogFormat(TraceLevel msgLevel, string fmt, params object[] parms)
        {
            lock (this)
            {
                using (TempLevel(msgLevel))
                {
                    MaybeLogFormat(msgLevel, fmt, parms);
                }
            }
        }

        static private void _calculate_global_max_level()
        {
            TraceLevel level = TraceLevel.Inherited;

            lock (_global_max_level_lock_object)
            {
                if (level < _global_BinaryFileTraceLevel) level = _global_BinaryFileTraceLevel;
                if (level < _global_TextFileTraceLevel) level = _global_TextFileTraceLevel;
                if (level < _global_ConsoleTraceLevel) level = _global_ConsoleTraceLevel;
                if (level < _global_DebugTraceLevel) level = _global_DebugTraceLevel;
                if (level < _global_EventLogTraceLevel) level = _global_EventLogTraceLevel;
                if (level < _global_EventHandlerTraceLevel) level = _global_EventHandlerTraceLevel;

                _global_max_level = level;
            }
        }

        #endregion

        #region Modified API

        /// <summary>
        /// Yochai.......
        /// </summary>
        public bool IsLevelEnabled(TraceLevel msgLevel)
        {
            return _global_max_level >= msgLevel || this._maxLevel >= msgLevel;
        }

        private void AddLoggerPrivate(Logger logger)
        {
            AddLoggerPrivate(logger, logger.Name);
        }

        private const char _tree_separator = '.';

        private void AddLoggerPrivate(Logger logger, String reminder_name)
        {
            // See if the new logger should be a child of any of our children.
            // If not, it will become our child.

#if DEBUG
            bool children_can_be_moved = true;
#else
            bool children_can_be_moved = !_right_tree_order;
#endif
            string newNameWithDot = (children_can_be_moved) ? logger.Name + _tree_separator : "";
            bool movedChildren = false;

            if (_children == null)
            {
                _children = new List<Logger>();
            }
            else
            {
                if (!(children_can_be_moved == false && reminder_name.IndexOf(_tree_separator) < 0))
                {
                    foreach (Logger child in _children)
                    {
                        System.Diagnostics.Debug.Assert(child.Name != logger.Name);

                        bool child_should_be_moved = children_can_be_moved && child.Name.StartsWith(newNameWithDot);

                        System.Diagnostics.Debug.Assert(child_should_be_moved == false || _right_tree_order == false);

                        if (child_should_be_moved && _right_tree_order == false)
                        {
                            // The new logger should be a parent of the current child
                            // and should replace the current child in the list.
                            // Note that there may be several such children.  E.g.,
                            // we have children A.B.1 and A.B.2, and the new logger is A.B or A.
                            // Therefore, keep looping.
                            reminder_name = child.Name.Substring(newNameWithDot.Length);
                            logger.AddLoggerPrivate(child, reminder_name);
                            movedChildren = true;

                        }
                        else
                            if (!movedChildren)
                            {
                                string childNameWithDot = child.Name + _tree_separator;
                                if (logger.Name.StartsWith(childNameWithDot))
                                {
                                    // The new logger should be a child of the current child.

                                    reminder_name = logger.Name.Substring(childNameWithDot.Length);
                                    child.AddLoggerPrivate(logger, reminder_name);
                                    return;
                                }
                            }
                    }

                    // Getting here means the new logger will become our child.

                    if (movedChildren)
                    {
                        // Some of our children are now the new logger's children.
                        // Replace them with the new logger.
                        foreach (Logger child in logger._children)
                        {
                            _children.Remove(child);
                        }
                    }
                }
            }

            System.Diagnostics.Debug.Assert(!_right_tree_order || reminder_name.IndexOf(_tree_separator) < 0);

            _children.Add(logger);
            logger.parent = this;
        }

        /// <summary>
        /// Ctor is private.  GetLogger() should be the only caller.
        /// </summary>
        private Logger(string name, bool right_tree_order)
        {
            _name = name;
            _right_tree_order = right_tree_order;
            DestinationLevels = new LevelPair[] { BinaryFileLevels, TextFileLevels, ConsoleLevels, DebugOutLevels, EventLogLevels, EventHandlerLevels };
            _loggers.Add(name, this);
        }

        static Logger()
        {
            Root = new Logger("Root", false);
            Root.BinaryFileTraceLevel = TraceLevel.Info;
            Root.TextFileTraceLevel = TraceLevel.Off;
            Root.ConsoleTraceLevel = TraceLevel.Off;
            Root.DebugTraceLevel = TraceLevel.Off;
            Root.EventLogTraceLevel = TraceLevel.Off;
            Root.EventHandlerTraceLevel = TraceLevel.Off;

            // The StandardData logger is special in that it is initialized with a FileTraceLevel
            // of Verbose.  The user can change it programatically or via XML.

            StandardData = GetLogger("TracerX");

            StandardData.BinaryFileTraceLevel = TraceLevel.Verbose;

            AppDomain.CurrentDomain.UnhandledException += _appDomainExceptionHandler;
        }

        internal static void RemoveLogger(Logger logger)
        {
            lock (_loggers)
            {
                _loggers.Remove(logger.Name);

                logger.parent._children.Remove(logger);

                if (logger._children != null)
                {
                    foreach (Logger child in logger._children)
                    {
                        logger.parent._children.Add(child);
                        child.parent = logger.parent;
                    }
                }

                logger.parent = null;
            }
        }

        #endregion

        private bool _right_tree_order;
        static private Object     _global_max_level_lock_object  = new Object();
        static private TraceLevel _global_max_level              = TracerX.TraceLevel.Inherited;

        static private TraceLevel _global_BinaryFileTraceLevel   = TracerX.TraceLevel.Inherited;
        static private TraceLevel _global_TextFileTraceLevel     = TracerX.TraceLevel.Inherited;
        static private TraceLevel _global_ConsoleTraceLevel      = TracerX.TraceLevel.Inherited;
        static private TraceLevel _global_DebugTraceLevel        = TracerX.TraceLevel.Inherited;
        static private TraceLevel _global_EventLogTraceLevel     = TracerX.TraceLevel.Inherited;
        static private TraceLevel _global_EventHandlerTraceLevel = TracerX.TraceLevel.Inherited;

        static internal ExternalLogDestination sm_external_log_destination = null;
    }

    /// <summary>
    /// Yochai.......
    /// </summary>
    ///
    public delegate void ExternalLogDestination(Logger logger, TraceLevel lineLevel, String id, String context, String msg);

    /// <summary>
    /// Yochai.......
    /// </summary>
    ///
    public static class Configuration
    {
        /// <summary>
        /// Yochai.......
        /// </summary>
        ///
        public static bool UseMachineDomain = true;
        /// <summary>
        /// Yochai.......
        /// </summary>
        ///
        public static bool UseCurrentDomain = true;
    }
#endif //USE_ERICOM_CUSTOM_CODE

}
