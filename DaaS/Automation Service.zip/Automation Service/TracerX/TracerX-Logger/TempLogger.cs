﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace TracerX
{
#if USE_ERICOM_CUSTOM_CODE
    /// <summary>
    /// Yochai.......
    /// </summary>
    [EditorBrowsable(EditorBrowsableState.Never)]
    [Browsable(false)]
    public class TempLogger : MarshalByRefObject, IDisposable
    {
        /// <summary>
        /// Yochai.......
        /// </summary>
        public TempLogger(string name, bool right_tree_order = true)
        {
            _logger = Logger.GetLogger(name, false, right_tree_order);
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        ~TempLogger()
        {
            Dispose();
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public Logger Logger
        {
            get
            {
                return _logger;
            }
        }

        /// <summary>
        /// Yochai.......
        /// </summary>
        public void Dispose()
        {
            lock (this)
            {
                if (_logger == null)
                    return;

                Logger.RemoveLogger(_logger);

                _logger = null;
            }
        }

        private Logger _logger;
    }
#endif //USE_ERICOM_CUSTOM_CODE
}
