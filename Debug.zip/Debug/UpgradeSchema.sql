﻿-- Script to upgrade the database

-- If needed .. can get current and desired versions from the CloudConnectSystemProperties table 
--   DbCreationBuild
--   DesiredUpgradeVersion
--   UpgradedToVersion  (this is updated externally after a successful upgrade)


delete from CloudConnectSystemProperties where PropertyName = 'SchemaMajorVersion'
delete from CloudConnectSystemProperties where PropertyName = 'SchemaMinorVersion'


