﻿
-- For keys that come from StirngUtils.UniqueId

CREATE TYPE StandardIdType FROM nvarchar(36);  -- for types that use StringUtilities.UniqueId - should be 36 - but a test got an error - don't know which
create type EndUserIdType From nvarchar(100);
create type ModuleNameType From nvarchar(100);
create type DescriptorNameType From nvarchar(200);
create type MessagePriorityType from int;
go

create table [dbo].[CloudConnectSystemProperties] (
   PropertyName nvarchar(100) primary key,
   PropertyValue nvarchar(100) not null
)

-- Several SystemProperties are maintained by the configuration / upgrade process
-- DbCreationBuild  = product version (e.g. 7.1.0.1234) when the database was created
-- UpgradedToVersion = product version that we have been upgraded to
-- DesiredUpgradeVersion = product version that we would like to upgrade to (used by the Upgrade scripts)


-- initialized by CreateDatabase

create table [dbo].[MessagePriorities] (
   Value int not null,
   Name nvarchar(10) primary key)

-- initialized by CreateDatabase
create table [dbo].DescriptorNames (
   Name DescriptorNameType primary key)

go
-- initialized by CreateDatabase
create table [dbo].ModuleNames (
   Name nvarchar(100) primary key)
go   

CREATE TABLE [dbo].[CloudConnectSystemConfiguration] (
        [ConfigName] [nvarchar](255) NOT NULL PRIMARY KEY,
        [Version] [int] NOT NULL,
        [SystemProperties] [varbinary](max) NOT NULL,
        EsgCommonProperties [varbinary](max) NOT NULL,
        EuwsCommonProperties [varbinary](max) NOT NULL,
        CloudConnectBLCommonProperties [varbinary](max) NOT NULL,
        RemoteAgentCommonProperties [varbinary](max) NOT NULL,
        AdminWsCommonProperties [varbinary](max) NOT NULL,
        RemoteHostCommonProperties [varbinary](max) NOT NULL,
        SystemDefaultConnectionProperties [varbinary](max) NOT NULL,
        SystemDefaultBindingProperties [varbinary](max) NOT NULL
        )


CREATE TABLE [dbo].ConnectSpecialConfiguration (
        SpecialConfigId [nvarchar](255) NOT NULL PRIMARY KEY,
        [Version] [int] NOT NULL,
        SpecialProperties [varbinary](max) NOT NULL
        )


create table dbo.EndUserConfig (
  EndUserId EndUserIdType not null primary key,
  TenantId StandardIdType not null,
  [Version] [int] NOT NULL,
  DownLevelLogonName nvarchar(100) not null ,
  UserPrincipalName nvarchar(100) not null ,
  PersonName nvarchar(100) not null,
  InitialLoginTime DateTime2 not null 
)

create index EndUserConfig_DownLevelLogonName on EndUserConfig(DownLevelLogonName)
create index EndUserConfig_PersonName on EndUserConfig(PersonName)

CREATE TABLE [dbo].[RemoteHostConfig](
        [RemoteHostId] StandardIdType NOT NULL PRIMARY KEY,
        [Version] [int] NOT NULL,
        HostName nvarchar(100) not null,
        [ConfigProperties] [varbinary](max) NOT NULL,
        DomainQualifiedHostName [nvarchar](512) NOT NULL,
        IpAddress [nvarchar](45) NOT NULL,
        TenantId StandardIdType NOT NULL,
        [HostClassificationTags] [varbinary](max) NOT NULL,
        InUse [bit] not null,
        LastRecordedState int not null
)

create index RemoteHostConfig_TenantId on RemoteHostConfig(TenantId)

CREATE TABLE [dbo].[RemoteHostGroup](
        RemoteHostGroupId StandardIdType NOT NULL primary key,
        TenantId StandardIdType not null,
        [Version] [int] NOT NULL,
        RemoteHostIds [varbinary](max) not NULL,
        ConfigProperties varbinary(max) not null,
        MetaData varbinary(max) not null,
        InUse [bit] not null
        )

CREATE TABLE [dbo].[ResourceDefinition](
        [ResourceDefinitionId] StandardIdType NOT NULL primary key,
        [Version] [int] NOT NULL,
        [DisplayProperties] [varbinary](max) NOT NULL,
        [ConnectionProperties] [varbinary](max) NOT NULL,
        [TenantId] StandardIdType NOT NULL,
        [BindingProperties] [varbinary](max) NOT NULL,
        MetaData varbinary(max) not null,
        InUse [bit] not null
        )

CREATE TABLE [dbo].[ResourceGroup](
        [ResourceGroupId] StandardIdType NOT NULL primary key,
        [Version] [int] NOT NULL,
        [DisplayProperties] [varbinary](max) NOT NULL,
        [ConnectionProperties] [varbinary](max) NOT NULL,
        [BindingProperties] [varbinary](max) NOT NULL,
        [TenantId] StandardIdType NOT NULL,
        [ResourceComputationMode] int NOT NULL,
        [ResourceDefinitionIds] [varbinary](max) NULL,
        RemoteHostGroupIds [varbinary](max) not NULL,
        [BindingGroups] [varbinary](max) NOT NULL,
        MetaData varbinary(max) not null,
        InUse [bit] not null
        )

CREATE TABLE [dbo].[Tenant] (
        [TenantId] StandardIdType NOT NULL primary key,
        [Name] nvarchar(100) not null,
        [Version] [int] NOT NULL,
        [ParentTenantId] StandardIdType NULL,
        [Properties] [varbinary](max) NOT NULL,
        [ConnectionProperties] [varbinary](max) NOT NULL,
        [BindingProperties] [varbinary](max) NOT NULL,
        [RadiusProperties] [varbinary](max) NOT NULL,
        RemoteHostProperties [varbinary](max) NOT NULL,
        [InUse] [bit] not null
        )

CREATE TABLE [dbo].[EndUserWebServiceConfig](
        StandaloneServerId StandardIdType NOT NULL primary key,
        [Version] [int] NOT NULL,
        [ConfigProperties] [varbinary](max) NOT NULL,
        InUse [bit] not null,
        HostName nvarchar(100) not null,
        DomainQualifiedHostName nvarchar(512) not null,
        IpAddress nvarchar(45) not null,
        LastRecordedState int not null,
        BuildVersion nvarchar(100) not null 
        )

CREATE TABLE [dbo].[CloudConnectBLServiceConfig](
        StandaloneServerId StandardIdType NOT NULL primary key,
        [Version] [int] NOT NULL,
        [ConfigProperties] [varbinary](max) NOT NULL,
        InUse [bit] not null,
        HostName nvarchar(100) not null,
        DomainQualifiedHostName nvarchar(512) not null,
        IpAddress nvarchar(45) not null,
        LastRecordedState int not null,
        BuildVersion nvarchar(100) not null
        )

CREATE TABLE [dbo].AdminWebServiceConfig(
        StandaloneServerId StandardIdType NOT NULL primary key,
        [Version] [int] NOT NULL,
        [ConfigProperties] [varbinary](max) NOT NULL,
        InUse [bit] not null,
        HostName nvarchar(100) not null,
        DomainQualifiedHostName nvarchar(512) not null,
        IpAddress nvarchar(45) not null,
        LastRecordedState int not null,
        BuildVersion nvarchar(100) not null
        )
        
CREATE TABLE [dbo].[EsgConfig](
        StandaloneServerId StandardIdType NOT NULL PRIMARY KEY,
        [Version] [int] NOT NULL,
        [ConfigProperties] [varbinary](max) NOT NULL,
        InUse [bit] not null,
        HostName nvarchar(100) not null,
        DomainQualifiedHostName nvarchar(512) not null,
        IpAddress nvarchar(45) not null,
        LastRecordedState int not null,
        BuildVersion nvarchar(100) not null
)

CREATE TABLE [dbo].[RemoteAgentConfig](
        [StandaloneServerId] StandardIdType NOT NULL PRIMARY KEY,
        [Version] [int] NOT NULL,
        [ConfigProperties] [varbinary](max) NOT NULL,
        InUse [bit] not null,
        HostName nvarchar(100) not null,
        DomainQualifiedHostName nvarchar(512) not null,
        IpAddress nvarchar(45) not null,
        LastRecordedState int not null,
        BuildVersion nvarchar(100) not null
)

-------------------------------------------------------------
-- LOGGING tables

-- EndUserSessionLog
CREATE TABLE dbo.EndUserSessionLog (
        EndUserSessionId StandardIdType     not null primary key nonclustered,
        SourceMachineIp [nvarchar](255) NOT NULL,
        EndUserSessionStartTime [datetime2](7) NOT NULL,
        EndUserId EndUserIdType             not null,
        StandaloneServerId StandardIdType null,
        PortalType nvarchar(100) not null,
        PortalVersion nvarchar(100),
        [DbCreationTime] [datetime2](7) NOT NULL default SYSUTCDATETIME(),
)

create clustered index EndUserSessionLog_DbTime on EndUserSessionLog(DbCreationTime)
create index EndUserSessionLog_EndUserSessionStartTime on EndUserSessionLog(EndUserSessionStartTime)
create index EndUserSessionLog_EndUserId on EndUserSessionLog(EndUserId)

-- store session end information for EndUserSessions and RemoteSessions
create table dbo.SessionEndLog (
  [EventId] StandardIdType not null primary key nonclustered,  -- either an EndUserSessionId or a RemoteSessionId
  [DbCreationTime] [datetime2] NOT NULL default SYSUTCDATETIME(),
  SessionEndTime datetime2 not null,
  SessionEndReason nvarchar(100) not null
)

create clustered index SessionEndLog_DbTime on SessionEndLog(DbCreationTime)
create index SessionEndTime_SessionEndTime on SessionEndLog(SessionEndTime)
-- TODO:  perhaps an index on the end reason

CREATE TABLE dbo.RemoteSessionLog (
        -- common for all log messages
        RemoteSessionId StandardIdType NOT NULL primary key nonclustered,
        RemoteSessionStartTime [datetime2](7) NOT NULL,
        [DbCreationTime] [datetime2](7) NOT NULL default SYSUTCDATETIME(),
      
        EndUserId EndUserIdType             not null,
        EndUserSessionId StandardIdType     not null, 
        ResourceDefinitionId StandardIdType     not null, 
        InitialApplicationName nvarchar(255) not null,
        RemoteHostId StandardIdType not null,
        RemoteHostName nvarchar(100) not null
)

CREATE TABLE dbo.EsgSessionLog (
        [DbCreationTime] [datetime2](7) NOT NULL default SYSUTCDATETIME(),
        [EventId] StandardIdType NOT NULL primary key nonclustered,
        StartTime [datetime2](7) NOT NULL,
        EndTime [datetime2](7) NOT NULL,
        ElapsedTimeMs bigint not null,
        EsgSessionId nvarchar(100) not null,
        EsgSessionType nvarchar(100) not null,
        UnderlyingProtocols nvarchar(100) not null,
        Purpose nvarchar(100) not null,
        TerminatedBy nvarchar(100) not null,
        TerminationReason nvarchar(1024) not null,
        ClientAddress nvarchar(100) not null,  
        HostAddress nvarchar(100) not null,     
        FinalAddress nvarchar(100),
        RemoteUserName nvarchar(100) not null,
        ClientDescription nvarchar(1024) not null,
        StandaloneServerId StandardIdType not null,  
        EndUserId EndUserIdType not null,  
        EndUserSessionId StandardIdType not null,        
)

CREATE TABLE dbo.EsgHttpLog (
        [DbCreationTime] [datetime2](7) NOT NULL default SYSUTCDATETIME(),
        [EventId] StandardIdType NOT NULL primary key nonclustered,
        StartTime [datetime2](7) NOT NULL,
        EndTime [datetime2](7) NOT NULL,
        ElapsedTimeMs nvarchar(100) not null,
        ClientAddress nvarchar(100) not null,
        EsgAddress nvarchar(100) not null,
        RequestMethod nvarchar(100) not null,
        RequestPath nvarchar(256) not null,
        RequestQuery nvarchar(256),
        RequestUrlCategory nvarchar(100) not null,
        RequestUserAgent nvarchar(256),
        RequestContentLength nvarchar(100),
        RequestPipelined nvarchar(100) not null,       
        ResponseStatusCode nvarchar(100),
        ResponseStatusCodeStr nvarchar(100),
        ResponseStatusDescription nvarchar(256),
        ResponseContentLength nvarchar(100),
        InternalWebServerUploadRequestTotalTimeMs nvarchar(100),
        InternalWebServerDownloadResponseTotalTimeMs nvarchar(100),
        ExternalWebServerServicePoint nvarchar(100),
        ExternalWebServerGetRequestStreamTotalTimeMs nvarchar(100),
        ExternalWebServerUploadRequestTotalTimeMs nvarchar(100),
        ExternalWebServerGetResponseTotalTimeMs nvarchar(100),
        ExternalWebServerGetResponseStreamTotalTimeMs nvarchar(100),
        ExternalWebServerDownloadResponseTotalTimeMs nvarchar(100),
        ErrorMessage nvarchar(256),
        StandaloneServerId StandardIdType not null,
)

create clustered index RemoteSessionLog_DbTime on RemoteSessionLog(DbCreationTime)
create index RemoteSessionLog_RemoteSessionStartTime on RemoteSessionLog(RemoteSessionStartTime)
create index RemoteSessionLog_EndUserId on RemoteSessionLog(EndUserId)
create index RemoteSessionLog_EndUserSessionId on RemoteSessionLog(EndUserSessionId)

CREATE TABLE dbo.RemoteSessionApplicationLog (
        RemoteSessionApplicationId StandardIdType NOT NULL primary key nonclustered,
        RemoteSessionId StandardIdType NOT NULL,
        ApplicationStartTime [datetime2](7) NOT NULL,
        [DbCreationTime] [datetime2](7) NOT NULL default SYSUTCDATETIME(),
      
        EndUserId EndUserIdType             not null,
        EndUserSessionId StandardIdType     not null, 
        ResourceDefinitionId StandardIdType     not null, 
        ApplicationName nvarchar(255) not null
)

CREATE TABLE [dbo].[MessageLog](
        [EventId] StandardIdType NOT NULL primary key nonclustered,
        [ClientMessageCreationTime] [datetime2](7) NOT NULL,
        [Priority] MessagePriorityType NOT NULL,
        [Module] ModuleNameType NOT NULL,
        [Submodule] [nvarchar](255) NULL,
        [InstanceId] [nvarchar](255) NULL,
        DescriptorName DescriptorNameType not null,
        Hostname nvarchar(100) not null,
        -- cross references
        EndUserId EndUserIdType null,
        EndUserSessionId StandardIdType null,
        RemoteSessionId StandardIdType null,
        RemoteHostId StandardIdType null,
        StandaloneServerId StandardIdType null,
        TenantId StandardIdType null,
        AdminSessionId StandardIdType null,
        GridPartition int not null,
        -- message parameters
        M1 nvarchar(max)  null,
        M2 nvarchar(max)  null,
        M3 nvarchar(max)  null,      
        DbCreationTime [datetime2] not null default SYSUTCDATETIME()
 )

create clustered index MessageLog_DbTime on MessageLog(DbCreationTime)
create index MessageLog_ClientMessageCreationTime on MessageLog(ClientMessageCreationTime)
create index MessageLog_Module on MessageLog(Module)
create index MessageLog_DescriptorName on MessageLog(DescriptorName)
create index MessageLog_RemoteSessionId on MessageLog(RemoteSessionId)
create index MessageLog_Priority on MessageLog(Priority)
create index MessageLog_RemoteHostId on MessageLog(RemoteHostId)