# have bin directory on the path
# start x64 powershell 
#   >  C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe
# check permission to run scripts with Get-ExecutionPolicy -List
#  ps> Set-ExecutionPolicy Unrestricted -scope Process
#  ps> CloudConnect.ps1
#  $regularUser = New-Object Ericom.CloudConnect.Utilities.SpaceCredentials("regularUser")
#  $adminApi = [Ericom.MegaConnect.Runtime.XapApi.AdministrationProcessingUnitClassFactory]::GetInstance($regularUser)
#  $adminSessionId = $adminApi.CreateAdminsession("ccadmin", ".Admin1!","rooturl","en-us")
#  "Guid=" + $adminSessionId

function Get-ScriptDirectory
{
    $Invocation = (Get-Variable MyInvocation -Scope 1).Value
    Split-Path $Invocation.MyCommand.Path
}

$MegaConnectRuntimeApiDll = Join-Path (Get-ScriptDirectory) "MegaConnectRuntimeXapApi.dll"
$CloudConnectUtilitiesDll = Join-Path (Get-ScriptDirectory) "CloudConnectUtilities.dll"


add-type -Path (
    $MegaConnectRuntimeApiDll,
    $CloudConnectUtilitiesDll
)
                                                                                                                `
$Assem = ( 
    $MegaConnectRuntimeApiDll,
    $CloudConnectUtilitiesDll
    ) 

