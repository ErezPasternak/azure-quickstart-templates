﻿if exists (select * from sysobjects where name = 'GetAllTableSizes' and type = 'P')
    drop procedure GetAllTableSizes
go

CREATE PROCEDURE GetAllTableSizes
AS
begin
  -- table variable to hold the raw information
  declare @TempTable1 table
  (
      tableName varchar(100),
      numberofRows varchar(100),
      reservedSize varchar(50),
      dataSize varchar(50),
      indexSize varchar(50),
      unusedSize varchar(50)
  )

  DECLARE @TableName VARCHAR(100)    --For storing values in the cursor

  DECLARE tableCursor CURSOR FOR 
  select [name]
  from dbo.sysobjects 
  where  OBJECTPROPERTY(id, N'IsUserTable') = 1
  FOR READ ONLY

  OPEN tableCursor
  FETCH NEXT FROM tableCursor INTO @TableName

  WHILE (@@Fetch_Status >= 0)
  BEGIN
    --Dump the results of the sp_spaceused query to the temp table
    INSERT  @TempTable1
        EXEC sp_spaceused @TableName

    FETCH NEXT FROM tableCursor INTO @TableName
  END

  CLOSE tableCursor
  DEALLOCATE tableCursor

  -- convert the 'kb' columns to numbers

  declare @TableSize table
  (
      tableName varchar(100),
      numberofRows int,
      reservedSize int,
      dataSize int,
      indexSize int,
      unusedSize int
  )

  insert into @TableSize
  SELECT 
      tableName 'tableName',
      cast(numberofRows as int) 'numberofRows',
      cast(replace(reservedSize, ' KB', '') as int) 'reservedSize',
      cast(replace(dataSize, ' KB', '') as int) 'dataSize',
      cast(replace(indexSize, ' KB', '') as int) 'indexSize',
      cast(replace(unusedSize, ' KB', '') as int) 'unusedSize'
  FROM 
      @TempTable1

  select 
    tableName 'TableName',
    numberofRows 'NumberRows',
    reservedSize 'ReservedSizeKB',
    dataSize 'DataSizeKB',
    indexSize 'IndexSizeKB',
    unusedSize'UnusedSizeKB'

  from @TableSize
  order by numberofRows desc

end

GO

