﻿-- views for reportingRemoteSessionApplicationLog

IF EXISTS (SELECT TABLE_NAME FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = 'LogMessageReportingView')
    DROP VIEW LogMessageReportingView
GO

create view LogMessageReportingView
as
  select  
    MessageLog.EventId,
    MessageLog.ClientMessageCreationTime,
    MessageLog.Priority 'PriorityNumber',
    MessageLog.Module,
    MessageLog.Submodule,
    MessageLog.InstanceId,
    MessageLog.DescriptorName,
    MessageLog.Hostname,
    MessageLog.EndUserId,
    MessageLog.EndUserSessionId,
    MessageLog.RemoteSessionId,
    MessageLog.RemoteHostId,
    MessageLog.StandaloneServerId,
    MessageLog.AdminSessionId,
    MessageLog.M1 'M1_Unbounded',
    MessageLog.M2 'M2_Unbounded',
    MessageLog.M3 'M3_Unbounded',
    case when Len(MessageLog.M1) > 1000 then Left(MessageLog.M1,1000) + ' ...' else MessageLog.M1 end 'M1_Bounded',
    case when Len(MessageLog.M2) > 1000 then Left(MessageLog.M2,1000) + ' ...' else MessageLog.M2 end 'M2_Bounded',
    case when Len(MessageLog.M3) > 1000 then Left(MessageLog.M3,1000) + ' ...' else MessageLog.M3 end 'M3_Bounded',
    Name [TenantName],
    MessageLog.TenantId,
    MessageLog.DbCreationTime,
    MessageLog.GridPartition,
    --
    EndUserConfig.UserPrincipalName,         
    EndUserConfig.PersonName,
    -- 
    datediff(mi, ClientMessageCreationTime, SYSUTCDATETIME()) 'MinutesAgo',
    (select Name from MessagePriorities where Value = Priority) 'PriorityName',
     (case 
        when MessageLog.Module = 'StandaloneServer' and M1 in ('KeepAlive') or
             MessageLog.Module = 'AdminWs' and DescriptorName = 'StandaloneServerMessageDescriptors.Api'
             then 1
             else 0
       end) 'IsUninteresting',
    (case  
         when DescriptorName  in ('StandaloneServerMessageDescriptors.Api', 'RuntimeMessageDescriptors.Api')
      then 1 else 0 end) 'IsApi'       

  from MessageLog with(nolock) 
       left outer join EndUserConfig with(nolock) on(MessageLog.EndUserId = EndUserConfig.EndUserId)
       left outer join Tenant  with(nolock) on(MessageLog.TenantId = Tenant.TenantId)

go

IF EXISTS (SELECT TABLE_NAME FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = 'EndUserReportingView')
    DROP VIEW EndUserReportingView
GO

create view EndUserReportingView
as
 select  
    UserPrincipalName,
    PersonName,
    InitialLoginTime,
    EndUserConfig.TenantId,
    Name [TenantName],
    (select count(*) from EndUserSessionLog  with(nolock) where EndUserSessionLog.EndUserId = EndUserConfig.EndUserId) 'NumberLogins',
    (select count(*) from RemoteSessionLog  with(nolock) where RemoteSessionLog.EndUserId = EndUserConfig.EndUserId) 'NumberRemoteSessions',
    EndUserId
 from 
     EndUserConfig  with(nolock)
      join Tenant  with(nolock) on(EndUserConfig.TenantId = Tenant.TenantId)
go

IF EXISTS (SELECT TABLE_NAME FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = 'EndUserSessionReportingView')
    DROP VIEW EndUserSessionReportingView
GO

create view EndUserSessionReportingView
as
 select  
    EndUserSessionStartTime,
    UserPrincipalName,
    PersonName,
    SourceMachineIp,
    SessionEndTime,
    SessionEndReason,
    (select count(*) from RemoteSessionLog  with(nolock) where RemoteSessionLog.EndUserSessionId = EndUserSessionLog.EndUserSessionId) 'NumberRemoteSessionsLaunched',
    EndUserConfig.EndUserId,
    EndUserSessionId,
    StandaloneServerId,
    EndUserSessionLog.DbCreationTime DbCreationTime,
    Tenant.Name [TenantName],
    Tenant.TenantId
from 
    EndUserSessionLog with(nolock)
    join EndUserConfig  with(nolock) on(EndUserSessionLog.EndUserId = EndUserConfig.EndUserId)
    left outer join sessionEndLog with(nolock) on(EndUserSessionLog.EndUserSessionId = sessionEndLog.EventId)
    join Tenant  with(nolock) on(EndUserConfig.TenantId =Tenant.TenantId)

go

IF EXISTS (SELECT TABLE_NAME FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = 'RemoteSessionReportingView')
    DROP VIEW RemoteSessionReportingView
GO

create view RemoteSessionReportingView
as
  select
    DATEADD(day, DATEDIFF(day, 0, RemoteSessionStartTime), 0) AS DayStart,
    DATEADD( day , -1, DATEADD(week, DATEDIFF(week, 0, RemoteSessionStartTime), 0)) AS WeekStart,
    DATEADD(month, DATEDIFF(month, 0, RemoteSessionStartTime), 0) AS MonthStart,
    DATEADD(year, DATEDIFF(year, 0, RemoteSessionStartTime), 0) AS YearStart,
    DATENAME(dw,RemoteSessionStartTime) AS DayOfWeek,
    RemoteSessionStartTime,
    UserPrincipalName,
    PersonName,
    InitialApplicationName,
    RemoteHostName,
    SessionEndLog.SessionEndTime,
    SessionEndLog.SessionEndReason,
    RemoteSessionId,
    ResourceDefinitionId,
    RemoteHostId,
    RemoteSessionLog.DbCreationTime,
    RemoteSessionLog.EndUserId,
    RemoteSessionLog.EndUserSessionId,
    Tenant.Name [TenantName],
    Tenant.TenantId,
    (Select count(*) from [MessageLog] with(nolock) where MessageLog.RemoteSessionId = RemoteSessionLog.RemoteSessionId and DescriptorName = 'RemoteHostMessageDescriptors.RdpSessionActivated')  'NumberReconnects',
    (Select count(*) from [MessageLog] with(nolock) where MessageLog.RemoteSessionId = RemoteSessionLog.RemoteSessionId and DescriptorName = 'RemoteHostMessageDescriptors.RdpSessionDisconnected')  'NumberDisconnects'
from 
    RemoteSessionLog with(nolock)
    join EndUserSessionLog with(nolock) on (RemoteSessionLog.EndUserSessionId = EndUserSessionLog.EndUserSessionId)
    join EndUserConfig  with(nolock) on(EndUserSessionLog.EndUserId = EndUserConfig.EndUserId)
    join Tenant  with(nolock) on(EndUserConfig.TenantId =Tenant.TenantId)
    left outer join SessionEndLog with(nolock) on(RemoteSessionLog.RemoteSessionId = SessionEndLog.EventId)

go

IF EXISTS (SELECT TABLE_NAME FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = 'EsgSessionLogReportingView')
    DROP VIEW EsgSessionLogReportingView
GO

create view EsgSessionLogReportingView
as
  select
       [DbCreationTime] ,
        [EventId] ,
        StartTime,
        EndTime ,
        ElapsedTimeMs,
        EsgSessionId,
        EsgSessionType,
        UnderlyingProtocols,
        Purpose ,
        TerminatedBy ,
        TerminationReason,
        ClientAddress,  
        HostAddress ,     
        FinalAddress ,
        RemoteUserName,
        ClientDescription ,
        StandaloneServerId ,  
        [EsgSessionLog].EndUserId ,  
        EndUserSessionId ,        
        UserPrincipalName, PersonName,
        datediff(mi, StartTime, SYSUTCDATETIME()) 'MinutesAgo'
from 
    [EsgSessionLog] with(nolock)
    join EndUserConfig  with(nolock) on(EsgSessionLog.EndUserId = EndUserConfig.EndUserId)
   
go

IF EXISTS (SELECT TABLE_NAME FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = 'RemoteSessionApplicationLogView')
    DROP VIEW RemoteSessionApplicationLogView
GO

create view RemoteSessionApplicationLogView
as
  select
    DATEADD(day, DATEDIFF(day, 0, ApplicationStartTime), 0) AS DayStart,
    DATEADD( day , -1, DATEADD(week, DATEDIFF(week, 0, ApplicationStartTime), 0)) AS WeekStart,
    DATEADD(month, DATEDIFF(month, 0, ApplicationStartTime), 0) AS MonthStart,
    DATEADD(year, DATEDIFF(year, 0, ApplicationStartTime), 0) AS YearStart,
    DATENAME(dw,ApplicationStartTime) AS DayOfWeek,
    RemoteSessionApplicationId,
    RemoteSessionId,
    ApplicationStartTime,
    [DbCreationTime],
    RemoteSessionApplicationLog.EndUserId,
    EndUserSessionId,
    ResourceDefinitionId,
    ApplicationName,
    Tenant.Name [TenantName],
    Tenant.TenantId
from 
    RemoteSessionApplicationLog with(nolock)
    join EndUserConfig with(nolock) on(RemoteSessionApplicationLog.EndUserId = EndUserConfig.EndUserId)
    join Tenant  with(nolock) on(EndUserConfig.TenantId = Tenant.TenantId)

   
go